﻿using System;
using RfidSdk;
namespace RfidReader
{
    class ScanReaderImpl : RfidReaderRspNotify
    {
        ScanWindow scanWin;
        delegate void OnRecvRspDelegate(byte[] message, int messageLen);
        public void SetScanWind(ScanWindow win)
        {
            this.scanWin = win;
        }

        void RfidReaderRspNotify.OnRecvResetRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (scanWin != null)
            {
                if (scanWin.InvokeRequired)
                {
                    scanWin.BeginInvoke(new EventHandler(delegate
                    {
                        scanWin.OnRecvResetParam();
                    }));

                }
                else
                {
                    scanWin.OnRecvResetParam();
                }
            }
        }

        void RfidReaderRspNotify.OnRecvSetFactorySettingRsp(RfidSdk.RfidReader reader, byte result)
        {
            
        }

        void RfidReaderRspNotify.OnRecvStartInventoryRsp(RfidSdk.RfidReader reader, byte result)
        {
            
        }

        void RfidReaderRspNotify.OnRecvStopInventoryRsp(RfidSdk.RfidReader reader, byte result)
        {
            
        }

        void RfidReaderRspNotify.OnRecvDeviceInfoRsp(RfidSdk.RfidReader reader, byte[] firmwareVersion, byte deviceType)
        {
            
        }

        void RfidReaderRspNotify.OnRecvSetWorkParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            
        }

        void RfidReaderRspNotify.OnRecvQueryWorkParamRsp(RfidSdk.RfidReader reader, byte result, RfidWorkParam workParam)
        {
            
        }

        void RfidReaderRspNotify.OnRecvSetTransmissionParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            
        }

        void RfidReaderRspNotify.OnRecvQueryTransmissionParamRsp(RfidSdk.RfidReader reader, byte result, RfidTransmissionParam transmissiomParam)
        {

            if (scanWin != null)
            {
                if (scanWin.InvokeRequired)
                {
                    scanWin.BeginInvoke(new EventHandler(delegate
                    {
                        scanWin.OnRecvQueryTransferParamRep(transmissiomParam);
                    }));

                }
                else
                {
                    scanWin.OnRecvQueryTransferParamRep(transmissiomParam);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvSetAdvanceParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            
        }

        void RfidReaderRspNotify.OnRecvQueryAdvanceParamRsp(RfidSdk.RfidReader reader, byte result, RfidAdvanceParam advanceParam)
        {
            
        }

        void RfidReaderRspNotify.OnRecvTagNotify(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, byte tlvCount)
        {
            
        }

        void RfidReaderRspNotify.OnRecvHeartBeats(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, byte tlvCount)
        {
            return;
        }

        void RfidReaderRspNotify.OnRecvSettingSingleParam(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvQuerySingleParam(RfidSdk.RfidReader reader, TlvValueItem item)
        {
            throw new NotImplementedException();
        }

        public void OnRecvWriteTagRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvWriteTagRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvReadBlockRsp(RfidSdk.RfidReader reader, byte result, byte[] read_data,byte[] epc_data)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvWriteWiegandNumberRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvLockResult(RfidSdk.RfidReader reader, byte result) { throw new NotImplementedException(); }

        public void OnRecvRecordNotify(RfidSdk.RfidReader reader, string time, string tagId)
        {
            throw new NotImplementedException();
        }

        public void OnRecvRecordStatusRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        public void OnRecvSetRtcTimeStatusRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        public void OnRecvQueryRtcTimeRsp(int year, int month, int day, int hour, int min, int sec)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvRecordNotify(RfidSdk.RfidReader reader, string time, string tagId)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvRecordStatusRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvSetRtcTimeStatusRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvQueryRtcTimeRsp(int year, int month, int day, int hour, int min, int sec)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvQueryExtParamRsp(RfidSdk.RfidReader reader, byte result, RfidExtParam extParam)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvSetExtParam(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvAudioPlayRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvRelayOpRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvVerifyTagRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvSetUsbInfoRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvQueryUsbInfoRsp(RfidSdk.RfidReader reader,byte interfaceType, byte usbProto, byte enterflag)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvSetDataFlagRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        void RfidReaderRspNotify.OnRecvQueryDataFlagRsp(RfidSdk.RfidReader reader, UInt16 dataflag, byte dataFormat)
        {
            throw new NotImplementedException();
        }

        public void OnRecvQueryModbusParam(RfidSdk.RfidReader reader, byte tagNum, byte unionSize, byte startaddr, byte clearflag, int modbusProto)
        {
            throw new NotImplementedException();
        }

        public void OnRecvSetModbusParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            throw new NotImplementedException();
        }

        public void OnRecvTagData(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, byte tlvCount)
        {
            throw new NotImplementedException();
        }
    }
}
