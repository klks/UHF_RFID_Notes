﻿
using ConfigureFile;
using NPOI.HSSF.UserModel;
//using NPOI.OpenXmlFormats.Spreadsheet;
//using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
//using NPOI.XWPF.UserModel;
using RfidSdk;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RfidReader
{
    public partial class M100Window : Form
    {
        RfidSdk.RfidReader reader;
        Form1 parentWindow;
        Dictionary<String, TagItem> tagDictionary;
        RfidWorkParam workParam;
        RfidTransmissionParam transferParam;
        RfidAdvanceParam advanceParam;
        Boolean initWorkParamFlag = false;
        Boolean initTransParamFlag = false;
        Boolean initAdvanceParamFlag = false;
        System.IO.FileStream record_file_stream = null;
        System.IO.StreamWriter record_writer = null;
        public byte autoWriteMode = 0;  //0:默认 1:自动写Hex 2：自动写wiegand
        public byte autoIncreseFlag = 0;
        System.Timers.Timer timer = new System.Timers.Timer(800); //实例化Timer类，设置间隔时间为1000毫秒；
        String mWriteFilePath;

        int mWriteStartLine;    
        public int mFileWriteMode; //0:静止 1:手动写  2:自动写
        IWorkbook mFileWorkBook;
        IRow mFileRow;
        ICell mFileCell;
        ISheet mFileSheet;

        byte[] mLastWriteData = new byte[128];
        byte mLastWriteDataLen = 0;

        System.Timers.Timer mFileWriteTimer = new System.Timers.Timer(800);

        System.Timers.Timer mAutoAddVerfiyTimer = new System.Timers.Timer(800);
        Boolean mAutoAddVerfiyFlag = false;

        FileStream mFileWriteStream;
        public M100Window()
        {
            InitializeComponent();
            workParam = new RfidWorkParam();
            transferParam = new RfidTransmissionParam();
            advanceParam = new RfidAdvanceParam();
            tagDictionary = new Dictionary<string, TagItem>();
            tagDictionary.Clear();
            skinWaterTextBox_address.Text = "2";
            skinComboBox_membank.SelectedIndex = 1;
            skinWater_content.Text = "01 02 03 04";
            skinWaterTextBox_length.Text = "2"; 
            skinWaterTextBox_password.Text = "00 00 00 00";
            textBox_auto_hex_write_text.Text = "E2 01 02 03 04 05 06 07 08 09 0A 0B";
            textBox_auto_wiegand_write_text.Text = "1234";
            timer.Elapsed += new System.Timers.ElapsedEventHandler(HandleWriteTagTimer);//到达时间的时候执行事件；
            timer.AutoReset = true;//设置是执行一次（false）还是一直执行(true)；
            timer.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；

            mFileWriteTimer.Elapsed += new System.Timers.ElapsedEventHandler(HandleFileWriteTagTimer);
            mFileWriteTimer.AutoReset = true;
            mFileWriteTimer.Enabled = true;
            mFileWriteTimer.Stop();
            mFileWriteMode = 0;


            mAutoAddVerfiyTimer.Elapsed += new System.Timers.ElapsedEventHandler(HandleAutoAddVerfiyTimer);
            mAutoAddVerfiyTimer.AutoReset = true;
            mAutoAddVerfiyTimer.Enabled = true;
            mAutoAddVerfiyTimer.Stop();
        }

        public void SaveParam()
        {
            byte temp = 0;
            CIniFile.WriteIniKeys("INFO", "WriteHexData", textBox_auto_hex_write_text.Text, parentWindow.sys_init_path);
            CIniFile.WriteIniKeys("INFO", "WriteWiegandData", textBox_auto_wiegand_write_text.Text, parentWindow.sys_init_path);
            if (checkBox_auto_write_flag.Checked)
            {
                temp = 1;
            }

            if (checkBox_auto_write_increse.Checked)
            {
                temp |= 0x02;
            }
            CIniFile.WriteIniKeys("INFO", "WriteAutoInfo", temp.ToString(), parentWindow.sys_init_path);


            CIniFile.WriteIniKeys("INFO", "WriteFilePath", textBox_write_file_path.Text, parentWindow.sys_init_path);
            CIniFile.WriteIniKeys("INFO", "WriteFileData", textBox_write_file_data.Text, parentWindow.sys_init_path);
            CIniFile.WriteIniKeys("INFO", "WriteFileStartLine", numericUpDown_write_file_row.Value.ToString(), parentWindow.sys_init_path);

        }

        public void OnClose()
        {
            mFileWriteTimer.Stop();
            timer.Stop();
            if (mFileWriteStream != null) { mFileWriteStream.Close();}
        }
        public void UpdateParam()
        {
            textBox_auto_hex_write_text.Text = CIniFile.ReadIniKeys("INFO", "WriteHexData", parentWindow.sys_init_path);
            textBox_auto_wiegand_write_text.Text = CIniFile.ReadIniKeys("INFO", "WriteWiegandData", parentWindow.sys_init_path);

            try
            {
                String temp = CIniFile.ReadIniKeys("INFO", "WriteAutoInfo", parentWindow.sys_init_path);
                if (temp.Trim().Length > 0)
                {
                    int tempvalue = int.Parse(temp);
                    if ((tempvalue & 0x01) != 0)
                    {
                        checkBox_auto_write_flag.Checked = true;
                    }

                    if ((tempvalue & 0x02) != 0)
                    {
                        checkBox_auto_write_increse.Checked = true;
                    }
                }
            }
            catch (Exception)
            {

            }

            textBox_write_file_path.Text = CIniFile.ReadIniKeys("INFO", "WriteFilePath", parentWindow.sys_init_path);
            textBox_write_file_data.Text = CIniFile.ReadIniKeys("INFO", "WriteFileData", parentWindow.sys_init_path);
            numericUpDown_write_file_row.Text = CIniFile.ReadIniKeys("INFO", "WriteFileStartLine", parentWindow.sys_init_path);
        }
        public void SetParentWindow(Form1 window)
        {
            this.parentWindow = window;
            UpdateParam();
        }
        public void SetReader(RfidSdk.RfidReader reader)
        {
            this.reader = reader;
        }

        private void skinButton_start_Click(object sender, EventArgs e)
        {
            ((Form1)(this.Parent.Parent)).AddResultItem("Send start inventorying cmd.",MessageType.Normal);
            reader.StartInventory();
        }

        private void skinButton_stop_Click(object sender, EventArgs e)
        {
            ((Form1)(this.Parent.Parent)).AddResultItem("send stop inventory.", MessageType.Normal);
            reader.StopInventory();
        }



        private void skinButton_save_Click(object sender, EventArgs e)
        {
            //((Form1)(this.Parent.Parent)).AddResultItem("send stop inventory.", MessageType.Normal);
            String ExcelFilePath = null;
            String subItem;
            int index = 0;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            //"Excel files (*.xls)|*.xls|All files (*.*)|*.*"
            saveFileDialog.Filter = "Excel files (*.xls)|*.xls|Excel files (*.xlsx)|*.xlsx";
            saveFileDialog.FilterIndex = 1;

            if (saveFileDialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }
            else
            {
                ExcelFilePath = saveFileDialog.FileName;
            }
            
            //创建文件
            HSSFWorkbook _workbook = new HSSFWorkbook();
            ISheet wSheet = _workbook.CreateSheet("UHF Data"+ string.Format("{0:yyyy-MM-dd}", DateTime.Now));
            
            IRow row;
            ICell cell;
            foreach (ListViewItem item in skinListView_tags.Items)
            {
                if (item.SubItems[1].Text.Trim().Length != 0)
                {
                    row = wSheet.CreateRow(index);
                    cell = row.CreateCell(0);
                    cell.SetCellValue(item.SubItems[1].Text);
                    subItem = item.SubItems[2].Text.Trim();
                    //处理TID,USER
                    index++;
                }
                else
                {
                    //处理TID,USER
                }
            }
            wSheet.AutoSizeColumn(0);
            FileStream fs = new FileStream(ExcelFilePath, FileMode.Create, FileAccess.Write);
            _workbook.Write(fs);
            fs.Close();
            parentWindow.AddResultItem("文件：" + ExcelFilePath + " 成功", MessageType.Normal);
        }

        private void DisplayOneTag(String epc_id,String ext_msg,String ext_id, byte ext_id_type)
        {
            TagItem tag_item = null;
            ListViewItem item = new ListViewItem();
            item.ForeColor = Color.BurlyWood;

            try
            {
                if (ext_id_type == (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_TID || (epc_id.Length == 0))
                {
                    tagDictionary.TryGetValue(ext_id, out tag_item);
                }
                else
                {
                    tagDictionary.TryGetValue(epc_id, out tag_item);
                }
            }
            catch (ArgumentNullException)
            {

            }
            if (null != tag_item)
            {
                tag_item.mReadTimes++;
                tag_item.viewItem.SubItems[3].Text = ext_msg;
                tag_item.viewItem.SubItems[4].Text = tag_item.mReadTimes.ToString();
                if (ext_id.Length > 0)
                {
                    if ( ext_id_type == (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_TEMPETURE)
                    {
                        tag_item.viewItem.SubItems[2].Text = ext_id;
                    }
                }
            }
            else
            {
                tag_item = new TagItem();
                item.Text = DateTime.Now.ToLongTimeString();
                item.SubItems.Add(epc_id);
                //add extend data
                if (ext_id.Length > 0 )
                {
                    if (ext_id_type == (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_TID)
                    {
                        item.SubItems.Add(ext_id);
                    }
                    else if (ext_id_type == (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_USER)
                    {
                        item.SubItems.Add(ext_id);
                    }
                    else
                    {
                        item.SubItems.Add(ext_id);
                    }
                    
                }
                else
                {
                    item.SubItems.Add("");
                }
                item.SubItems.Add(ext_msg);
                item.SubItems.Add("1");
                /*
                item.SubItems[0].ForeColor = Color.BurlyWood;
                item.SubItems[1].ForeColor = Color.BurlyWood;
                item.SubItems[2].ForeColor = Color.BurlyWood;
                item.SubItems[3].ForeColor = Color.BurlyWood;
                */
                tag_item.viewItem = item;
                tag_item.mReadTimes = 1;
                tag_item.viewItem = skinListView_tags.Items.Add(item);
                if (ext_id_type == (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_TID || (epc_id.Length == 0))
                {
                    tagDictionary.Add(ext_id, tag_item);
                }
                else
                {
                    tagDictionary.Add(epc_id, tag_item);
                }
                skinLabel_tag_num.Text = tagDictionary.Count.ToString();
                //skinListView_tags.Items[skinListView_tags.Items.Count - 1].EnsureVisible();
            }

        }

        //message: receive from reader
        public void InsertTagRecord(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, int tlvCount)
        {
            int index = 0;
            int tagIndex = 0;
            UInt16 year = 0;
            String tagId = "";
            String ext_id = "";
            byte ext_type = 0;
            int tempeture = 0;
            float fTempeture = 0;
            String ex_msg = "";
            if (null == tlvItems)
            {
                return;
            }
            if (tlvItems.Length < tlvCount)
            {
                return;
            }

            for (index = 0; index < tlvCount;index++)
            {
                switch(tlvItems[index]._tlvType)
                {
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_EPC:
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_TAG_6B:
                        for (tagIndex = 0; tagIndex < tlvItems[index]._tlvLen; tagIndex++)
                        {
                            tagId += tlvItems[index]._tlvValue[tagIndex].ToString("X2");
                        }
                        break;
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_RSSI:
                        ex_msg += "RSSI="+tlvItems[index]._tlvValue[0].ToString("X2")+";";
                        break;
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_TID:
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_USER:
                        ext_type = tlvItems[index]._tlvType;
                        for (tagIndex = 0; tagIndex < tlvItems[index]._tlvLen; tagIndex++)
                        {
                            ext_id += tlvItems[index]._tlvValue[tagIndex].ToString("X2");
                        }
                        break;
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_TEMPETURE:
                        ext_type = tlvItems[index]._tlvType;
                        tempeture = tlvItems[index]._tlvValue[0];
                        tempeture = tempeture << 8;
                        tempeture += tlvItems[index]._tlvValue[1];
                        fTempeture = ((float)tempeture) / 10;
                        ext_id = fTempeture.ToString() + " C";
                        break;
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_ANT_NO:
                        ex_msg += "ANT=" + tlvItems[index]._tlvValue[0]+";";
                        break;
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_DEVICE_NO:
                        ex_msg += "Dev No=" + System.Text.Encoding.Default.GetString(tlvItems[index]._tlvValue) + ";";
                        break;
                    case (byte)RfidSdk.Tlv_Attr_Code.TLV_ATTR_CODE_FLUSH_NOW_TIME:
                        year = tlvItems[index]._tlvValue[0];
                        year = (UInt16)(year << 8);
                        year += tlvItems[index]._tlvValue[1];
                        ex_msg += String.Format("{0:4d}/{1:2d}/{2:2d} {3:2d}:{4:2d}:{5:2d}",year, tlvItems[index]._tlvValue[2], tlvItems[index]._tlvValue[3]
                            , tlvItems[index]._tlvValue[4], tlvItems[index]._tlvValue[5], tlvItems[index]._tlvValue[6]);
                        break;
                }
            }
           DisplayOneTag(tagId, ex_msg, ext_id, ext_type);
        }
		
		 public void OnRecvRecordNodtify(RfidSdk.RfidReader reader, String time, String tagId)
        {
            if (record_writer == null)
            {
                return;
            }

            String text = time + " " + tagId;
            record_writer.WriteLine(text);
            parentWindow.AddResultItem(text, MessageType.Normal);
        }

        public void OnRecvRecordStatusRsp(RfidSdk.RfidReader reader, byte status)
        {
            record_writer.Flush();
            record_writer.Close();
            record_writer = null;
            record_file_stream.Close();
            record_file_stream = null;
            parentWindow.AddResultItem("Receive record from reader completed.",MessageType.Normal);
        }

        public void OnRecvSetRtcTimeRsp(RfidSdk.RfidReader reader, byte status)
        {
            if (status == 0)
            {
                parentWindow.AddResultItem("Success to set reader's rtc time.", MessageType.Normal);
            }
            else
            {
                parentWindow.AddResultItem("Fail to set reader's rtc time.", MessageType.Error);
            }
        }

        public void OnRecvQueryRtcTimeRsp(int year,int month,int day,int hour,int min,int sec)
        {
            StringBuilder time = new StringBuilder();
            time.AppendFormat("The reader's time: {0}.{1}.{2}  {3}:{4}:{5}", year, month, day, hour, min, sec);
            parentWindow.AddResultItem(time.ToString(), MessageType.Normal);
        }
        public void OnRecvQuerySingleParam(TlvValueItem item)
        {
            if (item._tlvValue[0] == 0x04)
            {
                UInt16 value = 0;
                String text = "";
                value = item._tlvValue[3];
                value = (UInt16)(value << 8);
                value += item._tlvValue[4];
                text = "Mixer Gain：" + item._tlvValue[1].ToString() + " , IF AMP Gain：" + item._tlvValue[2].ToString() + "  , Threshold:" + value.ToString("X4");
                ((Form1)(this.Parent.Parent)).AddResultItem(text,MessageType.Normal);
            }
            else if(item._tlvValue[0] == (byte)Tlv_Attr_Code.TLV_ATTR_CODE_DEVICE_NO)
            {
                //设备类型:1byte 设备号
                String text = "";
                skinWaterTextBox_dev_num.Text = Encoding.UTF8.GetString(item._tlvValue,2,item._tlvValue.Length-2);
                text = "查询到的设备号是:" + Encoding.UTF8.GetString(item._tlvValue, 2, item._tlvValue.Length - 2);
                ((Form1)(this.Parent.Parent)).AddResultItem(text, MessageType.Normal);
            }
        }
        public void OnRecvWorkingParamRep(RfidWorkParam newParam)
        {
            initWorkParamFlag = true;
            workParam = newParam;
            //update the interface

            skinNumericUpDown_power.Value = workParam.ucRFPower;
            if (workParam.ucInventoryArea < skinComboBox_inventory_area.Items.Count)
            {
                skinComboBox_inventory_area.SelectedIndex = workParam.ucInventoryArea;
            }
            skinWaterTextBox_inventory_address.Text = workParam.ucInventoryAddress.ToString();
            skinWaterTextBox_inventory_length.Text = workParam.ucInventoryLength.ToString();
            skinNumericUpDown_trigger_time.Value = workParam.ucAutoTrigoffTime;
            skinNumericUpDown_work_filter.Value = workParam.ucFilterTime;
            skinNumericUpDown_work_interval.Value = workParam.ucScanInterval;
            if (0 != workParam.ucBeepOnFlag)
            {
                buzzer_check.Checked = true;
            }
            else
            {
                buzzer_check.Checked = false;
            }
            skinWaterTextBox_addr.Text = workParam.usDeviceAddr.ToString();
            if (workParam.ucWorkMode < 3)
            {
                skinComboBox_work_mode.SelectedIndex = workParam.ucWorkMode;
            }
            for (int index = 0; index < 8; index++)
            {
                if ( 0 != (workParam.usAntennaFlag & (1<< index)))
                {
                    checkedListBox_work_ant.SetItemChecked(index, true);
                }
            }
            if ( 0 != workParam.ucIsEnableRecord)
            {
                record_check.Checked = true;
            }
            else
            {
                record_check.Checked = false;
            }
        }

        
        private void skinButton_clear_Click(object sender, EventArgs e)
        {
            tagDictionary.Clear();
            skinListView_tags.Items.Clear();
        }

        private void skinButton_work_refresh_Click(object sender, EventArgs e)
        {
            reader.QueryWorkingParam();
        }

        private void skinButton_work_set_Click(object sender, EventArgs e)
        {
            byte tempValue = 0;
            RfidWorkParam tempWorkParam = new RfidWorkParam();
            tempWorkParam.ucParamVersion = workParam.ucParamVersion;
            tempWorkParam.ucRFPower = (byte)skinNumericUpDown_power.Value;
            tempWorkParam.ucScanInterval = (byte)(skinNumericUpDown_work_interval.Value);
            tempWorkParam.ucAutoTrigoffTime = (byte)(skinNumericUpDown_trigger_time.Value);
            tempWorkParam.ucWorkMode = (byte)skinComboBox_work_mode.SelectedIndex;
            tempWorkParam.ucFilterTime = (byte)skinNumericUpDown_work_filter.Value;
            tempWorkParam.usAntennaFlag = 0;
            tempWorkParam.usDeviceAddr = Convert.ToUInt16(skinWaterTextBox_addr.Text.ToString());
            if (buzzer_check.Checked)
            {
                tempWorkParam.ucBeepOnFlag = 1;
            }
            else
            {
                tempWorkParam.ucBeepOnFlag = 0;
            }

            tempWorkParam.usAntennaFlag = 0;
            for (int index = 0; index < 8; index++)
            {
                if (checkedListBox_work_ant.GetItemChecked(index))
                {
                    tempWorkParam.usAntennaFlag |= (UInt16)(1 << index);
                }
            }
            tempWorkParam.ucInventoryArea = (byte)skinComboBox_inventory_area.SelectedIndex;
            if (true == byte.TryParse(skinWaterTextBox_inventory_address.Text,out tempValue))
            {
                tempWorkParam.ucInventoryAddress = tempValue;
            }
            else
            {
                tempWorkParam.ucInventoryAddress = 0;
            }

            if (true == byte.TryParse(skinWaterTextBox_inventory_length.Text,out tempValue))
            {
                tempWorkParam.ucInventoryLength = tempValue;
            }
            else
            {
                tempWorkParam.ucInventoryLength = 0;
            }

            if (true == record_check.Checked)
            {
                tempWorkParam.ucIsEnableRecord = 1;
            }
            else
            {
                tempWorkParam.ucIsEnableRecord = 0;
            }
            reader.SetWorkingParam(tempWorkParam);
        }

        private void skinButton_transfer_query_Click(object sender, EventArgs e)
        {
            reader.QueryTransferParam();
        }

        public void FreshTransmissionParam(RfidTransmissionParam transParam)
        {
            int index = 0;
            String strTemp;
            initTransParamFlag = true;
            transferParam = transParam;
            //update the UI
            if (transferParam.ucTransferLink <= skinComboBox_transfer_mode.Items.Count)
            {
                skinComboBox_transfer_mode.SelectedIndex = (byte)transferParam.ucTransferLink;
            }

            if (transferParam.ucBaudRate < 5)
            {
                skinComboBox_transfer_baudrate.SelectedIndex = transferParam.ucBaudRate;
            }

            //set wiegand
            if (transferParam.ucWiegandProtocol < skinComboBox_wiegand_protocl.Items.Count)
            {
                skinComboBox_wiegand_protocl.SelectedIndex = transferParam.ucWiegandProtocol;
            }
            skinWaterTextBox_wiegand_width.Text = transferParam.ucWiegandPulseWidth.ToString();
            skinWaterTextBox_wiegand_prorid.Text = transferParam.ucWiegandPulsePeriod.ToString();
            skinWaterTextBox_wiegand_interval.Text = transferParam.ucWiegandInterval.ToString();
            skinNumericUpDown_wiegand_location.Value = transferParam.ucWiegandPosition;
            if (transferParam.ucWiegandDirection == 0)
            {
                skinComboBox_wiegand_direction.SelectedIndex = 0;
            }
            else
            {
                skinComboBox_wiegand_direction.SelectedIndex = 1;
            }
            //update tcp/ip UI
            strTemp = "";
            for (index = 0; index < 6; index++)
            {
                if (index != 5)
                {
                    strTemp += transferParam.mac_addr[index].ToString("X2") + ":";
                }
                else
                {
                    strTemp += transferParam.mac_addr[index].ToString("X2");
                }
            }
            skinWaterTextBox_ip_mac.Text = strTemp;

            if (0 != transferParam.config_ip_mode)
            {
                dhcp_check.Checked = true;
            }
            else
            {
                dhcp_check.Checked = false;
            }

            //subnet ip
            strTemp = "";
            for (index = 0; index < 4; index++)
            {
                if (index != 3)
                {
                    strTemp += transferParam.sub_mask_addr[index].ToString() + ".";
                }
                else
                {
                    strTemp += transferParam.sub_mask_addr[index].ToString();
                }
            }
            skinWaterTextBox_ip_sub_masker.Text = strTemp;

            //gate way
            strTemp = "";
            for (index = 0; index < 4; index++)
            {
                if (index != 3)
                {
                    strTemp += transferParam.gateway[index].ToString() + ".";
                }
                else
                {
                    strTemp += transferParam.gateway[index].ToString();
                }
            }
            skinWaterTextBox_gate_way.Text = strTemp;

            //local Ip
            strTemp = "";
            for (index = 0; index < 4; index++)
            {
                if (index != 3)
                {
                    strTemp += transferParam.local_ip[index].ToString() + ".";
                }
                else
                {
                    strTemp += transferParam.local_ip[index].ToString();
                }
            }
            skinWaterTextBox_ip_local.Text = strTemp;

            //remote Ip
            strTemp = "";
            for (index = 0; index < 4; index++)
            {
                if (index != 3)
                {
                    strTemp += transferParam.remote_ip_addr[index].ToString() + ".";
                }
                else
                {
                    strTemp += transferParam.remote_ip_addr[index].ToString();
                }
            }
            skinWaterTextBox_ip_remote.Text = strTemp;
            if (transferParam.ucTransferProtocol < skinComboBox_sub_protocol.Items.Count)
            {
                skinComboBox_sub_protocol.SelectedIndex = transferParam.ucTransferProtocol;
            }
            //remote Ip
            skinWaterTextBox_local_port.Text = transferParam.local_port.ToString();
            skinWaterTextBox_remote_port.Text = transferParam.remote_port.ToString();
            skinWaterTextBox_heart_beats.Text = transferParam.heartBeates.ToString();

            skinWaterTextBox_module_sn.Text = new String(transferParam.syris_module_sn);
            skinWaterTextBox_module_id.Text = transferParam.syris_module_id.ToString();
        }
        private void skinButton_transfer_set_Click(object sender, EventArgs e)
        {
            int index = 0;
            RfidTransmissionParam tempTransfer = new RfidTransmissionParam();
            //update the UI
            tempTransfer.ucTransferLink = (byte)skinComboBox_transfer_mode.SelectedIndex;
            tempTransfer.ucBaudRate = (byte)skinComboBox_transfer_baudrate.SelectedIndex;
            tempTransfer.ucTransferProtocol = 0;
            //set wiegand
            tempTransfer.ucWiegandProtocol = (byte)skinComboBox_wiegand_protocl.SelectedIndex;
            tempTransfer.ucWiegandPulseWidth = byte.Parse(skinWaterTextBox_wiegand_width.Text);
            tempTransfer.ucWiegandPulsePeriod = byte.Parse(skinWaterTextBox_wiegand_prorid.Text);
            tempTransfer.ucWiegandInterval = byte.Parse(skinWaterTextBox_wiegand_interval.Text);
            tempTransfer.ucWiegandPosition = (byte)skinNumericUpDown_wiegand_location.Value;
            if(skinComboBox_wiegand_direction.SelectedIndex == 0)
            {
                tempTransfer.ucWiegandDirection = 0;
            }
            else
            {
                tempTransfer.ucWiegandDirection = 1;
            }
            //update tcp/ip UI
            //mac
            String[] strMac = skinWaterTextBox_ip_mac.Text.Split(':');
            if (strMac.Length < 6)
            {
                //error MAC address
                parentWindow.AddResultItem("Please check your MAC address",MessageType.Error);
                return;
            }
            for (index = 0; index < 6; index++)
            {
                tempTransfer.mac_addr[index] = Convert.ToByte(strMac[index],16);
            }

            if (dhcp_check.Checked)
            {
                tempTransfer.config_ip_mode = 1;
            }
            else
            {
                tempTransfer.config_ip_mode = 0;
            }

            //subnet ip
            String[] strSubnet = skinWaterTextBox_ip_sub_masker.Text.Split('.');
            for (index = 0; index < 4; index++)
            {
                tempTransfer.sub_mask_addr[index] = Convert.ToByte(strSubnet[index]);
            }

            //gate way
            String[] strGateway = skinWaterTextBox_gate_way.Text.Split('.');
            for (index = 0; index < 4; index++)
            {
                tempTransfer.gateway[index] = Convert.ToByte(strGateway[index]);
            }

            //local Ip
            String[] strLocalIp = skinWaterTextBox_ip_local.Text.Split('.');
            for (index = 0; index < 4; index++)
            {
                tempTransfer.local_ip[index] = Convert.ToByte(strLocalIp[index]);
            }


            //remote Ip
            String[] strRemoteIp = skinWaterTextBox_ip_remote.Text.Split('.');
            for (index = 0; index < 4; index++)
            {
                tempTransfer.remote_ip_addr[index] = Convert.ToByte(strRemoteIp[index]);
            }

            //remote Ip
            tempTransfer.local_port = Convert.ToUInt16(skinWaterTextBox_local_port.Text);
            tempTransfer.remote_port = Convert.ToUInt16(skinWaterTextBox_remote_port.Text);
            tempTransfer.heartBeates = Convert.ToByte(skinWaterTextBox_heart_beats.Text);
            tempTransfer.ucTransferProtocol = (byte)skinComboBox_sub_protocol.SelectedIndex;
            if (skinWaterTextBox_module_sn.Text.Length != 8)
            {
                parentWindow.AddResultItem("The module sn is error parameter.",MessageType.Error);
                return;
            }
            char[] sn = skinWaterTextBox_module_sn.Text.Trim().ToArray();
            for (index = 0; index < 8; index++)
            {
                tempTransfer.syris_module_sn[index] = sn[index];
            }
            if (0 == skinWaterTextBox_module_id.Text.Trim().Length)
            {
                parentWindow.AddResultItem("The module id is error parameter.", MessageType.Error);
                return;
            }
            char[] id = skinWaterTextBox_module_id.Text.ToArray();
            tempTransfer.syris_module_id = id[0];
            reader.SetTransferParam(tempTransfer);

            
        }

        private void skinButton_advance_refresh_Click(object sender, EventArgs e)
        {
            reader.QueryAdvanceParam();
        }

        private void skinButton_advance_set_Click(object sender, EventArgs e)
        {
            RfidAdvanceParam tempAdvanceParam = new RfidAdvanceParam();
            tempAdvanceParam.ucInitFlag = advanceParam.ucInitFlag;
            tempAdvanceParam.ucRegion = (byte)skinComboBox_advan_region.SelectedIndex;
            tempAdvanceParam.ucChannelIndex = byte.Parse(skinWaterTextBox_advan_channel.Text);
            tempAdvanceParam.ucFreqHoppingFlag = (byte)(skinComboBox_advan_hopping.SelectedIndex);
            tempAdvanceParam.ucCWFlag = (byte)(skinComboBox_advan_cw.SelectedIndex);
            tempAdvanceParam.sel_flag = (byte)(skinComboBox_advan_sel.SelectedIndex);
            tempAdvanceParam.session = (byte)(skinComboBox_advan_session.SelectedIndex);
            tempAdvanceParam.target = (byte)(skinComboBox_advan_target.SelectedIndex);
            tempAdvanceParam.QValue = (byte)skinNumericUpDown_advan_Q.Value;
            tempAdvanceParam.rssiValue = byte.Parse(textBox_advan_rssi.Text.Trim());
            reader.SetAdvanceParam(tempAdvanceParam);
        }

        public void FreshAdvanceParam(RfidAdvanceParam advanceParam)
        {
            this.advanceParam = advanceParam;
            initAdvanceParamFlag = true;
            //update the interface
            skinComboBox_advan_region.SelectedIndex = advanceParam.ucRegion;
            skinWaterTextBox_advan_channel.Text = advanceParam.ucChannelIndex.ToString();
            if (0 != advanceParam.ucFreqHoppingFlag)
            {
                skinComboBox_advan_hopping.SelectedIndex = 1;
            }
            else
            {
                skinComboBox_advan_hopping.SelectedIndex = 0;
            }
            if (0 != advanceParam.ucCWFlag)
            {
                skinComboBox_advan_cw.SelectedIndex = 1;
            }
            else
            {
                skinComboBox_advan_cw.SelectedIndex = 0;
            }
            skinComboBox_advan_sel.SelectedIndex = advanceParam.sel_flag;
            if (advanceParam.session < 4)
            {
                skinComboBox_advan_session.SelectedIndex = advanceParam.session;
            }

            if (0 == advanceParam.target)
            {
                skinComboBox_advan_target.SelectedIndex = 0;
            }
            else
            {
                skinComboBox_advan_target.SelectedIndex = 1;
            }
            if (advanceParam.QValue > 15)
            {
                skinNumericUpDown_advan_Q.Value = 0;
            }
            else
            {
                skinNumericUpDown_advan_Q.Value = advanceParam.QValue;
            }
            textBox_advan_rssi.Text = advanceParam.rssiValue.ToString();
        }

        private void skinButton_defualt_Click(object sender, EventArgs e)
        {
            reader.SetDefaultParam();
        }

        private void skinButton_once_Click(object sender, EventArgs e)
        {
            reader.InventoryOnce();
        }

        private void skinButton_reset_Click(object sender, EventArgs e)
        {
            reader.ResetReader();
        }

        private void tabControl_function_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (null == reader)
            {
                return;
            }

            if (tabControl_function.SelectedIndex == 1)
            {
                //query work parameter
                if (initWorkParamFlag == false)
                {
                    reader.QueryWorkingParam();
                }
            }
            else if (tabControl_function.SelectedIndex == 2)
            {
                if (initTransParamFlag == false)
                {
                    reader.QueryTransferParam();
                }
            }
            else if (tabControl_function.SelectedIndex == 3)
            {
                if (initAdvanceParamFlag == false)
                {
                    reader.QueryAdvanceParam();
                }
            }
        }

        private void skinButton_single_Parameter_Query_Click(object sender, EventArgs e)
        {
            reader.QuerySingleParam(0x04);
        }

        private void skinButton_operation_write_Click(object sender, EventArgs e)
        {
            UInt16 startAddr = 0;
            String[] strWrittenContent = null;
            String[] passwords = null;
            byte[] bWrittenBytes = null;
            byte writeLen = 0;
            byte[] passwrod = new byte[4];
            byte membank = 0;

            try
            {
                startAddr = UInt16.Parse(skinWaterTextBox_address.Text);
                strWrittenContent = skinWater_content.Text.Trim().Split(' ');
                passwords = skinWaterTextBox_password.Text.Trim().Split(' ');
                membank = (byte)skinComboBox_membank.SelectedIndex;
                bWrittenBytes = new byte[strWrittenContent.Length];
                writeLen = byte.Parse(skinWaterTextBox_length.Text.Trim());
                for (int iIndex = 0; iIndex < strWrittenContent.Length; iIndex++)
                {
                    bWrittenBytes[iIndex] = byte.Parse(strWrittenContent[iIndex], System.Globalization.NumberStyles.AllowHexSpecifier);
                }

                if (passwords.Length < 4)
                {
                    return;
                }
                for (int index = 0; index < 4; index++)
                {
                    passwrod[index] = byte.Parse(passwords[index], System.Globalization.NumberStyles.AllowHexSpecifier);
                }
            }

            catch (Exception ex)
            {
                parentWindow.AddResultItem(ex.ToString(), MessageType.Error);
                return;
            }
            if ((strWrittenContent.Length % 2) != 0)
            {
                parentWindow.AddResultItem("the length of you input is error", MessageType.Error);
            }
            else
            {
                //writeLen = (byte)(bWrittenBytes.Length / 2);
                reader.WriteTag(membank, startAddr, writeLen, bWrittenBytes, passwrod);
            }
        }

        private void skinButton_operation_read_Click(object sender, EventArgs e)
        {
            UInt16 startAddr = 0;
            String[] passwords = null;
            byte writeLen = 0;
            byte[] passwrod = new byte[4];
            byte membank = 0;

            try
            {
                startAddr = UInt16.Parse(skinWaterTextBox_address.Text);
                passwords = skinWaterTextBox_password.Text.Trim().Split(' ');
                membank = (byte)skinComboBox_membank.SelectedIndex;
                writeLen = byte.Parse(skinWaterTextBox_length.Text.Trim());

                if (passwords.Length < 4)
                {
                    return;
                }
                for (int index = 0; index < 4; index++)
                {
                    passwrod[index] = byte.Parse(passwords[index], System.Globalization.NumberStyles.AllowHexSpecifier);
                }
            }

            catch (Exception ex)
            {
                parentWindow.AddResultItem(ex.ToString(), MessageType.Error);
                return;
            }
            reader.ReadTag(membank, startAddr, writeLen, passwrod);
        }

        public void OnOperationResult(String result)
        {
            skinTextBox_opt_result.Text = result;
        }

        private void skinButton_wiegand_write_Click(object sender, EventArgs e)
        {
            byte write_address = 0;
            UInt32 numberic_data = 0;
            byte[] written_data = new byte[4];
            if (null != transferParam)
            {
                if (transferParam.ucWiegandPosition > 0)
                {
                    write_address = (byte)((transferParam.ucWiegandPosition - 1) / 2  + 2);
                }
                else
                {
                    write_address = 6;
                }
            }
            {
                write_address = 6;
            }
            if(true != UInt32.TryParse(skinWaterTextBox_wiegand_write_data.Text,out numberic_data))
            {
                parentWindow.AddResultItem("Wiegand Written Data:" + skinWaterTextBox_wiegand_write_data.Text + "is illegal.", MessageType.Error);
                return;
            }
            reader.WiegandWriteTag(numberic_data,null);
        }

        private void skinButton_upload_record_Click(object sender, EventArgs e)
        {
            StringBuilder file_path = new StringBuilder();
            DateTime now = DateTime.Now;
            file_path.AppendFormat("{0}_{1}_{2}_{3}_{4}_{5}_record.txt", now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second);
            String filePath = System.AppDomain.CurrentDomain.BaseDirectory.ToString();
            filePath += "\\records\\";
            if (false == System.IO.Directory.Exists(filePath))
            {
                Directory.CreateDirectory(filePath);
            }
            filePath += file_path.ToString();

            record_file_stream = File.Open(filePath, FileMode.OpenOrCreate, FileAccess.Write);
            record_file_stream.Seek(0, SeekOrigin.Begin);
            record_file_stream.SetLength(0);
            record_writer = new StreamWriter(record_file_stream);
            reader.UploadRecord();
        }

		private void skinButton_query_time_Click(object sender, EventArgs e)
        {
            reader.QueryTime();
        }
        private void skinButton_sync_time_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            reader.SetTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second);
        }

        private void button_ext_fresh_Click(object sender, EventArgs e)
        {
            reader.QueryExtParam();
        }

        public void OnRecvQueryExtParam(byte result,RfidExtParam ext_param)
        {
            if ( 0 != result)
            {
                //(Form1)(this.Parent).AddResultItem("查询拓展参数失败", MessageType.Error);
                ((Form1)(this.Parent.Parent)).AddResultItem("查询拓展参数失败", MessageType.Error);
                return;
            }
            if(0 != (ext_param.ucRelayMode & 1))
            {
                checkBox_relay1_auto.Checked = true;
            }
            if (0 != (ext_param.ucRelayMode & 2))
            {
                checkBox_relay2_auto.Checked = true;
            }
            textBox_relay_time.Text = ext_param.ucRelayTime.ToString();

            if(ext_param.ucVerifyFlag != 0)
            {
                checkBox_tag_verify.Checked = true;
            }
            else
            {
                checkBox_tag_verify.Checked = false;
            }

            textBox_tag_verify_pwd.Text = ext_param.usVerifyPwd.ToString("X4");
        }

        private void button_relay_set_Click(object sender, EventArgs e)
        {
            RfidExtParam ext_param = new RfidExtParam();

            if (textBox_tag_verify_pwd.Text.Trim().Length > 4)
            {
                ((Form1)(this.Parent.Parent)).AddResultItem("密码不能超过4个16进制字符", MessageType.Error);
                return;
            }

            if ( checkBox_relay1_auto.Checked == true)
            {
                ext_param.ucRelayMode = (byte)(ext_param.ucRelayMode | 0x01);
            }

            if (checkBox_relay2_auto.Checked == true)
            {
                ext_param.ucRelayMode = (byte)(ext_param.ucRelayMode | 0x02);
            }
            ext_param.ucRelayTime = byte.Parse(textBox_relay_time.Text.ToString());

            if(checkBox_tag_verify.Checked)
            {
                ext_param.ucVerifyFlag = 1;
            }
            else
            {
                ext_param.ucVerifyFlag = 0;
            }
            ext_param.usVerifyPwd = UInt16.Parse(textBox_tag_verify_pwd.Text.ToString(), System.Globalization.NumberStyles.AllowHexSpecifier);

            reader.SetExtParam(ext_param);
        }

        private void button_audio_play_Click(object sender, EventArgs e)
        {
            reader.AudioPlay(textBox_audio_text.Text.Trim());
        }

        private void button_relay_control_Click(object sender, EventArgs e)
        {
            int op_index = comboBox_op_index.SelectedIndex;
            byte relay_time = byte.Parse(textBox_relay_ctrl_time.Text.Trim());
            switch(op_index)
            {
                case 0: //打开继电器1
                    reader.RelayOperation(1, 1, relay_time);
                    break;
                case 1: //关闭继电器1
                    reader.RelayOperation(1, 0, relay_time);
                    break;
                case 2: //打开继电器2
                    reader.RelayOperation(2, 1, relay_time);
                    break;
                case 3: //关闭继电器2
                    reader.RelayOperation(2, 0, relay_time);
                    break;
                case 4: //1,2一起开
                    reader.RelayOperation(3, 0, relay_time);
                    break;
                case 5: //1,2一起关
                    reader.RelayOperation(3, 0, relay_time);
                    break;
            }
        }

        
        private void button_audio_set_vol_Click(object sender, EventArgs e)
        {
            reader.AudioSetOfflineContext(textBox_audio_text.Text.Trim());
        }

        private void skinButton_tag_lock_Click(object sender, EventArgs e)
        {
            byte[] passwrod = new byte[4];
            string[] passwords = null;
            byte lock_index = (byte)comboBox_lock_type.SelectedIndex;
            passwords = skinWaterTextBox_password.Text.Trim().Split(' ');
            if (passwords.Length < 4)
            {
                return;
            }
            for (int index = 0; index < 4; index++)
            {
                passwrod[index] = byte.Parse(passwords[index], System.Globalization.NumberStyles.AllowHexSpecifier);
            }
            reader.LockTag(lock_index, passwrod);


        }

        private void skinButton_kill_tag_Click(object sender, EventArgs e)
        {
            byte[] passwrod = new byte[4];
            byte[] killpassword = new byte[4];
            string[] passwords = null;
            passwords = skinWaterTextBox_password.Text.Trim().Split(' ');
            if (passwords.Length < 4)
            {
                return;
            }
            for (int index = 0; index < 4; index++)
            {
                passwrod[index] = byte.Parse(passwords[index], System.Globalization.NumberStyles.AllowHexSpecifier);
                killpassword[index] = byte.Parse(passwords[index], System.Globalization.NumberStyles.AllowHexSpecifier);
            }
            reader.KillTag(passwrod,killpassword);
        }

        private void skinButton_dev_query_Click(object sender, EventArgs e)
        {
            reader.QuerySingleParam(0xF0);
        }

        private void skinButton_dev_set_Click(object sender, EventArgs e)
        {
            if (skinWaterTextBox_dev_num.Text.Length > 12)
            {
                ((Form1)(this.Parent.Parent)).AddResultItem("您输入的设备号不能超过12个数字或者字母", MessageType.Error);
                return;
            }
            byte[] queryNum = Encoding.UTF8.GetBytes(skinWaterTextBox_dev_num.Text.Trim());
            byte[] dev_ser = new byte[queryNum.Length + 1];
            dev_ser[0] = 0;
            Array.Copy(queryNum, 0, dev_ser, 1, queryNum.Length);
            reader.SetSingleParam(0xF0, dev_ser);
        }

        private void skinButton_tag_verify_Click(object sender, EventArgs e)
        {
            reader.AddVerifyToTag();
        }

        public void AutoWriteWiegandTag()
        {
            UInt32 numberic_data = 0;
            byte[] written_data = new byte[4];
            if (true != UInt32.TryParse(textBox_auto_wiegand_write_text.Text, out numberic_data))
            {
                parentWindow.AddResultItem(textBox_auto_wiegand_write_text.Text+"是一个错误的韦根卡号。", MessageType.Error);
                return;
            }
            reader.WiegandWriteTag(numberic_data, null);
        }

        public void OnRecvAutoWriteRsp(int status)
        {
            UInt32 numberic_data = 0;

            if(0 == status)
            {
                parentWindow.AddResultItem("成功写入数据:"+textBox_auto_wiegand_write_text.Text, MessageType.Normal);
                if (true != UInt32.TryParse(textBox_auto_wiegand_write_text.Text, out numberic_data))
                {
                    parentWindow.AddResultItem(textBox_auto_wiegand_write_text.Text + "是一个错误的韦根卡号。", MessageType.Error);
                    return;
                }
                numberic_data += 1;
                textBox_auto_wiegand_write_text.Text = numberic_data.ToString();
            }
        }

        public byte[] StringToHex(String str,out int hexlen)
        {
            hexlen = 0;
            byte[] hexBytes = new byte[(str.Length / 2) + 1];
            int interalLen = 0;
            int pos = 0;
            char[] strChars = str.ToCharArray();
            try
            {
                for (int index = 0; index < strChars.Length; index++)
                {
                    if (strChars[index] == ' ')
                    {
                        if (interalLen != 0)
                        {
                            //有非法字符
                            return null;
                        }
                        continue;
                    }
                    else if (strChars[index] >= '0' && strChars[index] <= '9')
                    {
                        if (interalLen == 0)
                        {
                            hexBytes[pos] = (byte)(strChars[index] - '0');
                            interalLen = 1;
                        }
                        else
                        {
                            hexBytes[pos] = (byte)(hexBytes[pos] << 4);
                            hexBytes[pos] += (byte)(strChars[index] - '0');
                            pos++;
                            interalLen = 0;
                        }
                    }
                    else if (strChars[index] >= 'a' && strChars[index] <= 'f')
                    {
                        if (interalLen == 0)
                        {
                            hexBytes[pos] = (byte)(strChars[index] - 'a' + 10);
                            interalLen = 1;
                        }
                        else
                        {
                            hexBytes[pos] = (byte)(hexBytes[pos] << 4);
                            hexBytes[pos] += (byte)(strChars[index] - 'a' + 10);
                            pos++;
                            interalLen = 0;
                        }
                    }
                    else if (strChars[index] >= 'A' && strChars[index] <= 'F')
                    {
                        if (interalLen == 0)
                        {
                            hexBytes[pos] = (byte)(strChars[index] - 'A' + 10);
                            interalLen = 1;
                        }
                        else
                        {
                            hexBytes[pos] = (byte)(hexBytes[pos] << 4);
                            hexBytes[pos] += (byte)(strChars[index] - 'A' + 10);
                            pos++;
                            interalLen = 0;
                        }
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch(Exception)
            {
                hexlen = 0;
                return null;
            }
            hexlen = pos;
            return hexBytes;
        }

        public void AutoWriteHexTag()
        {
            byte startAddr = 0;
            String[] strWrittenContent = null;
            String[] passwords = null;
            byte[] bWrittenBytes = null;
            byte writeLen = 0;
            byte[] passwrod = new byte[4];
            byte membank = 0;

            try
            {
                startAddr = 0x02;
                strWrittenContent = textBox_auto_hex_write_text.Text.Trim().Split(' ');
                passwords = skinWaterTextBox_password.Text.Trim().Split(' ');
                membank = 0x01;
                bWrittenBytes = new byte[strWrittenContent.Length];
                for (int iIndex = 0; iIndex < strWrittenContent.Length; iIndex++)
                {
                    bWrittenBytes[iIndex] = byte.Parse(strWrittenContent[iIndex], System.Globalization.NumberStyles.AllowHexSpecifier);
                }
                writeLen = (byte)(strWrittenContent.Length / 2);
                if (passwords.Length < 4)
                {
                    return;
                }
                for (int index = 0; index < 4; index++)
                {
                    passwrod[index] = byte.Parse(passwords[index], System.Globalization.NumberStyles.AllowHexSpecifier);
                }
            }
            catch (Exception ex)
            {
                parentWindow.AddResultItem(ex.ToString(), MessageType.Error);
                return;
            }
            if ((strWrittenContent.Length % 2) != 0)
            {
                parentWindow.AddResultItem("要写入的卡号长度单位必须是2的整数倍，用空格隔开。", MessageType.Error);
            }
            else
            {
                //writeLen = (byte)(bWrittenBytes.Length / 2);
                reader.WriteEpc(membank, startAddr, writeLen, bWrittenBytes, passwrod);
            }
        }

        public void OnRecvAutoWriteHexTag(int status)
        {
            String[] strWrittenContent = null;
            byte[] bWrittenBytes = null;
            byte writeLen = 0;
            byte[] passwrod = new byte[4];
            StringBuilder changeStr = new StringBuilder();
            parentWindow.AddResultItem("成功写入数据：" + textBox_auto_hex_write_text.Text.Trim(), MessageType.Normal);
            try
            {
                strWrittenContent = textBox_auto_hex_write_text.Text.Trim().Split(' ');
                bWrittenBytes = new byte[strWrittenContent.Length];
                writeLen = byte.Parse(skinWaterTextBox_length.Text.Trim());
                for (int iIndex = 0; iIndex < strWrittenContent.Length; iIndex++)
                {
                    bWrittenBytes[iIndex] = byte.Parse(strWrittenContent[iIndex], System.Globalization.NumberStyles.AllowHexSpecifier);
                }

                //从底部开始加1
                for(int index = strWrittenContent.Length-1;index>=0;index--)
                {
                    if(bWrittenBytes[index] == 0xFF)
                    {
                        bWrittenBytes[index] = 0;
                        continue;
                    }
                    else
                    {
                        bWrittenBytes[index] = (byte)(bWrittenBytes[index] + 1);
                        break;
                    }
                }
                changeStr.Clear();
                for(int index = 0; index < strWrittenContent.Length;index++)
                {
                    changeStr.Append(bWrittenBytes[index].ToString("X2") + " ");
                }
                textBox_auto_hex_write_text.Text = changeStr.ToString().Trim();
            }
            catch(Exception ex)
            {
                parentWindow.AddResultItem(ex.ToString(), MessageType.Error);
                return;
            }
        }

        public int GetCurTagPageIndex()
        {
            return tabControl_function.SelectedIndex;
        }
        //定时器的处理函数
        public void HandleWriteTagTimer(object source, System.Timers.ElapsedEventArgs e)
        {
            if (autoWriteMode == 1)
            {
                AutoWriteHexTag();
            }
            else if (autoWriteMode == 2)
            {
                AutoWriteWiegandTag();
            }
        }

        private void button_auto_write_hex_Click(object sender, EventArgs e)
        {
            if(checkBox_auto_write_increse.Checked)
            {
                autoIncreseFlag = 1;
            }
            else
            {
                autoIncreseFlag = 0;
            }
            if(!checkBox_auto_write_flag.Checked)
            {
                AutoWriteHexTag();
                return;
            }
            if(autoWriteMode == 0)
            {
                autoWriteMode = 1;
                ButtonDisableOnWrite(1);
                
                button_auto_write_hex.Text = "停止";
                timer.Start();
            }
            else
            {
                timer.Stop();
                autoWriteMode = 0;
                button_auto_write_hex.Text = "Hex写卡";
                ButtonEnableWrite();
            }
        }

        private void button_auto_write_wiegand_Click(object sender, EventArgs e)
        {
            if (checkBox_auto_write_increse.Checked)
            {
                autoIncreseFlag = 1;
            }
            else
            {
                autoIncreseFlag = 0;
            }

            if (!checkBox_auto_write_flag.Checked)
            {
                AutoWriteWiegandTag();
                return;
            }
            if (autoWriteMode == 0)
            {
                autoWriteMode = 2;
                button_auto_write_hex.Enabled = false;
                checkBox_auto_write_increse.Enabled = false;
                checkBox_auto_write_flag.Enabled = false;
                button_auto_write_wiegand.Text = "停止";
                ButtonDisableOnWrite(2);
                timer.Start();
            }
            else
            {
                timer.Stop();
                autoWriteMode = 0;
                button_auto_write_wiegand.Text = "韦根写卡";
                ButtonEnableWrite();
            }
        }

        private void button_usbdata_query_Click(object sender, EventArgs e)
        {
            reader.QueryUsbInfoParam();
        }

        public void OnRecvQueryUsbData(byte interfacetype,byte usbDataProto,byte usbEnterFlag)
        {
            if (interfacetype == 7)
            {
                //USB键盘输出
                radioButton_USB_HID.Checked = true;
            }
            else if (interfacetype == 8)
            {
                radioButton_USB_COM.Checked = true;
            }
            else
            {
                radioButton_USB_HID.Checked = false;
                radioButton_USB_COM.Checked = false;
            }
            if (usbDataProto < comboBox_usbdata_proto.Items.Count)
            {
                comboBox_usbdata_proto.SelectedIndex = usbDataProto;
            }
            else
            {
                comboBox_usbdata_proto.SelectedIndex = -1;
            }

            if (0 != usbEnterFlag)
            {
                checkBox_usbdata_enter_flag.Checked = true;
            }
            else
            {
                checkBox_usbdata_enter_flag.Checked = false;
            }
            parentWindow.AddResultItem("成功查询USB参数", MessageType.Normal);
        }

        private void button_usbdata_sset_Click(object sender, EventArgs e)
        {
            byte usbProto = 0;
            byte enterflag = 0;
            byte interfaceType = 0;
            if (radioButton_USB_COM.Checked)
            {
                interfaceType = 8;
            }
            else if (radioButton_USB_HID.Checked)
            {
                interfaceType = 7;
            }
            else
            {
                return;
            }
            if (-1 == comboBox_usbdata_proto.SelectedIndex)
            {
                usbProto = 0;
            }
            else
            {
                usbProto = (byte)comboBox_usbdata_proto.SelectedIndex;
            }
            
            if (checkBox_usbdata_enter_flag.Checked)
            {
                enterflag = 1;
            }
            else
            {
                enterflag = 0;
            }
            reader.SetUsbInfo(interfaceType,usbProto, enterflag);
        }

        public void OnRecvQueryDataFlag(UInt16 dataFlag,byte dataFormat)
        {
            if ( 0 != (dataFlag & 0x01))
            {
                checkBoxDataFlag_RSSI.Checked = true;
            }
            else 
            {
                checkBoxDataFlag_RSSI.Checked = false;
            }

            if (0 != (dataFlag & 0x02))
            {
                checkBoxDataFlag_DevNo.Checked = true;
            }
            else
            {
                checkBoxDataFlag_DevNo.Checked = false;
            }

            if (0 != (dataFlag & 0x04))
            {
                checkBoxDataFlag_ANT.Checked = true;
            }
            else
            {
                checkBoxDataFlag_ANT.Checked = false;
            }

            if (dataFormat < comboBox_dataflag_format.Items.Count)
            {
                comboBox_dataflag_format.SelectedIndex = dataFormat;
            }
            else
            {
                comboBox_dataflag_format.SelectedIndex = 0;
            }

            parentWindow.AddResultItem("成功查询数据参数", MessageType.Normal);
        }

        
        private void button_dataflag_query_Click(object sender, EventArgs e)
        {
            reader.QUeryDatainfoFlag();
        }

        private void button_dataflag_set_Click(object sender, EventArgs e)
        {
            UInt16 dataFlag = 0;
            byte dataformat = 0;
            if (checkBoxDataFlag_RSSI.Checked)
            {
                dataFlag |= 1;
            }
           
            if (checkBoxDataFlag_DevNo.Checked)
            {
                dataFlag |= 2;
            }

            if (checkBoxDataFlag_ANT.Checked)
            {
                dataFlag = 4;
            }
            if (comboBox_dataflag_format.SelectedIndex > 0)
            {
                dataformat = (byte)comboBox_dataflag_format.SelectedIndex;
            }

            reader.SetDataInfoFlag(dataFlag, dataformat);
        }

        private void button_ext_add_verify_Click(object sender, EventArgs e)
        {
            reader.AddVerifyToTag();
        }


        public void HandleAutoAddVerfiyTimer(object source, System.Timers.ElapsedEventArgs e)
        {
            reader.AddVerifyToTag();
        }

        private void button_ext_auto_verify_Click(object sender, EventArgs e)
        {
            if (mAutoAddVerfiyFlag == false)
            {
                button_ext_auto_add_verify.Text = "停止校验";
                mAutoAddVerfiyTimer.Start();
                mAutoAddVerfiyFlag = true;
            }
            else
            {
                button_ext_auto_add_verify.Text = "自动校验";
                mAutoAddVerfiyTimer.Stop();
                mAutoAddVerfiyFlag = false;
            }
        }


        private void button_ex_modbus_query_Click(object sender, EventArgs e)
        {
            reader.QueryModebusParam();
        }

        public void OnRecvQueryModbusParam(byte tagNum, byte unionSize, byte startAddr, byte clearFlag,int modbusproto)
        {
            numericUpDown_ex_modbus_tag_num.Value = tagNum;
            numericUpDown_ex_modbus_union_size.Value = unionSize;
            numericUpDown_ex_modbus_startaddr.Value = startAddr;
            if (clearFlag != 0)
            {
                checkBox_ex_modbus_clear_flag.Checked = true;
            }
            else
            {
                checkBox_ex_modbus_clear_flag.Checked = false;
            }

            if (modbusproto >= 0)
            {
                comboBox_ex_modbus_proto.SelectedIndex = modbusproto;
            }
            else
            {
                comboBox_ex_modbus_proto.SelectedIndex = -1;
            }
            parentWindow.AddResultItem("成功查询Modbus参数", MessageType.Normal);

        }

        private void button_ex_modbus_set_Click(object sender, EventArgs e)
        {
            byte tagNum = 0;
            byte unionsize = 0;
            byte startaddr = 0;
            byte clearFlag = 0;
            int modbusProto = 0;
            tagNum = (byte)numericUpDown_ex_modbus_tag_num.Value;
            unionsize = (byte)numericUpDown_ex_modbus_union_size.Value;
            startaddr = (byte)numericUpDown_ex_modbus_startaddr.Value;
            if (checkBox_ex_modbus_clear_flag.Checked)
            {
                clearFlag = 1;
            }
            else
            {
                clearFlag = 0;
            }
            modbusProto = comboBox_ex_modbus_proto.SelectedIndex;
            if (modbusProto == -1)
            {
                parentWindow.AddResultItem("请选择modbus的协议格式", MessageType.Error);
                return;
            }
            reader.SetModbusParam(tagNum, unionsize, startaddr, clearFlag,(byte)modbusProto);
        }

        private void skinComboBox_transfer_mode_SelectedIndexChanged(object sender, EventArgs e)
        {
            skinComboBox_sub_protocol.Items.Clear();
            switch (skinComboBox_transfer_mode.SelectedIndex)
            {
                case 0: //RS232&485
                    skinComboBox_sub_protocol.Items.Add("Normal(Deafault)");
                    break;
                case 1: //RS485
                    skinComboBox_sub_protocol.Items.Add("Normal(Deafault)");
                    skinComboBox_sub_protocol.Items.Add("Syris");
                    skinComboBox_sub_protocol.Items.Add("Modbus Rtu");
                    skinComboBox_sub_protocol.Items.Add("Modbus ASCII");
                    break;
                case 2:
                    skinComboBox_sub_protocol.Items.Add("Wiegand26");
                    skinComboBox_sub_protocol.Items.Add("Wiegand32");
                    skinComboBox_sub_protocol.Items.Add("Wiegand34");
                    break;
                case 3:
                    skinComboBox_sub_protocol.Items.Add("Normal(Deafault)");
                    break;
                case 4: //RJ45
                    skinComboBox_sub_protocol.Items.Add("TCP Server");
                    skinComboBox_sub_protocol.Items.Add("TCP Client");
                    skinComboBox_sub_protocol.Items.Add("UDP");
                    skinComboBox_sub_protocol.Items.Add("UDP Server");
                    break;
                case 5: //4G
                    skinComboBox_sub_protocol.Items.Add("TCP Client");
                    skinComboBox_sub_protocol.Items.Add("UDP");
                    skinComboBox_sub_protocol.Items.Add("HTTP Client");
                    break;
            }
        }

        private void button_write_file_choose_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            {
                openFileDialog.Title = "";
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();  // 设置初始目录
                //"excel files (*.xls)|*.xls|txt files (*.txt)|*.txt|excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                openFileDialog.Filter = "excel files (*.xls,*.xlsx)|*.xls;*.xlsx|txt files (*.txt)|*.txt"; // 设置文件过滤器
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // 用户点击了打开按钮，返回选择的文件路径
                    textBox_write_file_path.Text = openFileDialog.FileName.Trim();
                    mWriteFilePath = textBox_write_file_path.Text;
                    numericUpDown_write_file_row.Value = 1;
                }
            }
        }

        private void button_write_file_hand_Click(object sender, EventArgs e)
        {
            mWriteFilePath = textBox_write_file_path.Text.Trim();
            mWriteStartLine = (int)numericUpDown_write_file_row.Value;
            String fileType;
            if (mWriteFilePath.Length == 0)
            {
                parentWindow.AddResultItem("请选择要加载的写入文件", MessageType.Error);
                return;
            }

            try
            {
                if (mFileWriteStream != null)
                {
                    mFileWriteStream.Close();
                    mFileWriteStream = null;
                }
                mFileWriteStream = new FileStream(mWriteFilePath, FileMode.Open, FileAccess.Read);
            }
            catch(Exception)
            {
                parentWindow.AddResultItem("打开文件失败.",MessageType.Error);
                return;
            }
            fileType = Path.GetExtension(mWriteFilePath);
            if (fileType.Equals(".xls"))
            {
                mFileWorkBook = new HSSFWorkbook(mFileWriteStream);
            }
            else if (fileType.Equals(".xlsx"))
            {
                mFileWorkBook = new XSSFWorkbook(mFileWriteStream);
            }

            mFileSheet = mFileWorkBook.GetSheetAt(0);

            mFileWriteMode = 1;
            mFileWriteTimer.Start();
        }

        private void button_write_file_reload_Click(object sender, EventArgs e)
        {
            int dstRow = 0;
            String fileType;
            if (textBox_write_file_path.Text.Trim().Length == 0)
            {
                parentWindow.AddResultItem("文件路径为空，不能获取该行数据",MessageType.Error);
                return;
            }
            mWriteFilePath = textBox_write_file_path.Text.Trim();
            dstRow =(int)numericUpDown_write_file_row.Value;
            mWriteStartLine = dstRow;

            try
            {
                IWorkbook workbook;
                FileStream fs = new FileStream(mWriteFilePath, FileMode.Open, FileAccess.Read);
                fileType = Path.GetExtension(mWriteFilePath);
                if (fileType.Equals(".xls"))
                {
                    workbook = new HSSFWorkbook(fs);
                }
                else if (fileType.Equals(".xlsx"))
                {
                    workbook = new XSSFWorkbook(fs);
                }
                else
                {
                    fs.Close();
                    return;
                }
                IRow row;
                ICell cell;
                ISheet wSheet = workbook.GetSheetAt(0);

                row = wSheet.GetRow(dstRow - 1);
                if (null == row)
                {
                    parentWindow.AddResultItem("第"+dstRow+"行不存在，请检查",MessageType.Error);
                    fs.Close();
                    return;
                }
                cell = row.GetCell(0);

                //格式化
                String valueStr = cell.StringCellValue.Trim(); 
                int hexlen = 0;
                byte[] hexdata = StringToHex(valueStr, out hexlen);
                if (hexlen == 0)
                {
                    parentWindow.AddResultItem("第" + dstRow + "行数据为非法数据，数据内容：" + valueStr, MessageType.Error);
                    textBox_write_file_data.Text = "";
                }
                else
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int index = 0; index < hexlen;index++)
                    {
                        stringBuilder.AppendFormat("{0:X2} ", hexdata[index]);
                    }
                    textBox_write_file_data.Text = stringBuilder.ToString().Trim();
                    parentWindow.AddResultItem("读取第" + dstRow + "行数据成功，数据内容：" + stringBuilder.ToString().Trim(), MessageType.Normal);
                }
                fs.Close();
            }
            catch(Exception)
            {
                parentWindow.AddResultItem("打开文件失败,请检查文件是否已经被其它程序打开", MessageType.Error);
            }
        }
        
        public int ArrayByteCompare(byte[] array1, byte[] array2,int compareLen)
        {
            int result = 0;
            if ( (array1.Length < compareLen) || (array2.Length < compareLen))
            {
                return -1;
            }

            for (int index = 0; index < compareLen; index++)
            {
                if (array1[index] != array2[index])
                {
                    return -1;
                }
            }
            return result;
        }
        public void OnRecvIdentify(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, byte tlvCount)
        {
            if (tlvCount != 0)
            {
                //如果数据和上次写入的一样则不用写入
                if ((mLastWriteDataLen == tlvItems[0]._tlvLen) &&
                    (0 == ArrayByteCompare(mLastWriteData, tlvItems[0]._tlvValue,mLastWriteDataLen)))
                {
                    //与上次写的一样
                    StringBuilder sb = new StringBuilder();
                    for(int index = 0; index < mLastWriteDataLen;index++)
                    {
                        sb.AppendFormat("{0:X2} ", mLastWriteData[index]);
                    }
                    parentWindow.AddResultItem("此标签["+ sb.ToString().Trim()+"]与之前写入的数据一样，请更换标签",MessageType.Error);
                }
                else
                {
                    int result = TimerFileWrite();
                    if (0 != result)
                    {
                        ButtonEnableWrite();
                        mFileWriteStream.Close();
                        mFileWriteStream = null;
                        mFileWriteTimer.Stop();
                    }
                }
            }
            if (mFileWriteMode <= 1)
            {
                if (mFileWriteStream != null)
                {
                    mFileWriteStream.Close();
                    mFileWriteStream = null;
                }
                mFileWriteTimer.Stop();
            }
        }

        public void OnRecvFileWriteEpc(int status)
        {
            byte[] hexData = null;
            int hexLen = 0;
            parentWindow.AddResultItem("成功写入第" + mWriteStartLine + "行数据["+ textBox_write_file_data.Text.Trim()+ "]", MessageType.Normal);
 
            do
            {
                mWriteStartLine += 1;
                numericUpDown_write_file_row.Value = mWriteStartLine;
                mFileRow = mFileSheet.GetRow(mWriteStartLine - 1);
                if (mFileRow == null)
                {
                    parentWindow.AddResultItem("第" + mWriteStartLine.ToString() + "行在文件中不存在,文件读取结束", MessageType.Normal);
                    textBox_write_file_data.Text = "";
                    ButtonEnableWrite();
                    if (mFileWriteStream != null)
                    {
                        mFileWriteStream.Close();
                        mFileWriteStream = null;
                    }
                    mFileWriteTimer.Stop();
                }
                mFileCell = mFileRow.GetCell(0);


                //格式化
                hexData = StringToHex(mFileCell.StringCellValue.Trim(), out hexLen);
                if (hexLen == 0)
                {
                    parentWindow.AddResultItem("第" + mWriteStartLine + "行检测到错误的数据格式[" + mFileCell.StringCellValue.Trim() + "]，切换到第" + (mWriteStartLine + 1) + "行数据", MessageType.Error);
                    mWriteStartLine++;
                    continue;
                }
                else if (hexLen % 2 != 0)
                {
                    parentWindow.AddResultItem("第" + mWriteStartLine + "行检测到错误的数据格式[" + mFileCell.StringCellValue.Trim() + "]的长度为" + hexLen.ToString() + "(必须是2的整数倍)切换到第" + (mWriteStartLine + 1) + "行数据", MessageType.Error);
                    mWriteStartLine++;
                    continue;
                }
                break;
            }
            while (true);

            StringBuilder stringBuilder = new StringBuilder();
            for (int index = 0; index < hexLen;index++)
            {
                stringBuilder.AppendFormat("{0:X2}",hexData[index]);
            }
            textBox_write_file_data.Text = stringBuilder.ToString().Trim();
        }

        public int TimerFileWrite()
        {
            byte[] hexData = null;
            int hexLen = 0;
            do
            {
                mFileRow = mFileSheet.GetRow(mWriteStartLine - 1);
                if (mFileRow == null)
                {
                    parentWindow.AddResultItem("第" + mWriteStartLine.ToString() + "行在文件中不存在", MessageType.Normal);
                    return 1;
                }
                mFileCell = mFileRow.GetCell(0);
                

                //格式化
                hexData = StringToHex(mFileCell.StringCellValue.Trim(), out hexLen);
                if (hexLen == 0)
                {
                    parentWindow.AddResultItem("第" + mWriteStartLine + "行检测到错误的数据格式["+ mFileCell.StringCellValue.Trim()+"]，切换到第"+(mWriteStartLine+1)+"行数据", MessageType.Error);
                    mWriteStartLine++;
                    continue;
                }
                else if (hexLen % 2 != 0)
                {
                    parentWindow.AddResultItem("第" + mWriteStartLine + "行检测到错误的数据格式[" + mFileCell.StringCellValue.Trim() + "]的长度为"+hexLen.ToString() + "(必须是2的整数倍)切换到第"+(mWriteStartLine+1)+"行数据", MessageType.Error);
                    mWriteStartLine++; 
                    continue;
                }
                break;
            }
            while (true);

            StringBuilder stringBuilder = new StringBuilder();
            for (int index = 0; index < hexLen;index++)
            {
                stringBuilder.AppendFormat("{0:X2} ", hexData[index]);
            }
            textBox_write_file_data.Text = stringBuilder.ToString().Trim();


            //转化为数组
            if ( (hexData != null) && (hexLen != 0) && (hexLen % 2 == 0))
            {
                Array.Copy(hexData, 0, mLastWriteData, 0, hexLen);
                mLastWriteDataLen = (byte)hexLen;
                reader.WriteEpc(0x01, 0x02, (byte)(hexLen/2), hexData, null);
                return 0;
            }
            parentWindow.AddResultItem("第" + mWriteStartLine + "行检测到错误的数据，停止写卡", MessageType.Error);
            return 1;
        }
        public void HandleFileWriteTagTimer(object source, System.Timers.ElapsedEventArgs e)
        {
            reader.GetEpcData();
        }

        private void ButtonDisableOnWrite(int mode)
        {
            numericUpDown_write_file_row.Enabled = false;
            button_write_file_reload.Enabled = false;
            button_write_file_hand.Enabled = false;
            checkBox_auto_write_increse.Enabled = false;
            checkBox_auto_write_flag.Enabled = false;
            textBox_auto_hex_write_text.Enabled = false;
            textBox_auto_wiegand_write_text.Enabled = false;
            if (mode == 1)
            {
                //hex自动写入模式
                button_auto_write_wiegand.Enabled = false;
                button_write_file_auto.Enabled = false;
            }
            else if (mode == 2)
            {
                //Wiegand自动写入模式
                button_auto_write_hex.Enabled = false;
                button_write_file_auto.Enabled = false;
            }
            else if (mode == 3)
            {
                button_auto_write_wiegand.Enabled = false;
                button_auto_write_hex.Enabled = false;
            }

        }


        private void ButtonEnableWrite()
        {
            numericUpDown_write_file_row.Enabled = true;
            button_write_file_reload.Enabled = true;
            button_write_file_hand.Enabled = true;
            button_auto_write_wiegand.Enabled = true;
            button_write_file_auto.Enabled = true;
            button_auto_write_hex.Enabled = true;
            checkBox_auto_write_increse.Enabled = true;
            checkBox_auto_write_flag.Enabled = true;
            textBox_auto_hex_write_text.Enabled = true;
            textBox_auto_wiegand_write_text.Enabled = true;
        }
        private void button_write_file_auto_Click(object sender, EventArgs e)
        {
            mWriteFilePath = textBox_write_file_path.Text.Trim();
            mWriteStartLine = (int)numericUpDown_write_file_row.Value;
            String fileType;

            if (mFileWriteMode == 2)
            {
                button_write_file_auto.Text = "自动写卡";
                ButtonEnableWrite();
                mFileWriteTimer.Stop();
                mFileWriteStream.Close();
            }

            if (mWriteFilePath.Length == 0)
            {
                parentWindow.AddResultItem("请选择要加载的写入文件", MessageType.Error);
                return;
            }

            try
            {
                mFileWriteStream = new FileStream(mWriteFilePath, FileMode.Open, FileAccess.Read);
            }
            catch (Exception)
            {
                parentWindow.AddResultItem("打开文件失败.", MessageType.Error);
                return;
            }
            fileType = Path.GetExtension(mWriteFilePath);
            if (fileType.Equals(".xls"))
            {
                mFileWorkBook = new HSSFWorkbook(mFileWriteStream);
            }
            else if (fileType.Equals(".xlsx"))
            {
                mFileWorkBook = new XSSFWorkbook(mFileWriteStream);
            }

            mFileSheet = mFileWorkBook.GetSheetAt(0);

            mFileWriteMode = 2;
            ButtonDisableOnWrite(3);
            button_write_file_auto.Text = "停止";
            mFileWriteTimer.Start();
        }
    }

    public class TagItem
    {
        public int mIndex;
        public ListViewItem viewItem = null;
        public int mReadTimes;
        //public String mStrTag;

        public TagItem()
        {
            mIndex = 0;
            mReadTimes = 1;
            //mStrTag = "";
            viewItem = null;
        }

        public void Increase()
        {
            mReadTimes++;
        }
    }
}
