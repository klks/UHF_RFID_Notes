﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RfidSdk;

namespace RfidReader
{
    class RfidRspNotify : RfidSdk.RfidReaderRspNotify
    {
        Form1 mainWindows;
        public RfidRspNotify(Form1 winForm)
        {
            this.mainWindows = winForm;
        }

        void RfidReaderRspNotify.OnRecvResetRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReaderResetRsp(reader, result);
                }));
            }
            else
            {
                mainWindows.OnRecvReaderResetRsp(reader,result);
            }
        }

        void RfidReaderRspNotify.OnRecvSetFactorySettingRsp(RfidSdk.RfidReader reader, byte result)
        {
            
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReaderRestorFactorySettingRsp(reader, result);
                }));
            }
            else
            {
                mainWindows.OnRecvReaderRestorFactorySettingRsp(reader, result);
            }
        }

        void RfidReaderRspNotify.OnRecvStartInventoryRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("Start to inventory tags.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("Fail to inventory tags.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("Start to inventory tags.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("Fail to inventory tags.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvStopInventoryRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (result==0)
                    {
                        mainWindows.AddResultItem("Stop to inventory tags.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("Stop to inventory tags.", MessageType.Normal);
                    }
                }));
            }
            else
            {
                if (result == 0)
                {
                    mainWindows.AddResultItem("Stop to inventory tags.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("Stop to inventory tags.", MessageType.Normal);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvDeviceInfoRsp(RfidSdk.RfidReader reader, byte[] firmwareVersion, byte deviceType)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReaderDeviceInfoRsp(firmwareVersion, deviceType);
                }));
            }
            else
            {
                mainWindows.OnRecvReaderDeviceInfoRsp(firmwareVersion,deviceType);
            }
        }

        void RfidReaderRspNotify.OnRecvSetWorkParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("设置工作参数成功.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("设置工作参数失败.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("Successfully set working parameters.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("Fail to set working parameters.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvQueryWorkParamRsp(RfidSdk.RfidReader reader, byte result, RfidWorkParam workParam)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReaderQueryWorkParamRsp(reader,result,workParam);
                }));
            }
            else
            {
                mainWindows.OnRecvReaderQueryWorkParamRsp(reader, result, workParam);
            }
        }

        void RfidReaderRspNotify.OnRecvSetTransmissionParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("Success to set transmission parameters.", MessageType.Normal);
                        mainWindows.BackToConnectMode();                
                    }
                    else
                    {
                        mainWindows.AddResultItem("Fail to stop transmission parameters.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("Success to set transmission parameters.", MessageType.Normal);
                    mainWindows.BackToConnectMode();
                }
                else
                {
                    mainWindows.AddResultItem("Fail to stop transmission parameters.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvQueryTransmissionParamRsp(RfidSdk.RfidReader reader, byte result, RfidTransmissionParam transmissiomParam)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReaderQueryTransmissionRsp(reader, result, transmissiomParam);
                }));
            }
            else
            {
                mainWindows.OnRecvReaderQueryTransmissionRsp(reader, result, transmissiomParam);
            }
        }

        void RfidReaderRspNotify.OnRecvSetAdvanceParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("Success to set advance parameters.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("Fail to stop advance parameters.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("Success to set advance parameters.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("Fail to stop advance parameters.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvQueryAdvanceParamRsp(RfidSdk.RfidReader reader, byte result, RfidAdvanceParam advanceParam)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReaderQueryAdvanceRsp(reader, result, advanceParam);
                }));
            }
            else
            {
                mainWindows.OnRecvReaderQueryAdvanceRsp(reader, result, advanceParam);
            }
        }

        //OnRecvWriteWiegandNumberRsp
        void RfidReaderRspNotify.OnRecvWriteWiegandNumberRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvWriteWiegandNumberRsp(reader, result);
                }));
            }
            else
            {
                mainWindows.OnRecvWriteWiegandNumberRsp(reader, result);
            }
        }

        void RfidReaderRspNotify.OnRecvLockResult(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("成功锁定标签.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("锁定标签失败.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("成功锁定标签.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("锁定标签失败.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvTagNotify(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, byte tlvCount)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvTagNotify(reader, tlvItems, tlvCount);
                }));
            }
            else
            {
                mainWindows.OnRecvTagNotify(reader, tlvItems, tlvCount);
            }
        }

        void RfidReaderRspNotify.OnRecvHeartBeats(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, byte tlvCount)
        {
            return;
        }

        void RfidReaderRspNotify.OnRecvSettingSingleParam(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("设置参数成功.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("设置参数失败.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("设置参数成功.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("设置参数失败.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvQuerySingleParam(RfidSdk.RfidReader reader, TlvValueItem item)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReaderQuerySingleParamRsp(reader, item);
                }));
            }
            else
            {
                mainWindows.OnRecvReaderQuerySingleParamRsp(reader, item);
            }
        }

        public void OnRecvWriteTagRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvWriteTagResult(result);
                }));
            }
            else
            {
                mainWindows.OnRecvWriteTagResult(result);
            }
        }

        void RfidReaderRspNotify.OnRecvReadBlockRsp(RfidSdk.RfidReader reader, byte result, byte[] read_data,byte[] epc_data)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvReadTagBlockNotify(reader, result, read_data, epc_data);
                   
                }));
            }
            else
            {
                mainWindows.OnRecvReadTagBlockNotify(reader, result, read_data,epc_data);
            }
        }
		void RfidReaderRspNotify.OnRecvRecordNotify(RfidSdk.RfidReader reader, string time, string tagId)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvRecordNotify(reader, time,tagId);
                }));
            }
            else
            {
                mainWindows.OnRecvRecordNotify(reader, time, tagId);
            }
        }

        void RfidReaderRspNotify.OnRecvRecordStatusRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvRecordStatusRsp(reader, result);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvRecordStatusRsp(reader, result);
            }
        }

        void RfidReaderRspNotify.OnRecvSetRtcTimeStatusRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvSetRtcTimeRsp(reader, result);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvSetRtcTimeRsp(reader, result);
            }
        }

        void RfidReaderRspNotify.OnRecvQueryRtcTimeRsp(int year, int month, int day, int hour, int min, int sec)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvQueryRtcTimeRsp(year, month,day,hour,min,sec);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvQueryRtcTimeRsp(year, month, day, hour, min, sec);
            }
        }

        void RfidReaderRspNotify.OnRecvWriteTagRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.OnRecvWriteTagResult(result);
                }));
            }
            else
            {
                mainWindows.OnRecvWriteTagResult(result);
            }
        }

        void RfidReaderRspNotify.OnRecvQueryExtParamRsp(RfidSdk.RfidReader reader, byte result, RfidExtParam extParam)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvQueryExtParam(result,extParam);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvQueryExtParam(result,extParam);
            }
        }

        void RfidReaderRspNotify.OnRecvSetExtParam(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (result == 0)
                    {
                        mainWindows.AddResultItem("成功设置拓展功能参数", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("设置拓展功能参数失败:" + result.ToString(), MessageType.Normal);
                    }
                }));
            }
            else
            {
                if (result == 0)
                {
                    mainWindows.AddResultItem("成功设置拓展功能参数.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("设置拓展功能参数失败:" + result.ToString(), MessageType.Normal);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvAudioPlayRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (result == 0)
                    {
                        mainWindows.AddResultItem("语音操作成功", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("语音操作失败:" + result.ToString(), MessageType.Normal);
                    }
                }));
            }
            else
            {
                if (result == 0)
                {
                    mainWindows.AddResultItem("语音操作成功.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("语音操作失败:" + result.ToString(), MessageType.Normal);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvRelayOpRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (result == 0)
                    {
                        mainWindows.AddResultItem("继电器打开成功", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("继电器打开失败:" + result.ToString(), MessageType.Normal);
                    }
                }));
            }
            else
            {
                if (result == 0)
                {
                    mainWindows.AddResultItem("继电器打开成功.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("继电器打开失败.:" + result.ToString(), MessageType.Normal);
                }
            }
        }

        public void OnRecvVerifyTagRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (result == 0)
                    {
                        mainWindows.AddResultItem("标签添加校验信息成功", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("标签添加校验信息失败:" + result.ToString(), MessageType.Normal);
                    }
                }));
            }
            else
            {
                if (result == 0)
                {
                    mainWindows.AddResultItem("标签添加校验信息成功", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("标签添加校验信息失败:" + result.ToString(), MessageType.Normal);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvSetUsbInfoRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("成功设置USB参数.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("设置USB参数失败.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("成功设置USB参数.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("设置USB参数失败.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvQueryUsbInfoRsp(RfidSdk.RfidReader reader,byte interfaceType, byte usbProto, byte enterflag)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvQueryUsbData(interfaceType,usbProto, enterflag);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvQueryUsbData(interfaceType,usbProto, enterflag);
            }
        }

        void RfidReaderRspNotify.OnRecvSetDataFlagRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("成功设置传输数据参数.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("设置传输数据参数失败.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("成功设置传输数据参数.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("设置传输数据参数失败.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvQueryDataFlagRsp(RfidSdk.RfidReader reader,UInt16 dataFlag,byte dataFormate)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvQueryDataFlag(dataFlag,dataFormate);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvQueryDataFlag(dataFlag, dataFormate);
            }
        }

        void RfidReaderRspNotify.OnRecvQueryModbusParam(RfidSdk.RfidReader reader, byte tagNum,byte unionSize,byte addr,byte clearFlag, int modbusProto)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvQueryModbusParam(tagNum, unionSize, addr,clearFlag,modbusProto);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvQueryModbusParam(tagNum, unionSize, addr, clearFlag, modbusProto);
            }
        }

        void RfidReaderRspNotify.OnRecvSetModbusParamRsp(RfidSdk.RfidReader reader, byte result)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    if (0 == result)
                    {
                        mainWindows.AddResultItem("成功设置Modbus参数.", MessageType.Normal);
                    }
                    else
                    {
                        mainWindows.AddResultItem("设置Modbus参数失败.", MessageType.Error);
                    }
                }));
            }
            else
            {
                if (0 == result)
                {
                    mainWindows.AddResultItem("成功设置Modbus参数.", MessageType.Normal);
                }
                else
                {
                    mainWindows.AddResultItem("设置Modbus参数失败.", MessageType.Error);
                }
            }
        }

        void RfidReaderRspNotify.OnRecvTagData(RfidSdk.RfidReader reader, TlvValueItem[] tlvItems, byte tlvCount)
        {
            if (mainWindows.InvokeRequired)
            {
                mainWindows.BeginInvoke(new EventHandler(delegate
                {
                    mainWindows.m100Windows.OnRecvIdentify(reader, tlvItems, tlvCount);
                }));
            }
            else
            {
                mainWindows.m100Windows.OnRecvIdentify(reader, tlvItems, tlvCount);
            }
        }
    }
}
