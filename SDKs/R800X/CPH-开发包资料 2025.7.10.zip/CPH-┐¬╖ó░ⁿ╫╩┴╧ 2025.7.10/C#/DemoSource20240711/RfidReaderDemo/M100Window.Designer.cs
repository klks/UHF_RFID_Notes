﻿namespace RfidReader
{
    partial class M100Window
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl_function = new System.Windows.Forms.TabControl();
            this.tabPage_inventory = new System.Windows.Forms.TabPage();
            this.skinLabel_tag_num = new CCWin.SkinControl.SkinLabel();
            this.skinButton_clear = new CCWin.SkinControl.SkinButton();
            this.skinButton_start = new CCWin.SkinControl.SkinButton();
            this.skinButton_once = new CCWin.SkinControl.SkinButton();
            this.skinButton_save = new CCWin.SkinControl.SkinButton();
            this.skinButton_stop = new CCWin.SkinControl.SkinButton();
            this.skinListView_tags = new CCWin.SkinControl.SkinListView();
            this.columnHeader_time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_ext = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_rssi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_count = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage_work_param = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.skinWaterTextBox_dev_num = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinButton_dev_set = new CCWin.SkinControl.SkinButton();
            this.skinButton_dev_query = new CCWin.SkinControl.SkinButton();
            this.label17 = new System.Windows.Forms.Label();
            this.skinGroupBox7 = new CCWin.SkinControl.SkinGroupBox();
            this.skinLabel50 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel4 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel31 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_addr = new CCWin.SkinControl.SkinWaterTextBox();
            this.checkedListBox_work_ant = new System.Windows.Forms.CheckedListBox();
            this.skinLabel1 = new CCWin.SkinControl.SkinLabel();
            this.skinNumericUpDown_power = new CCWin.SkinControl.SkinNumericUpDown();
            this.skinGroupBox6 = new CCWin.SkinControl.SkinGroupBox();
            this.record_check = new CCWin.SkinControl.SkinCheckBox();
            this.buzzer_check = new CCWin.SkinControl.SkinCheckBox();
            this.skinLabel49 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel48 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_inventory_length = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel47 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel33 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel46 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_inventory_address = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel45 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_inventory_area = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel44 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel_work_mode = new CCWin.SkinControl.SkinLabel();
            this.skinNumericUpDown_trigger_time = new CCWin.SkinControl.SkinNumericUpDown();
            this.skinLabel_trigger = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_work_mode = new CCWin.SkinControl.SkinComboBox();
            this.skinNumericUpDown_work_interval = new CCWin.SkinControl.SkinNumericUpDown();
            this.skinLabel3 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel2 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel32 = new CCWin.SkinControl.SkinLabel();
            this.skinNumericUpDown_work_filter = new CCWin.SkinControl.SkinNumericUpDown();
            this.skinButton_reset = new CCWin.SkinControl.SkinButton();
            this.skinButton_defualt = new CCWin.SkinControl.SkinButton();
            this.skinButton_work_set = new CCWin.SkinControl.SkinButton();
            this.skinButton_work_refresh = new CCWin.SkinControl.SkinButton();
            this.tabPage_transfer = new System.Windows.Forms.TabPage();
            this.skinGroupBox8 = new CCWin.SkinControl.SkinGroupBox();
            this.dhcp_check = new CCWin.SkinControl.SkinCheckBox();
            this.skinLabel12 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_ip_mac = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinWaterTextBox_gate_way = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel13 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_ip_local = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel19 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel14 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_local_port = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinWaterTextBox_ip_sub_masker = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel18 = new CCWin.SkinControl.SkinLabel();
            this.skinGroupBox5 = new CCWin.SkinControl.SkinGroupBox();
            this.skinWaterTextBox_module_id = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinWaterTextBox_module_sn = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel43 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel42 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_sub_protocol = new CCWin.SkinControl.SkinComboBox();
            this.skinButton_transfer_set = new CCWin.SkinControl.SkinButton();
            this.skinLabel29 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_transfer_query = new CCWin.SkinControl.SkinButton();
            this.skinGroupBox3 = new CCWin.SkinControl.SkinGroupBox();
            this.radioButton_remote_ipmode_host = new System.Windows.Forms.RadioButton();
            this.radioButton_remote_ipmode_IP = new System.Windows.Forms.RadioButton();
            this.skinWaterTextBox_heart_beats = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel17 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel30 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_remote_port = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinWaterTextBox_ip_remote = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel16 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel15 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_transfer_mode = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel6 = new CCWin.SkinControl.SkinLabel();
            this.skinGroupBox2 = new CCWin.SkinControl.SkinGroupBox();
            this.skinComboBox_wiegand_direction = new CCWin.SkinControl.SkinComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.skinNumericUpDown_wiegand_location = new CCWin.SkinControl.SkinNumericUpDown();
            this.skinWaterTextBox_wiegand_interval = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinWaterTextBox_wiegand_prorid = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinWaterTextBox_wiegand_width = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinComboBox_wiegand_protocl = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel11 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel10 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel9 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel8 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel7 = new CCWin.SkinControl.SkinLabel();
            this.skinGroupBox1 = new CCWin.SkinControl.SkinGroupBox();
            this.skinComboBox_transfer_baudrate = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel5 = new CCWin.SkinControl.SkinLabel();
            this.tabPage_advance = new System.Windows.Forms.TabPage();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox_advan_rssi = new System.Windows.Forms.TextBox();
            this.skinNumericUpDown_advan_Q = new CCWin.SkinControl.SkinNumericUpDown();
            this.skinButton_advance_set = new CCWin.SkinControl.SkinButton();
            this.skinButton_advance_refresh = new CCWin.SkinControl.SkinButton();
            this.skinLabel28 = new CCWin.SkinControl.SkinLabel();
            this.skinLabel27 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_advan_target = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel26 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_advan_session = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel25 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_advan_sel = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel24 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_advan_cw = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel23 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_advan_hopping = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel22 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_advan_channel = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel21 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_advan_region = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel20 = new CCWin.SkinControl.SkinLabel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.skinButton_tag_verify = new CCWin.SkinControl.SkinButton();
            this.skinButton_kill_tag = new CCWin.SkinControl.SkinButton();
            this.skinButton_tag_lock = new CCWin.SkinControl.SkinButton();
            this.comboBox_lock_type = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.skinGroupBox4 = new CCWin.SkinControl.SkinGroupBox();
            this.skinButton_query_time = new CCWin.SkinControl.SkinButton();
            this.skinButton_sync_time = new CCWin.SkinControl.SkinButton();
            this.skinButton_upload_record = new CCWin.SkinControl.SkinButton();
            this.skinButton_wiegand_write = new CCWin.SkinControl.SkinButton();
            this.skinWaterTextBox_wiegand_write_data = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel51 = new CCWin.SkinControl.SkinLabel();
            this.skinLine1 = new CCWin.SkinControl.SkinLine();
            this.skinTextBox_opt_result = new CCWin.SkinControl.SkinTextBox();
            this.skinLabel41 = new CCWin.SkinControl.SkinLabel();
            this.skinButton_operation_read = new CCWin.SkinControl.SkinButton();
            this.skinButton_operation_write = new CCWin.SkinControl.SkinButton();
            this.skinWater_content = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel40 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_password = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel39 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_length = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel38 = new CCWin.SkinControl.SkinLabel();
            this.skinWaterTextBox_address = new CCWin.SkinControl.SkinWaterTextBox();
            this.skinLabel37 = new CCWin.SkinControl.SkinLabel();
            this.skinComboBox_membank = new CCWin.SkinControl.SkinComboBox();
            this.skinLabel36 = new CCWin.SkinControl.SkinLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button_relay_control = new System.Windows.Forms.Button();
            this.textBox_relay_ctrl_time = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox_op_index = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_audio_set_vol = new System.Windows.Forms.Button();
            this.button_audio_play = new System.Windows.Forms.Button();
            this.textBox_audio_text = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_ext_add_verify = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox_tag_verify_pwd = new System.Windows.Forms.TextBox();
            this.checkBox_tag_verify = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button_relay_set = new System.Windows.Forms.Button();
            this.button_ext_fresh = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_relay_time = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.checkBox_relay2_auto = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox_relay1_auto = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button_write_file_reload = new System.Windows.Forms.Button();
            this.button_write_file_auto = new System.Windows.Forms.Button();
            this.button_write_file_hand = new System.Windows.Forms.Button();
            this.textBox_write_file_data = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.numericUpDown_write_file_row = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.button_write_file_choose = new System.Windows.Forms.Button();
            this.textBox_write_file_path = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.checkBox_auto_write_increse = new System.Windows.Forms.CheckBox();
            this.checkBox_auto_write_flag = new System.Windows.Forms.CheckBox();
            this.button_auto_write_wiegand = new System.Windows.Forms.Button();
            this.button_auto_write_hex = new System.Windows.Forms.Button();
            this.textBox_auto_wiegand_write_text = new System.Windows.Forms.TextBox();
            this.textBox_auto_hex_write_text = new System.Windows.Forms.TextBox();
            this.tabPage_ExDataParam = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.comboBox_ex_modbus_proto = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label_ex_modbus_register_num = new System.Windows.Forms.Label();
            this.button_ex_modbus_set = new System.Windows.Forms.Button();
            this.button_ex_modbus_query = new System.Windows.Forms.Button();
            this.checkBox_ex_modbus_clear_flag = new System.Windows.Forms.CheckBox();
            this.numericUpDown_ex_modbus_startaddr = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.numericUpDown_ex_modbus_union_size = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.numericUpDown_ex_modbus_tag_num = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.comboBox_dataflag_format = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.button_dataflag_set = new System.Windows.Forms.Button();
            this.button_dataflag_query = new System.Windows.Forms.Button();
            this.checkBoxDataFlag_DevNo = new System.Windows.Forms.CheckBox();
            this.checkBoxDataFlag_ANT = new System.Windows.Forms.CheckBox();
            this.checkBoxDataFlag_RSSI = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton_USB_COM = new System.Windows.Forms.RadioButton();
            this.radioButton_USB_HID = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.button_usbdata_sset = new System.Windows.Forms.Button();
            this.button_usbdata_query = new System.Windows.Forms.Button();
            this.checkBox_usbdata_enter_flag = new System.Windows.Forms.CheckBox();
            this.comboBox_usbdata_proto = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage_filterdata = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.button_ext_auto_add_verify = new System.Windows.Forms.Button();
            this.tabControl_function.SuspendLayout();
            this.tabPage_inventory.SuspendLayout();
            this.tabPage_work_param.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.skinGroupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_power)).BeginInit();
            this.skinGroupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_trigger_time)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_work_interval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_work_filter)).BeginInit();
            this.tabPage_transfer.SuspendLayout();
            this.skinGroupBox8.SuspendLayout();
            this.skinGroupBox5.SuspendLayout();
            this.skinGroupBox3.SuspendLayout();
            this.skinGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_wiegand_location)).BeginInit();
            this.skinGroupBox1.SuspendLayout();
            this.tabPage_advance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_advan_Q)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.skinGroupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_write_file_row)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tabPage_ExDataParam.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ex_modbus_startaddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ex_modbus_union_size)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ex_modbus_tag_num)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage_filterdata.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl_function
            // 
            this.tabControl_function.Controls.Add(this.tabPage_inventory);
            this.tabControl_function.Controls.Add(this.tabPage_work_param);
            this.tabControl_function.Controls.Add(this.tabPage_transfer);
            this.tabControl_function.Controls.Add(this.tabPage_advance);
            this.tabControl_function.Controls.Add(this.tabPage1);
            this.tabControl_function.Controls.Add(this.tabPage2);
            this.tabControl_function.Controls.Add(this.tabPage3);
            this.tabControl_function.Controls.Add(this.tabPage_ExDataParam);
            this.tabControl_function.Controls.Add(this.tabPage_filterdata);
            this.tabControl_function.Location = new System.Drawing.Point(0, -1);
            this.tabControl_function.Name = "tabControl_function";
            this.tabControl_function.SelectedIndex = 0;
            this.tabControl_function.Size = new System.Drawing.Size(586, 395);
            this.tabControl_function.TabIndex = 0;
            this.tabControl_function.SelectedIndexChanged += new System.EventHandler(this.tabControl_function_SelectedIndexChanged);
            // 
            // tabPage_inventory
            // 
            this.tabPage_inventory.Controls.Add(this.skinLabel_tag_num);
            this.tabPage_inventory.Controls.Add(this.skinButton_clear);
            this.tabPage_inventory.Controls.Add(this.skinButton_start);
            this.tabPage_inventory.Controls.Add(this.skinButton_once);
            this.tabPage_inventory.Controls.Add(this.skinButton_save);
            this.tabPage_inventory.Controls.Add(this.skinButton_stop);
            this.tabPage_inventory.Controls.Add(this.skinListView_tags);
            this.tabPage_inventory.Location = new System.Drawing.Point(4, 22);
            this.tabPage_inventory.Name = "tabPage_inventory";
            this.tabPage_inventory.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_inventory.Size = new System.Drawing.Size(578, 369);
            this.tabPage_inventory.TabIndex = 0;
            this.tabPage_inventory.Text = "盘存标签";
            this.tabPage_inventory.UseVisualStyleBackColor = true;
            // 
            // skinLabel_tag_num
            // 
            this.skinLabel_tag_num.AutoSize = true;
            this.skinLabel_tag_num.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_tag_num.BorderColor = System.Drawing.Color.White;
            this.skinLabel_tag_num.Font = new System.Drawing.Font("微软雅黑", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_tag_num.ForeColor = System.Drawing.Color.Blue;
            this.skinLabel_tag_num.Location = new System.Drawing.Point(488, 330);
            this.skinLabel_tag_num.Name = "skinLabel_tag_num";
            this.skinLabel_tag_num.Size = new System.Drawing.Size(68, 38);
            this.skinLabel_tag_num.TabIndex = 6;
            this.skinLabel_tag_num.Text = "000";
            // 
            // skinButton_clear
            // 
            this.skinButton_clear.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_clear.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_clear.DownBack = null;
            this.skinButton_clear.Location = new System.Drawing.Point(12, 336);
            this.skinButton_clear.MouseBack = null;
            this.skinButton_clear.Name = "skinButton_clear";
            this.skinButton_clear.NormlBack = null;
            this.skinButton_clear.Size = new System.Drawing.Size(75, 23);
            this.skinButton_clear.TabIndex = 5;
            this.skinButton_clear.Text = "清空";
            this.skinButton_clear.UseVisualStyleBackColor = false;
            this.skinButton_clear.Click += new System.EventHandler(this.skinButton_clear_Click);
            // 
            // skinButton_start
            // 
            this.skinButton_start.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_start.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_start.DownBack = null;
            this.skinButton_start.Location = new System.Drawing.Point(102, 336);
            this.skinButton_start.MouseBack = null;
            this.skinButton_start.Name = "skinButton_start";
            this.skinButton_start.NormlBack = null;
            this.skinButton_start.Size = new System.Drawing.Size(75, 23);
            this.skinButton_start.TabIndex = 4;
            this.skinButton_start.Text = "开始";
            this.skinButton_start.UseVisualStyleBackColor = false;
            this.skinButton_start.Click += new System.EventHandler(this.skinButton_start_Click);
            // 
            // skinButton_once
            // 
            this.skinButton_once.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_once.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_once.DownBack = null;
            this.skinButton_once.Location = new System.Drawing.Point(284, 336);
            this.skinButton_once.MouseBack = null;
            this.skinButton_once.Name = "skinButton_once";
            this.skinButton_once.NormlBack = null;
            this.skinButton_once.Size = new System.Drawing.Size(75, 23);
            this.skinButton_once.TabIndex = 3;
            this.skinButton_once.Text = "主动读取";
            this.skinButton_once.UseVisualStyleBackColor = false;
            this.skinButton_once.Click += new System.EventHandler(this.skinButton_once_Click);
            // 
            // skinButton_save
            // 
            this.skinButton_save.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_save.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_save.DownBack = null;
            this.skinButton_save.Location = new System.Drawing.Point(376, 336);
            this.skinButton_save.MouseBack = null;
            this.skinButton_save.Name = "skinButton_save";
            this.skinButton_save.NormlBack = null;
            this.skinButton_save.Size = new System.Drawing.Size(75, 23);
            this.skinButton_save.TabIndex = 2;
            this.skinButton_save.Text = "保存数据";
            this.skinButton_save.UseVisualStyleBackColor = false;
            this.skinButton_save.Click += new System.EventHandler(this.skinButton_save_Click);
            // 
            // skinButton_stop
            // 
            this.skinButton_stop.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_stop.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_stop.DownBack = null;
            this.skinButton_stop.Location = new System.Drawing.Point(192, 336);
            this.skinButton_stop.MouseBack = null;
            this.skinButton_stop.Name = "skinButton_stop";
            this.skinButton_stop.NormlBack = null;
            this.skinButton_stop.Size = new System.Drawing.Size(75, 23);
            this.skinButton_stop.TabIndex = 2;
            this.skinButton_stop.Text = "停止";
            this.skinButton_stop.UseVisualStyleBackColor = false;
            this.skinButton_stop.Click += new System.EventHandler(this.skinButton_stop_Click);
            // 
            // skinListView_tags
            // 
            this.skinListView_tags.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_time,
            this.columnHeader_ID,
            this.columnHeader_ext,
            this.columnHeader_rssi,
            this.columnHeader_count});
            this.skinListView_tags.HideSelection = false;
            this.skinListView_tags.Location = new System.Drawing.Point(0, -1);
            this.skinListView_tags.Name = "skinListView_tags";
            this.skinListView_tags.OwnerDraw = true;
            this.skinListView_tags.Size = new System.Drawing.Size(578, 319);
            this.skinListView_tags.TabIndex = 0;
            this.skinListView_tags.UseCompatibleStateImageBehavior = false;
            this.skinListView_tags.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader_time
            // 
            this.columnHeader_time.Text = "时间";
            this.columnHeader_time.Width = 65;
            // 
            // columnHeader_ID
            // 
            this.columnHeader_ID.Text = "EPC";
            this.columnHeader_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_ID.Width = 205;
            // 
            // columnHeader_ext
            // 
            this.columnHeader_ext.Text = "其它区域";
            this.columnHeader_ext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_ext.Width = 190;
            // 
            // columnHeader_rssi
            // 
            this.columnHeader_rssi.Text = "信息";
            this.columnHeader_rssi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_rssi.Width = 53;
            // 
            // columnHeader_count
            // 
            this.columnHeader_count.Text = "次数";
            this.columnHeader_count.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_count.Width = 58;
            // 
            // tabPage_work_param
            // 
            this.tabPage_work_param.Controls.Add(this.groupBox4);
            this.tabPage_work_param.Controls.Add(this.skinGroupBox7);
            this.tabPage_work_param.Controls.Add(this.skinGroupBox6);
            this.tabPage_work_param.Controls.Add(this.skinButton_reset);
            this.tabPage_work_param.Controls.Add(this.skinButton_defualt);
            this.tabPage_work_param.Controls.Add(this.skinButton_work_set);
            this.tabPage_work_param.Controls.Add(this.skinButton_work_refresh);
            this.tabPage_work_param.ForeColor = System.Drawing.Color.Black;
            this.tabPage_work_param.Location = new System.Drawing.Point(4, 22);
            this.tabPage_work_param.Name = "tabPage_work_param";
            this.tabPage_work_param.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_work_param.Size = new System.Drawing.Size(578, 369);
            this.tabPage_work_param.TabIndex = 2;
            this.tabPage_work_param.Text = "工作参数";
            this.tabPage_work_param.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.skinWaterTextBox_dev_num);
            this.groupBox4.Controls.Add(this.skinButton_dev_set);
            this.groupBox4.Controls.Add(this.skinButton_dev_query);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Location = new System.Drawing.Point(9, 307);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(563, 54);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "设备号设置";
            // 
            // skinWaterTextBox_dev_num
            // 
            this.skinWaterTextBox_dev_num.Location = new System.Drawing.Point(75, 24);
            this.skinWaterTextBox_dev_num.Name = "skinWaterTextBox_dev_num";
            this.skinWaterTextBox_dev_num.Size = new System.Drawing.Size(187, 21);
            this.skinWaterTextBox_dev_num.TabIndex = 27;
            this.skinWaterTextBox_dev_num.WaterColor = System.Drawing.Color.Aqua;
            this.skinWaterTextBox_dev_num.WaterText = "";
            // 
            // skinButton_dev_set
            // 
            this.skinButton_dev_set.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_dev_set.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_dev_set.DownBack = null;
            this.skinButton_dev_set.Location = new System.Drawing.Point(370, 21);
            this.skinButton_dev_set.MouseBack = null;
            this.skinButton_dev_set.Name = "skinButton_dev_set";
            this.skinButton_dev_set.NormlBack = null;
            this.skinButton_dev_set.Size = new System.Drawing.Size(75, 23);
            this.skinButton_dev_set.TabIndex = 26;
            this.skinButton_dev_set.Text = "设置";
            this.skinButton_dev_set.UseVisualStyleBackColor = false;
            this.skinButton_dev_set.Click += new System.EventHandler(this.skinButton_dev_set_Click);
            // 
            // skinButton_dev_query
            // 
            this.skinButton_dev_query.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_dev_query.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_dev_query.DownBack = null;
            this.skinButton_dev_query.Location = new System.Drawing.Point(280, 21);
            this.skinButton_dev_query.MouseBack = null;
            this.skinButton_dev_query.Name = "skinButton_dev_query";
            this.skinButton_dev_query.NormlBack = null;
            this.skinButton_dev_query.Size = new System.Drawing.Size(75, 23);
            this.skinButton_dev_query.TabIndex = 25;
            this.skinButton_dev_query.Text = "查询";
            this.skinButton_dev_query.UseVisualStyleBackColor = false;
            this.skinButton_dev_query.Click += new System.EventHandler(this.skinButton_dev_query_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(21, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "设备号：";
            // 
            // skinGroupBox7
            // 
            this.skinGroupBox7.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox7.BorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox7.Controls.Add(this.skinLabel50);
            this.skinGroupBox7.Controls.Add(this.skinLabel4);
            this.skinGroupBox7.Controls.Add(this.skinLabel31);
            this.skinGroupBox7.Controls.Add(this.skinWaterTextBox_addr);
            this.skinGroupBox7.Controls.Add(this.checkedListBox_work_ant);
            this.skinGroupBox7.Controls.Add(this.skinLabel1);
            this.skinGroupBox7.Controls.Add(this.skinNumericUpDown_power);
            this.skinGroupBox7.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox7.Location = new System.Drawing.Point(8, 162);
            this.skinGroupBox7.Name = "skinGroupBox7";
            this.skinGroupBox7.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox7.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox7.Size = new System.Drawing.Size(563, 83);
            this.skinGroupBox7.TabIndex = 23;
            this.skinGroupBox7.TabStop = false;
            this.skinGroupBox7.Text = "读写器设置";
            this.skinGroupBox7.TitleBorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox7.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox7.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // skinLabel50
            // 
            this.skinLabel50.AutoSize = true;
            this.skinLabel50.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel50.BorderColor = System.Drawing.Color.White;
            this.skinLabel50.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel50.Location = new System.Drawing.Point(7, 53);
            this.skinLabel50.Name = "skinLabel50";
            this.skinLabel50.Size = new System.Drawing.Size(32, 17);
            this.skinLabel50.TabIndex = 22;
            this.skinLabel50.Text = "天线";
            // 
            // skinLabel4
            // 
            this.skinLabel4.AutoSize = true;
            this.skinLabel4.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel4.BorderColor = System.Drawing.Color.White;
            this.skinLabel4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel4.Location = new System.Drawing.Point(11, 21);
            this.skinLabel4.Name = "skinLabel4";
            this.skinLabel4.Size = new System.Drawing.Size(59, 17);
            this.skinLabel4.TabIndex = 12;
            this.skinLabel4.Text = "设备地址:";
            // 
            // skinLabel31
            // 
            this.skinLabel31.AutoSize = true;
            this.skinLabel31.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel31.BorderColor = System.Drawing.Color.White;
            this.skinLabel31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel31.Location = new System.Drawing.Point(338, 21);
            this.skinLabel31.Name = "skinLabel31";
            this.skinLabel31.Size = new System.Drawing.Size(92, 17);
            this.skinLabel31.TabIndex = 18;
            this.skinLabel31.Text = "(15 ~ 30 dbm)";
            // 
            // skinWaterTextBox_addr
            // 
            this.skinWaterTextBox_addr.Location = new System.Drawing.Point(76, 21);
            this.skinWaterTextBox_addr.Name = "skinWaterTextBox_addr";
            this.skinWaterTextBox_addr.Size = new System.Drawing.Size(63, 21);
            this.skinWaterTextBox_addr.TabIndex = 13;
            this.skinWaterTextBox_addr.WaterColor = System.Drawing.Color.Aqua;
            this.skinWaterTextBox_addr.WaterText = "";
            // 
            // checkedListBox_work_ant
            // 
            this.checkedListBox_work_ant.CheckOnClick = true;
            this.checkedListBox_work_ant.ColumnWidth = 60;
            this.checkedListBox_work_ant.FormattingEnabled = true;
            this.checkedListBox_work_ant.Items.AddRange(new object[] {
            "ANT1",
            "ANT2",
            "ANT3",
            "ANT4",
            "ANT5",
            "ANT6",
            "ANT7",
            "ANT8"});
            this.checkedListBox_work_ant.Location = new System.Drawing.Point(45, 52);
            this.checkedListBox_work_ant.MultiColumn = true;
            this.checkedListBox_work_ant.Name = "checkedListBox_work_ant";
            this.checkedListBox_work_ant.Size = new System.Drawing.Size(513, 20);
            this.checkedListBox_work_ant.TabIndex = 21;
            // 
            // skinLabel1
            // 
            this.skinLabel1.AutoSize = true;
            this.skinLabel1.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel1.BorderColor = System.Drawing.Color.White;
            this.skinLabel1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel1.ForeColor = System.Drawing.Color.Black;
            this.skinLabel1.Location = new System.Drawing.Point(228, 21);
            this.skinLabel1.Name = "skinLabel1";
            this.skinLabel1.Size = new System.Drawing.Size(35, 17);
            this.skinLabel1.TabIndex = 0;
            this.skinLabel1.Text = "功率:";
            // 
            // skinNumericUpDown_power
            // 
            this.skinNumericUpDown_power.Location = new System.Drawing.Point(269, 21);
            this.skinNumericUpDown_power.Maximum = new decimal(new int[] {
            33,
            0,
            0,
            0});
            this.skinNumericUpDown_power.Name = "skinNumericUpDown_power";
            this.skinNumericUpDown_power.Size = new System.Drawing.Size(63, 21);
            this.skinNumericUpDown_power.TabIndex = 1;
            this.skinNumericUpDown_power.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.skinNumericUpDown_power.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // skinGroupBox6
            // 
            this.skinGroupBox6.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox6.BorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox6.Controls.Add(this.record_check);
            this.skinGroupBox6.Controls.Add(this.buzzer_check);
            this.skinGroupBox6.Controls.Add(this.skinLabel49);
            this.skinGroupBox6.Controls.Add(this.skinLabel48);
            this.skinGroupBox6.Controls.Add(this.skinWaterTextBox_inventory_length);
            this.skinGroupBox6.Controls.Add(this.skinLabel47);
            this.skinGroupBox6.Controls.Add(this.skinLabel33);
            this.skinGroupBox6.Controls.Add(this.skinLabel46);
            this.skinGroupBox6.Controls.Add(this.skinWaterTextBox_inventory_address);
            this.skinGroupBox6.Controls.Add(this.skinLabel45);
            this.skinGroupBox6.Controls.Add(this.skinComboBox_inventory_area);
            this.skinGroupBox6.Controls.Add(this.skinLabel44);
            this.skinGroupBox6.Controls.Add(this.skinLabel_work_mode);
            this.skinGroupBox6.Controls.Add(this.skinNumericUpDown_trigger_time);
            this.skinGroupBox6.Controls.Add(this.skinLabel_trigger);
            this.skinGroupBox6.Controls.Add(this.skinComboBox_work_mode);
            this.skinGroupBox6.Controls.Add(this.skinNumericUpDown_work_interval);
            this.skinGroupBox6.Controls.Add(this.skinLabel3);
            this.skinGroupBox6.Controls.Add(this.skinLabel2);
            this.skinGroupBox6.Controls.Add(this.skinLabel32);
            this.skinGroupBox6.Controls.Add(this.skinNumericUpDown_work_filter);
            this.skinGroupBox6.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox6.Location = new System.Drawing.Point(8, 3);
            this.skinGroupBox6.Name = "skinGroupBox6";
            this.skinGroupBox6.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox6.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox6.Size = new System.Drawing.Size(567, 153);
            this.skinGroupBox6.TabIndex = 22;
            this.skinGroupBox6.TabStop = false;
            this.skinGroupBox6.Text = "读卡参数设置";
            this.skinGroupBox6.TitleBorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox6.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox6.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // record_check
            // 
            this.record_check.AutoSize = true;
            this.record_check.BackColor = System.Drawing.Color.Transparent;
            this.record_check.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.record_check.DownBack = null;
            this.record_check.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.record_check.Location = new System.Drawing.Point(16, 120);
            this.record_check.MouseBack = null;
            this.record_check.Name = "record_check";
            this.record_check.NormlBack = null;
            this.record_check.SelectedDownBack = null;
            this.record_check.SelectedMouseBack = null;
            this.record_check.SelectedNormlBack = null;
            this.record_check.Size = new System.Drawing.Size(99, 21);
            this.record_check.TabIndex = 30;
            this.record_check.Text = "断网记录标签";
            this.record_check.UseVisualStyleBackColor = false;
            // 
            // buzzer_check
            // 
            this.buzzer_check.AutoSize = true;
            this.buzzer_check.BackColor = System.Drawing.Color.Transparent;
            this.buzzer_check.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.buzzer_check.DownBack = null;
            this.buzzer_check.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buzzer_check.Location = new System.Drawing.Point(121, 120);
            this.buzzer_check.MouseBack = null;
            this.buzzer_check.Name = "buzzer_check";
            this.buzzer_check.NormlBack = null;
            this.buzzer_check.SelectedDownBack = null;
            this.buzzer_check.SelectedMouseBack = null;
            this.buzzer_check.SelectedNormlBack = null;
            this.buzzer_check.Size = new System.Drawing.Size(87, 21);
            this.buzzer_check.TabIndex = 29;
            this.buzzer_check.Text = "读卡蜂鸣器";
            this.buzzer_check.UseVisualStyleBackColor = false;
            // 
            // skinLabel49
            // 
            this.skinLabel49.AutoSize = true;
            this.skinLabel49.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel49.BorderColor = System.Drawing.Color.White;
            this.skinLabel49.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel49.Location = new System.Drawing.Point(178, 72);
            this.skinLabel49.Name = "skinLabel49";
            this.skinLabel49.Size = new System.Drawing.Size(56, 17);
            this.skinLabel49.TabIndex = 28;
            this.skinLabel49.Text = "(* 10ms)";
            // 
            // skinLabel48
            // 
            this.skinLabel48.AutoSize = true;
            this.skinLabel48.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel48.BorderColor = System.Drawing.Color.White;
            this.skinLabel48.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel48.Location = new System.Drawing.Point(481, 71);
            this.skinLabel48.Name = "skinLabel48";
            this.skinLabel48.Size = new System.Drawing.Size(49, 17);
            this.skinLabel48.TabIndex = 27;
            this.skinLabel48.Text = "(Word)";
            // 
            // skinWaterTextBox_inventory_length
            // 
            this.skinWaterTextBox_inventory_length.Location = new System.Drawing.Point(402, 71);
            this.skinWaterTextBox_inventory_length.Name = "skinWaterTextBox_inventory_length";
            this.skinWaterTextBox_inventory_length.Size = new System.Drawing.Size(72, 21);
            this.skinWaterTextBox_inventory_length.TabIndex = 26;
            this.skinWaterTextBox_inventory_length.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_inventory_length.WaterText = "";
            // 
            // skinLabel47
            // 
            this.skinLabel47.AutoSize = true;
            this.skinLabel47.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel47.BorderColor = System.Drawing.Color.White;
            this.skinLabel47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel47.Location = new System.Drawing.Point(346, 72);
            this.skinLabel47.Name = "skinLabel47";
            this.skinLabel47.Size = new System.Drawing.Size(59, 17);
            this.skinLabel47.TabIndex = 25;
            this.skinLabel47.Text = "读卡长度:";
            // 
            // skinLabel33
            // 
            this.skinLabel33.AutoSize = true;
            this.skinLabel33.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel33.BorderColor = System.Drawing.Color.White;
            this.skinLabel33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel33.Location = new System.Drawing.Point(182, 96);
            this.skinLabel33.Name = "skinLabel33";
            this.skinLabel33.Size = new System.Drawing.Size(23, 17);
            this.skinLabel33.TabIndex = 20;
            this.skinLabel33.Text = "(S)";
            // 
            // skinLabel46
            // 
            this.skinLabel46.AutoSize = true;
            this.skinLabel46.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel46.BorderColor = System.Drawing.Color.White;
            this.skinLabel46.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel46.Location = new System.Drawing.Point(481, 45);
            this.skinLabel46.Name = "skinLabel46";
            this.skinLabel46.Size = new System.Drawing.Size(49, 17);
            this.skinLabel46.TabIndex = 24;
            this.skinLabel46.Text = "(Word)";
            // 
            // skinWaterTextBox_inventory_address
            // 
            this.skinWaterTextBox_inventory_address.Location = new System.Drawing.Point(402, 42);
            this.skinWaterTextBox_inventory_address.Name = "skinWaterTextBox_inventory_address";
            this.skinWaterTextBox_inventory_address.Size = new System.Drawing.Size(72, 21);
            this.skinWaterTextBox_inventory_address.TabIndex = 23;
            this.skinWaterTextBox_inventory_address.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_inventory_address.WaterText = "";
            // 
            // skinLabel45
            // 
            this.skinLabel45.AutoSize = true;
            this.skinLabel45.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel45.BorderColor = System.Drawing.Color.White;
            this.skinLabel45.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel45.Location = new System.Drawing.Point(310, 45);
            this.skinLabel45.Name = "skinLabel45";
            this.skinLabel45.Size = new System.Drawing.Size(83, 17);
            this.skinLabel45.TabIndex = 22;
            this.skinLabel45.Text = "读卡起始地址:";
            // 
            // skinComboBox_inventory_area
            // 
            this.skinComboBox_inventory_area.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_inventory_area.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_inventory_area.FormattingEnabled = true;
            this.skinComboBox_inventory_area.Items.AddRange(new object[] {
            "Reserve",
            "EPC",
            "TID",
            "USER",
            "TID+EPC",
            "USRE+EPC",
            "6B_Tag",
            "6C_EPC_6B_Tags",
            "YueHe_Temperature_Tag",
            "DTU_Temperature_Tag",
            "GB_Standard_Tag"});
            this.skinComboBox_inventory_area.Location = new System.Drawing.Point(402, 18);
            this.skinComboBox_inventory_area.Name = "skinComboBox_inventory_area";
            this.skinComboBox_inventory_area.Size = new System.Drawing.Size(114, 22);
            this.skinComboBox_inventory_area.TabIndex = 21;
            this.skinComboBox_inventory_area.WaterText = "";
            // 
            // skinLabel44
            // 
            this.skinLabel44.AutoSize = true;
            this.skinLabel44.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel44.BorderColor = System.Drawing.Color.White;
            this.skinLabel44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel44.Location = new System.Drawing.Point(336, 21);
            this.skinLabel44.Name = "skinLabel44";
            this.skinLabel44.Size = new System.Drawing.Size(59, 17);
            this.skinLabel44.TabIndex = 20;
            this.skinLabel44.Text = "读卡区域:";
            // 
            // skinLabel_work_mode
            // 
            this.skinLabel_work_mode.AutoSize = true;
            this.skinLabel_work_mode.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_work_mode.BorderColor = System.Drawing.Color.White;
            this.skinLabel_work_mode.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_work_mode.Location = new System.Drawing.Point(35, 19);
            this.skinLabel_work_mode.Name = "skinLabel_work_mode";
            this.skinLabel_work_mode.Size = new System.Drawing.Size(59, 17);
            this.skinLabel_work_mode.TabIndex = 14;
            this.skinLabel_work_mode.Text = "工作模式:";
            // 
            // skinNumericUpDown_trigger_time
            // 
            this.skinNumericUpDown_trigger_time.Location = new System.Drawing.Point(102, 96);
            this.skinNumericUpDown_trigger_time.Name = "skinNumericUpDown_trigger_time";
            this.skinNumericUpDown_trigger_time.Size = new System.Drawing.Size(68, 21);
            this.skinNumericUpDown_trigger_time.TabIndex = 9;
            this.skinNumericUpDown_trigger_time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // skinLabel_trigger
            // 
            this.skinLabel_trigger.AutoSize = true;
            this.skinLabel_trigger.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel_trigger.BorderColor = System.Drawing.Color.White;
            this.skinLabel_trigger.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel_trigger.Location = new System.Drawing.Point(13, 97);
            this.skinLabel_trigger.Name = "skinLabel_trigger";
            this.skinLabel_trigger.Size = new System.Drawing.Size(83, 17);
            this.skinLabel_trigger.TabIndex = 8;
            this.skinLabel_trigger.Text = "触发延长时间:";
            // 
            // skinComboBox_work_mode
            // 
            this.skinComboBox_work_mode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_work_mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_work_mode.FormattingEnabled = true;
            this.skinComboBox_work_mode.Items.AddRange(new object[] {
            "被动模式",
            "主动模式",
            "触发模式"});
            this.skinComboBox_work_mode.Location = new System.Drawing.Point(100, 18);
            this.skinComboBox_work_mode.Name = "skinComboBox_work_mode";
            this.skinComboBox_work_mode.Size = new System.Drawing.Size(102, 22);
            this.skinComboBox_work_mode.TabIndex = 15;
            this.skinComboBox_work_mode.WaterText = "";
            // 
            // skinNumericUpDown_work_interval
            // 
            this.skinNumericUpDown_work_interval.Location = new System.Drawing.Point(102, 69);
            this.skinNumericUpDown_work_interval.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.skinNumericUpDown_work_interval.Name = "skinNumericUpDown_work_interval";
            this.skinNumericUpDown_work_interval.Size = new System.Drawing.Size(69, 21);
            this.skinNumericUpDown_work_interval.TabIndex = 7;
            this.skinNumericUpDown_work_interval.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // skinLabel3
            // 
            this.skinLabel3.AutoSize = true;
            this.skinLabel3.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel3.BorderColor = System.Drawing.Color.White;
            this.skinLabel3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel3.Location = new System.Drawing.Point(13, 70);
            this.skinLabel3.Name = "skinLabel3";
            this.skinLabel3.Size = new System.Drawing.Size(83, 17);
            this.skinLabel3.TabIndex = 5;
            this.skinLabel3.Text = "读卡间隔时间:";
            // 
            // skinLabel2
            // 
            this.skinLabel2.AutoSize = true;
            this.skinLabel2.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel2.BorderColor = System.Drawing.Color.White;
            this.skinLabel2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel2.Location = new System.Drawing.Point(12, 45);
            this.skinLabel2.Name = "skinLabel2";
            this.skinLabel2.Size = new System.Drawing.Size(83, 17);
            this.skinLabel2.TabIndex = 4;
            this.skinLabel2.Text = "标签过滤时间:";
            // 
            // skinLabel32
            // 
            this.skinLabel32.AutoSize = true;
            this.skinLabel32.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel32.BorderColor = System.Drawing.Color.White;
            this.skinLabel32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel32.Location = new System.Drawing.Point(177, 45);
            this.skinLabel32.Name = "skinLabel32";
            this.skinLabel32.Size = new System.Drawing.Size(23, 17);
            this.skinLabel32.TabIndex = 19;
            this.skinLabel32.Text = "(S)";
            // 
            // skinNumericUpDown_work_filter
            // 
            this.skinNumericUpDown_work_filter.Location = new System.Drawing.Point(102, 42);
            this.skinNumericUpDown_work_filter.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.skinNumericUpDown_work_filter.Name = "skinNumericUpDown_work_filter";
            this.skinNumericUpDown_work_filter.Size = new System.Drawing.Size(69, 21);
            this.skinNumericUpDown_work_filter.TabIndex = 6;
            this.skinNumericUpDown_work_filter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // skinButton_reset
            // 
            this.skinButton_reset.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_reset.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_reset.DownBack = null;
            this.skinButton_reset.Location = new System.Drawing.Point(399, 254);
            this.skinButton_reset.MouseBack = null;
            this.skinButton_reset.Name = "skinButton_reset";
            this.skinButton_reset.NormlBack = null;
            this.skinButton_reset.Size = new System.Drawing.Size(75, 23);
            this.skinButton_reset.TabIndex = 17;
            this.skinButton_reset.Text = "重启设备";
            this.skinButton_reset.UseVisualStyleBackColor = false;
            this.skinButton_reset.Click += new System.EventHandler(this.skinButton_reset_Click);
            // 
            // skinButton_defualt
            // 
            this.skinButton_defualt.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_defualt.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_defualt.DownBack = null;
            this.skinButton_defualt.Location = new System.Drawing.Point(84, 254);
            this.skinButton_defualt.MouseBack = null;
            this.skinButton_defualt.Name = "skinButton_defualt";
            this.skinButton_defualt.NormlBack = null;
            this.skinButton_defualt.Size = new System.Drawing.Size(89, 23);
            this.skinButton_defualt.TabIndex = 16;
            this.skinButton_defualt.Text = "出厂设置";
            this.skinButton_defualt.UseVisualStyleBackColor = false;
            this.skinButton_defualt.Click += new System.EventHandler(this.skinButton_defualt_Click);
            // 
            // skinButton_work_set
            // 
            this.skinButton_work_set.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_work_set.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_work_set.DownBack = null;
            this.skinButton_work_set.Location = new System.Drawing.Point(301, 254);
            this.skinButton_work_set.MouseBack = null;
            this.skinButton_work_set.Name = "skinButton_work_set";
            this.skinButton_work_set.NormlBack = null;
            this.skinButton_work_set.Size = new System.Drawing.Size(75, 23);
            this.skinButton_work_set.TabIndex = 3;
            this.skinButton_work_set.Text = "设置参数";
            this.skinButton_work_set.UseVisualStyleBackColor = false;
            this.skinButton_work_set.Click += new System.EventHandler(this.skinButton_work_set_Click);
            // 
            // skinButton_work_refresh
            // 
            this.skinButton_work_refresh.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_work_refresh.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_work_refresh.DownBack = null;
            this.skinButton_work_refresh.Location = new System.Drawing.Point(201, 254);
            this.skinButton_work_refresh.MouseBack = null;
            this.skinButton_work_refresh.Name = "skinButton_work_refresh";
            this.skinButton_work_refresh.NormlBack = null;
            this.skinButton_work_refresh.Size = new System.Drawing.Size(75, 23);
            this.skinButton_work_refresh.TabIndex = 2;
            this.skinButton_work_refresh.Text = "刷新参数";
            this.skinButton_work_refresh.UseVisualStyleBackColor = false;
            this.skinButton_work_refresh.Click += new System.EventHandler(this.skinButton_work_refresh_Click);
            // 
            // tabPage_transfer
            // 
            this.tabPage_transfer.Controls.Add(this.skinGroupBox8);
            this.tabPage_transfer.Controls.Add(this.skinGroupBox5);
            this.tabPage_transfer.Controls.Add(this.skinComboBox_sub_protocol);
            this.tabPage_transfer.Controls.Add(this.skinButton_transfer_set);
            this.tabPage_transfer.Controls.Add(this.skinLabel29);
            this.tabPage_transfer.Controls.Add(this.skinButton_transfer_query);
            this.tabPage_transfer.Controls.Add(this.skinGroupBox3);
            this.tabPage_transfer.Controls.Add(this.skinComboBox_transfer_mode);
            this.tabPage_transfer.Controls.Add(this.skinLabel6);
            this.tabPage_transfer.Controls.Add(this.skinGroupBox2);
            this.tabPage_transfer.Controls.Add(this.skinGroupBox1);
            this.tabPage_transfer.Location = new System.Drawing.Point(4, 22);
            this.tabPage_transfer.Name = "tabPage_transfer";
            this.tabPage_transfer.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_transfer.Size = new System.Drawing.Size(578, 369);
            this.tabPage_transfer.TabIndex = 3;
            this.tabPage_transfer.Text = "传输参数";
            this.tabPage_transfer.UseVisualStyleBackColor = true;
            // 
            // skinGroupBox8
            // 
            this.skinGroupBox8.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox8.BorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox8.Controls.Add(this.dhcp_check);
            this.skinGroupBox8.Controls.Add(this.skinLabel12);
            this.skinGroupBox8.Controls.Add(this.skinWaterTextBox_ip_mac);
            this.skinGroupBox8.Controls.Add(this.skinWaterTextBox_gate_way);
            this.skinGroupBox8.Controls.Add(this.skinLabel13);
            this.skinGroupBox8.Controls.Add(this.skinWaterTextBox_ip_local);
            this.skinGroupBox8.Controls.Add(this.skinLabel19);
            this.skinGroupBox8.Controls.Add(this.skinLabel14);
            this.skinGroupBox8.Controls.Add(this.skinWaterTextBox_local_port);
            this.skinGroupBox8.Controls.Add(this.skinWaterTextBox_ip_sub_masker);
            this.skinGroupBox8.Controls.Add(this.skinLabel18);
            this.skinGroupBox8.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox8.Location = new System.Drawing.Point(5, 183);
            this.skinGroupBox8.Name = "skinGroupBox8";
            this.skinGroupBox8.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox8.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox8.Size = new System.Drawing.Size(566, 72);
            this.skinGroupBox8.TabIndex = 8;
            this.skinGroupBox8.TabStop = false;
            this.skinGroupBox8.Text = "读写器本地网络参数";
            this.skinGroupBox8.TitleBorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox8.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox8.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // dhcp_check
            // 
            this.dhcp_check.AutoSize = true;
            this.dhcp_check.BackColor = System.Drawing.Color.Transparent;
            this.dhcp_check.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.dhcp_check.DownBack = null;
            this.dhcp_check.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dhcp_check.Location = new System.Drawing.Point(36, 42);
            this.dhcp_check.MouseBack = null;
            this.dhcp_check.Name = "dhcp_check";
            this.dhcp_check.NormlBack = null;
            this.dhcp_check.SelectedDownBack = null;
            this.dhcp_check.SelectedMouseBack = null;
            this.dhcp_check.SelectedNormlBack = null;
            this.dhcp_check.Size = new System.Drawing.Size(60, 21);
            this.dhcp_check.TabIndex = 15;
            this.dhcp_check.Text = "DHCP";
            this.dhcp_check.UseVisualStyleBackColor = false;
            // 
            // skinLabel12
            // 
            this.skinLabel12.AutoSize = true;
            this.skinLabel12.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel12.BorderColor = System.Drawing.Color.White;
            this.skinLabel12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel12.Location = new System.Drawing.Point(391, 21);
            this.skinLabel12.Name = "skinLabel12";
            this.skinLabel12.Size = new System.Drawing.Size(39, 17);
            this.skinLabel12.TabIndex = 0;
            this.skinLabel12.Text = "MAC:";
            // 
            // skinWaterTextBox_ip_mac
            // 
            this.skinWaterTextBox_ip_mac.Location = new System.Drawing.Point(434, 18);
            this.skinWaterTextBox_ip_mac.Name = "skinWaterTextBox_ip_mac";
            this.skinWaterTextBox_ip_mac.Size = new System.Drawing.Size(113, 21);
            this.skinWaterTextBox_ip_mac.TabIndex = 1;
            this.skinWaterTextBox_ip_mac.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_ip_mac.WaterText = "";
            // 
            // skinWaterTextBox_gate_way
            // 
            this.skinWaterTextBox_gate_way.Location = new System.Drawing.Point(434, 42);
            this.skinWaterTextBox_gate_way.Name = "skinWaterTextBox_gate_way";
            this.skinWaterTextBox_gate_way.Size = new System.Drawing.Size(100, 21);
            this.skinWaterTextBox_gate_way.TabIndex = 16;
            this.skinWaterTextBox_gate_way.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_gate_way.WaterText = "";
            // 
            // skinLabel13
            // 
            this.skinLabel13.AutoSize = true;
            this.skinLabel13.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel13.BorderColor = System.Drawing.Color.White;
            this.skinLabel13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel13.Location = new System.Drawing.Point(32, 19);
            this.skinLabel13.Name = "skinLabel13";
            this.skinLabel13.Size = new System.Drawing.Size(26, 17);
            this.skinLabel13.TabIndex = 2;
            this.skinLabel13.Text = " IP:";
            // 
            // skinWaterTextBox_ip_local
            // 
            this.skinWaterTextBox_ip_local.Location = new System.Drawing.Point(62, 18);
            this.skinWaterTextBox_ip_local.Name = "skinWaterTextBox_ip_local";
            this.skinWaterTextBox_ip_local.Size = new System.Drawing.Size(104, 21);
            this.skinWaterTextBox_ip_local.TabIndex = 3;
            this.skinWaterTextBox_ip_local.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_ip_local.WaterText = "";
            // 
            // skinLabel19
            // 
            this.skinLabel19.AutoSize = true;
            this.skinLabel19.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel19.BorderColor = System.Drawing.Color.White;
            this.skinLabel19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel19.Location = new System.Drawing.Point(371, 43);
            this.skinLabel19.Name = "skinLabel19";
            this.skinLabel19.Size = new System.Drawing.Size(59, 17);
            this.skinLabel19.TabIndex = 15;
            this.skinLabel19.Text = "网关地址:";
            // 
            // skinLabel14
            // 
            this.skinLabel14.AutoSize = true;
            this.skinLabel14.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel14.BorderColor = System.Drawing.Color.White;
            this.skinLabel14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel14.Location = new System.Drawing.Point(190, 18);
            this.skinLabel14.Name = "skinLabel14";
            this.skinLabel14.Size = new System.Drawing.Size(35, 17);
            this.skinLabel14.TabIndex = 4;
            this.skinLabel14.Text = "端口:";
            // 
            // skinWaterTextBox_local_port
            // 
            this.skinWaterTextBox_local_port.Location = new System.Drawing.Point(231, 18);
            this.skinWaterTextBox_local_port.Name = "skinWaterTextBox_local_port";
            this.skinWaterTextBox_local_port.Size = new System.Drawing.Size(76, 21);
            this.skinWaterTextBox_local_port.TabIndex = 5;
            this.skinWaterTextBox_local_port.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_local_port.WaterText = "";
            // 
            // skinWaterTextBox_ip_sub_masker
            // 
            this.skinWaterTextBox_ip_sub_masker.Location = new System.Drawing.Point(231, 42);
            this.skinWaterTextBox_ip_sub_masker.Name = "skinWaterTextBox_ip_sub_masker";
            this.skinWaterTextBox_ip_sub_masker.Size = new System.Drawing.Size(100, 21);
            this.skinWaterTextBox_ip_sub_masker.TabIndex = 14;
            this.skinWaterTextBox_ip_sub_masker.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_ip_sub_masker.WaterText = "";
            // 
            // skinLabel18
            // 
            this.skinLabel18.AutoSize = true;
            this.skinLabel18.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel18.BorderColor = System.Drawing.Color.White;
            this.skinLabel18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel18.Location = new System.Drawing.Point(166, 43);
            this.skinLabel18.Name = "skinLabel18";
            this.skinLabel18.Size = new System.Drawing.Size(59, 17);
            this.skinLabel18.TabIndex = 13;
            this.skinLabel18.Text = "子网掩码:";
            // 
            // skinGroupBox5
            // 
            this.skinGroupBox5.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox5.BorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox5.Controls.Add(this.skinWaterTextBox_module_id);
            this.skinGroupBox5.Controls.Add(this.skinWaterTextBox_module_sn);
            this.skinGroupBox5.Controls.Add(this.skinLabel43);
            this.skinGroupBox5.Controls.Add(this.skinLabel42);
            this.skinGroupBox5.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox5.Location = new System.Drawing.Point(6, 110);
            this.skinGroupBox5.Name = "skinGroupBox5";
            this.skinGroupBox5.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox5.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox5.Size = new System.Drawing.Size(212, 66);
            this.skinGroupBox5.TabIndex = 7;
            this.skinGroupBox5.TabStop = false;
            this.skinGroupBox5.Text = "Syris485";
            this.skinGroupBox5.TitleBorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox5.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox5.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // skinWaterTextBox_module_id
            // 
            this.skinWaterTextBox_module_id.Location = new System.Drawing.Point(53, 43);
            this.skinWaterTextBox_module_id.Name = "skinWaterTextBox_module_id";
            this.skinWaterTextBox_module_id.Size = new System.Drawing.Size(100, 21);
            this.skinWaterTextBox_module_id.TabIndex = 3;
            this.skinWaterTextBox_module_id.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_module_id.WaterText = "";
            // 
            // skinWaterTextBox_module_sn
            // 
            this.skinWaterTextBox_module_sn.Location = new System.Drawing.Point(53, 21);
            this.skinWaterTextBox_module_sn.Name = "skinWaterTextBox_module_sn";
            this.skinWaterTextBox_module_sn.Size = new System.Drawing.Size(100, 21);
            this.skinWaterTextBox_module_sn.TabIndex = 2;
            this.skinWaterTextBox_module_sn.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_module_sn.WaterText = "";
            // 
            // skinLabel43
            // 
            this.skinLabel43.AutoSize = true;
            this.skinLabel43.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel43.BorderColor = System.Drawing.Color.White;
            this.skinLabel43.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel43.Location = new System.Drawing.Point(27, 45);
            this.skinLabel43.Name = "skinLabel43";
            this.skinLabel43.Size = new System.Drawing.Size(24, 17);
            this.skinLabel43.TabIndex = 1;
            this.skinLabel43.Text = "ID:";
            // 
            // skinLabel42
            // 
            this.skinLabel42.AutoSize = true;
            this.skinLabel42.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel42.BorderColor = System.Drawing.Color.White;
            this.skinLabel42.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel42.Location = new System.Drawing.Point(11, 22);
            this.skinLabel42.Name = "skinLabel42";
            this.skinLabel42.Size = new System.Drawing.Size(40, 17);
            this.skinLabel42.TabIndex = 0;
            this.skinLabel42.Text = "SN号:";
            // 
            // skinComboBox_sub_protocol
            // 
            this.skinComboBox_sub_protocol.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_sub_protocol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_sub_protocol.FormattingEnabled = true;
            this.skinComboBox_sub_protocol.Items.AddRange(new object[] {
            "TCP-Server",
            "TCP-Client",
            "UDP",
            "HTTP Client"});
            this.skinComboBox_sub_protocol.Location = new System.Drawing.Point(90, 35);
            this.skinComboBox_sub_protocol.Name = "skinComboBox_sub_protocol";
            this.skinComboBox_sub_protocol.Size = new System.Drawing.Size(122, 22);
            this.skinComboBox_sub_protocol.TabIndex = 22;
            this.skinComboBox_sub_protocol.WaterText = "";
            // 
            // skinButton_transfer_set
            // 
            this.skinButton_transfer_set.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_transfer_set.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_transfer_set.DownBack = null;
            this.skinButton_transfer_set.Location = new System.Drawing.Point(321, 343);
            this.skinButton_transfer_set.MouseBack = null;
            this.skinButton_transfer_set.Name = "skinButton_transfer_set";
            this.skinButton_transfer_set.NormlBack = null;
            this.skinButton_transfer_set.Size = new System.Drawing.Size(75, 23);
            this.skinButton_transfer_set.TabIndex = 6;
            this.skinButton_transfer_set.Text = "设置";
            this.skinButton_transfer_set.UseVisualStyleBackColor = false;
            this.skinButton_transfer_set.Click += new System.EventHandler(this.skinButton_transfer_set_Click);
            // 
            // skinLabel29
            // 
            this.skinLabel29.AutoSize = true;
            this.skinLabel29.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel29.BorderColor = System.Drawing.Color.White;
            this.skinLabel29.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel29.Location = new System.Drawing.Point(29, 36);
            this.skinLabel29.Name = "skinLabel29";
            this.skinLabel29.Size = new System.Drawing.Size(59, 17);
            this.skinLabel29.TabIndex = 21;
            this.skinLabel29.Text = "通信协议:";
            // 
            // skinButton_transfer_query
            // 
            this.skinButton_transfer_query.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_transfer_query.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_transfer_query.DownBack = null;
            this.skinButton_transfer_query.Location = new System.Drawing.Point(165, 343);
            this.skinButton_transfer_query.MouseBack = null;
            this.skinButton_transfer_query.Name = "skinButton_transfer_query";
            this.skinButton_transfer_query.NormlBack = null;
            this.skinButton_transfer_query.Size = new System.Drawing.Size(75, 23);
            this.skinButton_transfer_query.TabIndex = 5;
            this.skinButton_transfer_query.Text = "刷新";
            this.skinButton_transfer_query.UseVisualStyleBackColor = false;
            this.skinButton_transfer_query.Click += new System.EventHandler(this.skinButton_transfer_query_Click);
            // 
            // skinGroupBox3
            // 
            this.skinGroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox3.BorderColor = System.Drawing.Color.DarkCyan;
            this.skinGroupBox3.Controls.Add(this.radioButton_remote_ipmode_host);
            this.skinGroupBox3.Controls.Add(this.radioButton_remote_ipmode_IP);
            this.skinGroupBox3.Controls.Add(this.skinWaterTextBox_heart_beats);
            this.skinGroupBox3.Controls.Add(this.skinLabel17);
            this.skinGroupBox3.Controls.Add(this.skinLabel30);
            this.skinGroupBox3.Controls.Add(this.skinWaterTextBox_remote_port);
            this.skinGroupBox3.Controls.Add(this.skinWaterTextBox_ip_remote);
            this.skinGroupBox3.Controls.Add(this.skinLabel16);
            this.skinGroupBox3.Controls.Add(this.skinLabel15);
            this.skinGroupBox3.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox3.Location = new System.Drawing.Point(6, 258);
            this.skinGroupBox3.Name = "skinGroupBox3";
            this.skinGroupBox3.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox3.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox3.Size = new System.Drawing.Size(565, 79);
            this.skinGroupBox3.TabIndex = 4;
            this.skinGroupBox3.TabStop = false;
            this.skinGroupBox3.Text = "远端服务器参数";
            this.skinGroupBox3.TitleBorderColor = System.Drawing.Color.DarkCyan;
            this.skinGroupBox3.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox3.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // radioButton_remote_ipmode_host
            // 
            this.radioButton_remote_ipmode_host.AutoSize = true;
            this.radioButton_remote_ipmode_host.Location = new System.Drawing.Point(411, 18);
            this.radioButton_remote_ipmode_host.Name = "radioButton_remote_ipmode_host";
            this.radioButton_remote_ipmode_host.Size = new System.Drawing.Size(47, 16);
            this.radioButton_remote_ipmode_host.TabIndex = 23;
            this.radioButton_remote_ipmode_host.TabStop = true;
            this.radioButton_remote_ipmode_host.Text = "域名";
            this.radioButton_remote_ipmode_host.UseVisualStyleBackColor = true;
            // 
            // radioButton_remote_ipmode_IP
            // 
            this.radioButton_remote_ipmode_IP.AutoSize = true;
            this.radioButton_remote_ipmode_IP.Location = new System.Drawing.Point(346, 18);
            this.radioButton_remote_ipmode_IP.Name = "radioButton_remote_ipmode_IP";
            this.radioButton_remote_ipmode_IP.Size = new System.Drawing.Size(59, 16);
            this.radioButton_remote_ipmode_IP.TabIndex = 23;
            this.radioButton_remote_ipmode_IP.TabStop = true;
            this.radioButton_remote_ipmode_IP.Text = "IP格式";
            this.radioButton_remote_ipmode_IP.UseVisualStyleBackColor = true;
            // 
            // skinWaterTextBox_heart_beats
            // 
            this.skinWaterTextBox_heart_beats.Location = new System.Drawing.Point(286, 45);
            this.skinWaterTextBox_heart_beats.Name = "skinWaterTextBox_heart_beats";
            this.skinWaterTextBox_heart_beats.Size = new System.Drawing.Size(54, 21);
            this.skinWaterTextBox_heart_beats.TabIndex = 20;
            this.skinWaterTextBox_heart_beats.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_heart_beats.WaterText = "";
            // 
            // skinLabel17
            // 
            this.skinLabel17.AutoSize = true;
            this.skinLabel17.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel17.BorderColor = System.Drawing.Color.White;
            this.skinLabel17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel17.Location = new System.Drawing.Point(343, 47);
            this.skinLabel17.Name = "skinLabel17";
            this.skinLabel17.Size = new System.Drawing.Size(41, 17);
            this.skinLabel17.TabIndex = 20;
            this.skinLabel17.Text = "(*10s)";
            // 
            // skinLabel30
            // 
            this.skinLabel30.AutoSize = true;
            this.skinLabel30.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel30.BorderColor = System.Drawing.Color.White;
            this.skinLabel30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel30.Location = new System.Drawing.Point(224, 48);
            this.skinLabel30.Name = "skinLabel30";
            this.skinLabel30.Size = new System.Drawing.Size(59, 17);
            this.skinLabel30.TabIndex = 19;
            this.skinLabel30.Text = "心跳时间:";
            // 
            // skinWaterTextBox_remote_port
            // 
            this.skinWaterTextBox_remote_port.Location = new System.Drawing.Point(59, 45);
            this.skinWaterTextBox_remote_port.Name = "skinWaterTextBox_remote_port";
            this.skinWaterTextBox_remote_port.Size = new System.Drawing.Size(62, 21);
            this.skinWaterTextBox_remote_port.TabIndex = 9;
            this.skinWaterTextBox_remote_port.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_remote_port.WaterText = "";
            // 
            // skinWaterTextBox_ip_remote
            // 
            this.skinWaterTextBox_ip_remote.Location = new System.Drawing.Point(58, 18);
            this.skinWaterTextBox_ip_remote.Name = "skinWaterTextBox_ip_remote";
            this.skinWaterTextBox_ip_remote.Size = new System.Drawing.Size(268, 21);
            this.skinWaterTextBox_ip_remote.TabIndex = 8;
            this.skinWaterTextBox_ip_remote.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_ip_remote.WaterText = "";
            // 
            // skinLabel16
            // 
            this.skinLabel16.AutoSize = true;
            this.skinLabel16.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel16.BorderColor = System.Drawing.Color.White;
            this.skinLabel16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel16.Location = new System.Drawing.Point(8, 47);
            this.skinLabel16.Name = "skinLabel16";
            this.skinLabel16.Size = new System.Drawing.Size(47, 17);
            this.skinLabel16.TabIndex = 7;
            this.skinLabel16.Text = "端口号:";
            // 
            // skinLabel15
            // 
            this.skinLabel15.AutoSize = true;
            this.skinLabel15.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel15.BorderColor = System.Drawing.Color.White;
            this.skinLabel15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel15.Location = new System.Drawing.Point(18, 20);
            this.skinLabel15.Name = "skinLabel15";
            this.skinLabel15.Size = new System.Drawing.Size(35, 17);
            this.skinLabel15.TabIndex = 6;
            this.skinLabel15.Text = "地址:";
            // 
            // skinComboBox_transfer_mode
            // 
            this.skinComboBox_transfer_mode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_transfer_mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_transfer_mode.FormattingEnabled = true;
            this.skinComboBox_transfer_mode.Items.AddRange(new object[] {
            "RS232/RS485",
            "Wiegand",
            "RJ45",
            "Syris485",
            "4G",
            "ModbusRtu",
            "ModBusTcp",
            "USB Keyboard",
            "USB Virtual COM"});
            this.skinComboBox_transfer_mode.Location = new System.Drawing.Point(90, 6);
            this.skinComboBox_transfer_mode.Name = "skinComboBox_transfer_mode";
            this.skinComboBox_transfer_mode.Size = new System.Drawing.Size(122, 22);
            this.skinComboBox_transfer_mode.TabIndex = 3;
            this.skinComboBox_transfer_mode.WaterText = "";
            this.skinComboBox_transfer_mode.SelectedIndexChanged += new System.EventHandler(this.skinComboBox_transfer_mode_SelectedIndexChanged);
            // 
            // skinLabel6
            // 
            this.skinLabel6.AutoSize = true;
            this.skinLabel6.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel6.BorderColor = System.Drawing.Color.White;
            this.skinLabel6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel6.ForeColor = System.Drawing.Color.Blue;
            this.skinLabel6.Location = new System.Drawing.Point(7, 9);
            this.skinLabel6.Name = "skinLabel6";
            this.skinLabel6.Size = new System.Drawing.Size(83, 17);
            this.skinLabel6.TabIndex = 2;
            this.skinLabel6.Text = "数据传输接口:";
            // 
            // skinGroupBox2
            // 
            this.skinGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox2.BorderColor = System.Drawing.Color.DarkCyan;
            this.skinGroupBox2.Controls.Add(this.skinComboBox_wiegand_direction);
            this.skinGroupBox2.Controls.Add(this.label4);
            this.skinGroupBox2.Controls.Add(this.label3);
            this.skinGroupBox2.Controls.Add(this.label2);
            this.skinGroupBox2.Controls.Add(this.skinNumericUpDown_wiegand_location);
            this.skinGroupBox2.Controls.Add(this.skinWaterTextBox_wiegand_interval);
            this.skinGroupBox2.Controls.Add(this.skinWaterTextBox_wiegand_prorid);
            this.skinGroupBox2.Controls.Add(this.skinWaterTextBox_wiegand_width);
            this.skinGroupBox2.Controls.Add(this.skinComboBox_wiegand_protocl);
            this.skinGroupBox2.Controls.Add(this.skinLabel11);
            this.skinGroupBox2.Controls.Add(this.skinLabel10);
            this.skinGroupBox2.Controls.Add(this.skinLabel9);
            this.skinGroupBox2.Controls.Add(this.skinLabel8);
            this.skinGroupBox2.Controls.Add(this.skinLabel7);
            this.skinGroupBox2.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox2.Location = new System.Drawing.Point(275, 6);
            this.skinGroupBox2.Name = "skinGroupBox2";
            this.skinGroupBox2.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox2.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox2.Size = new System.Drawing.Size(297, 150);
            this.skinGroupBox2.TabIndex = 1;
            this.skinGroupBox2.TabStop = false;
            this.skinGroupBox2.Text = "韦根设置";
            this.skinGroupBox2.TitleBorderColor = System.Drawing.Color.DarkCyan;
            this.skinGroupBox2.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox2.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // skinComboBox_wiegand_direction
            // 
            this.skinComboBox_wiegand_direction.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_wiegand_direction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_wiegand_direction.FormattingEnabled = true;
            this.skinComboBox_wiegand_direction.Items.AddRange(new object[] {
            "MSB First",
            "LSB First"});
            this.skinComboBox_wiegand_direction.Location = new System.Drawing.Point(192, 120);
            this.skinComboBox_wiegand_direction.Name = "skinComboBox_wiegand_direction";
            this.skinComboBox_wiegand_direction.Size = new System.Drawing.Size(99, 22);
            this.skinComboBox_wiegand_direction.TabIndex = 14;
            this.skinComboBox_wiegand_direction.WaterText = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(192, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "(* 10ms)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(192, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 11;
            this.label3.Text = "(* 100 us)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "(*10 us)";
            // 
            // skinNumericUpDown_wiegand_location
            // 
            this.skinNumericUpDown_wiegand_location.Location = new System.Drawing.Point(122, 121);
            this.skinNumericUpDown_wiegand_location.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.skinNumericUpDown_wiegand_location.Name = "skinNumericUpDown_wiegand_location";
            this.skinNumericUpDown_wiegand_location.Size = new System.Drawing.Size(64, 21);
            this.skinNumericUpDown_wiegand_location.TabIndex = 9;
            this.skinNumericUpDown_wiegand_location.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // skinWaterTextBox_wiegand_interval
            // 
            this.skinWaterTextBox_wiegand_interval.Location = new System.Drawing.Point(122, 96);
            this.skinWaterTextBox_wiegand_interval.Name = "skinWaterTextBox_wiegand_interval";
            this.skinWaterTextBox_wiegand_interval.Size = new System.Drawing.Size(64, 21);
            this.skinWaterTextBox_wiegand_interval.TabIndex = 8;
            this.skinWaterTextBox_wiegand_interval.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_wiegand_interval.WaterText = "";
            // 
            // skinWaterTextBox_wiegand_prorid
            // 
            this.skinWaterTextBox_wiegand_prorid.Location = new System.Drawing.Point(122, 69);
            this.skinWaterTextBox_wiegand_prorid.Name = "skinWaterTextBox_wiegand_prorid";
            this.skinWaterTextBox_wiegand_prorid.Size = new System.Drawing.Size(64, 21);
            this.skinWaterTextBox_wiegand_prorid.TabIndex = 7;
            this.skinWaterTextBox_wiegand_prorid.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_wiegand_prorid.WaterText = "";
            // 
            // skinWaterTextBox_wiegand_width
            // 
            this.skinWaterTextBox_wiegand_width.Location = new System.Drawing.Point(122, 42);
            this.skinWaterTextBox_wiegand_width.Name = "skinWaterTextBox_wiegand_width";
            this.skinWaterTextBox_wiegand_width.Size = new System.Drawing.Size(64, 21);
            this.skinWaterTextBox_wiegand_width.TabIndex = 6;
            this.skinWaterTextBox_wiegand_width.WaterColor = System.Drawing.Color.DarkCyan;
            this.skinWaterTextBox_wiegand_width.WaterText = "";
            // 
            // skinComboBox_wiegand_protocl
            // 
            this.skinComboBox_wiegand_protocl.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_wiegand_protocl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_wiegand_protocl.FormattingEnabled = true;
            this.skinComboBox_wiegand_protocl.Items.AddRange(new object[] {
            "Wiegand26",
            "Wiegand32",
            "Wiegand34",
            "Wiegand44"});
            this.skinComboBox_wiegand_protocl.Location = new System.Drawing.Point(122, 18);
            this.skinComboBox_wiegand_protocl.Name = "skinComboBox_wiegand_protocl";
            this.skinComboBox_wiegand_protocl.Size = new System.Drawing.Size(98, 22);
            this.skinComboBox_wiegand_protocl.TabIndex = 5;
            this.skinComboBox_wiegand_protocl.WaterText = "";
            // 
            // skinLabel11
            // 
            this.skinLabel11.AutoSize = true;
            this.skinLabel11.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel11.BorderColor = System.Drawing.Color.White;
            this.skinLabel11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel11.Location = new System.Drawing.Point(35, 122);
            this.skinLabel11.Name = "skinLabel11";
            this.skinLabel11.Size = new System.Drawing.Size(83, 17);
            this.skinLabel11.TabIndex = 4;
            this.skinLabel11.Text = "输出标签位置:";
            // 
            // skinLabel10
            // 
            this.skinLabel10.AutoSize = true;
            this.skinLabel10.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel10.BorderColor = System.Drawing.Color.White;
            this.skinLabel10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel10.Location = new System.Drawing.Point(36, 96);
            this.skinLabel10.Name = "skinLabel10";
            this.skinLabel10.Size = new System.Drawing.Size(83, 17);
            this.skinLabel10.TabIndex = 3;
            this.skinLabel10.Text = "通信间隔时间:";
            // 
            // skinLabel9
            // 
            this.skinLabel9.AutoSize = true;
            this.skinLabel9.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel9.BorderColor = System.Drawing.Color.White;
            this.skinLabel9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel9.Location = new System.Drawing.Point(57, 74);
            this.skinLabel9.Name = "skinLabel9";
            this.skinLabel9.Size = new System.Drawing.Size(59, 17);
            this.skinLabel9.TabIndex = 2;
            this.skinLabel9.Text = "脉冲周期:";
            // 
            // skinLabel8
            // 
            this.skinLabel8.AutoSize = true;
            this.skinLabel8.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel8.BorderColor = System.Drawing.Color.White;
            this.skinLabel8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel8.Location = new System.Drawing.Point(57, 45);
            this.skinLabel8.Name = "skinLabel8";
            this.skinLabel8.Size = new System.Drawing.Size(59, 17);
            this.skinLabel8.TabIndex = 1;
            this.skinLabel8.Text = "脉冲宽度:";
            // 
            // skinLabel7
            // 
            this.skinLabel7.AutoSize = true;
            this.skinLabel7.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel7.BorderColor = System.Drawing.Color.White;
            this.skinLabel7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel7.Location = new System.Drawing.Point(61, 18);
            this.skinLabel7.Name = "skinLabel7";
            this.skinLabel7.Size = new System.Drawing.Size(59, 17);
            this.skinLabel7.TabIndex = 0;
            this.skinLabel7.Text = "韦根协议:";
            // 
            // skinGroupBox1
            // 
            this.skinGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox1.BorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox1.Controls.Add(this.skinComboBox_transfer_baudrate);
            this.skinGroupBox1.Controls.Add(this.skinLabel5);
            this.skinGroupBox1.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox1.Location = new System.Drawing.Point(6, 61);
            this.skinGroupBox1.Name = "skinGroupBox1";
            this.skinGroupBox1.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox1.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox1.Size = new System.Drawing.Size(213, 47);
            this.skinGroupBox1.TabIndex = 0;
            this.skinGroupBox1.TabStop = false;
            this.skinGroupBox1.Text = "RS232 / RS485";
            this.skinGroupBox1.TitleBorderColor = System.Drawing.Color.DarkCyan;
            this.skinGroupBox1.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox1.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // skinComboBox_transfer_baudrate
            // 
            this.skinComboBox_transfer_baudrate.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_transfer_baudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_transfer_baudrate.FormattingEnabled = true;
            this.skinComboBox_transfer_baudrate.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.skinComboBox_transfer_baudrate.Location = new System.Drawing.Point(102, 18);
            this.skinComboBox_transfer_baudrate.Name = "skinComboBox_transfer_baudrate";
            this.skinComboBox_transfer_baudrate.Size = new System.Drawing.Size(99, 22);
            this.skinComboBox_transfer_baudrate.TabIndex = 1;
            this.skinComboBox_transfer_baudrate.WaterText = "";
            // 
            // skinLabel5
            // 
            this.skinLabel5.AutoSize = true;
            this.skinLabel5.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel5.BorderColor = System.Drawing.Color.White;
            this.skinLabel5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel5.Location = new System.Drawing.Point(31, 21);
            this.skinLabel5.Name = "skinLabel5";
            this.skinLabel5.Size = new System.Drawing.Size(64, 17);
            this.skinLabel5.TabIndex = 0;
            this.skinLabel5.Text = "Baudrate:";
            // 
            // tabPage_advance
            // 
            this.tabPage_advance.Controls.Add(this.label27);
            this.tabPage_advance.Controls.Add(this.textBox_advan_rssi);
            this.tabPage_advance.Controls.Add(this.skinNumericUpDown_advan_Q);
            this.tabPage_advance.Controls.Add(this.skinButton_advance_set);
            this.tabPage_advance.Controls.Add(this.skinButton_advance_refresh);
            this.tabPage_advance.Controls.Add(this.skinLabel28);
            this.tabPage_advance.Controls.Add(this.skinLabel27);
            this.tabPage_advance.Controls.Add(this.skinComboBox_advan_target);
            this.tabPage_advance.Controls.Add(this.skinLabel26);
            this.tabPage_advance.Controls.Add(this.skinComboBox_advan_session);
            this.tabPage_advance.Controls.Add(this.skinLabel25);
            this.tabPage_advance.Controls.Add(this.skinComboBox_advan_sel);
            this.tabPage_advance.Controls.Add(this.skinLabel24);
            this.tabPage_advance.Controls.Add(this.skinComboBox_advan_cw);
            this.tabPage_advance.Controls.Add(this.skinLabel23);
            this.tabPage_advance.Controls.Add(this.skinComboBox_advan_hopping);
            this.tabPage_advance.Controls.Add(this.skinLabel22);
            this.tabPage_advance.Controls.Add(this.skinWaterTextBox_advan_channel);
            this.tabPage_advance.Controls.Add(this.skinLabel21);
            this.tabPage_advance.Controls.Add(this.skinComboBox_advan_region);
            this.tabPage_advance.Controls.Add(this.skinLabel20);
            this.tabPage_advance.Location = new System.Drawing.Point(4, 22);
            this.tabPage_advance.Name = "tabPage_advance";
            this.tabPage_advance.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_advance.Size = new System.Drawing.Size(578, 369);
            this.tabPage_advance.TabIndex = 4;
            this.tabPage_advance.Text = "射频参数";
            this.tabPage_advance.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(146, 83);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 12);
            this.label27.TabIndex = 22;
            this.label27.Text = "(0~255)";
            // 
            // textBox_advan_rssi
            // 
            this.textBox_advan_rssi.Location = new System.Drawing.Point(78, 78);
            this.textBox_advan_rssi.Name = "textBox_advan_rssi";
            this.textBox_advan_rssi.Size = new System.Drawing.Size(61, 21);
            this.textBox_advan_rssi.TabIndex = 21;
            // 
            // skinNumericUpDown_advan_Q
            // 
            this.skinNumericUpDown_advan_Q.Location = new System.Drawing.Point(389, 42);
            this.skinNumericUpDown_advan_Q.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.skinNumericUpDown_advan_Q.Name = "skinNumericUpDown_advan_Q";
            this.skinNumericUpDown_advan_Q.Size = new System.Drawing.Size(43, 21);
            this.skinNumericUpDown_advan_Q.TabIndex = 20;
            this.skinNumericUpDown_advan_Q.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // skinButton_advance_set
            // 
            this.skinButton_advance_set.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_advance_set.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_advance_set.DownBack = null;
            this.skinButton_advance_set.Location = new System.Drawing.Point(309, 119);
            this.skinButton_advance_set.MouseBack = null;
            this.skinButton_advance_set.Name = "skinButton_advance_set";
            this.skinButton_advance_set.NormlBack = null;
            this.skinButton_advance_set.Size = new System.Drawing.Size(75, 23);
            this.skinButton_advance_set.TabIndex = 19;
            this.skinButton_advance_set.Text = "设置";
            this.skinButton_advance_set.UseVisualStyleBackColor = false;
            this.skinButton_advance_set.Click += new System.EventHandler(this.skinButton_advance_set_Click);
            // 
            // skinButton_advance_refresh
            // 
            this.skinButton_advance_refresh.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_advance_refresh.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_advance_refresh.DownBack = null;
            this.skinButton_advance_refresh.Location = new System.Drawing.Point(162, 119);
            this.skinButton_advance_refresh.MouseBack = null;
            this.skinButton_advance_refresh.Name = "skinButton_advance_refresh";
            this.skinButton_advance_refresh.NormlBack = null;
            this.skinButton_advance_refresh.Size = new System.Drawing.Size(75, 23);
            this.skinButton_advance_refresh.TabIndex = 18;
            this.skinButton_advance_refresh.Text = "刷新";
            this.skinButton_advance_refresh.UseVisualStyleBackColor = false;
            this.skinButton_advance_refresh.Click += new System.EventHandler(this.skinButton_advance_refresh_Click);
            // 
            // skinLabel28
            // 
            this.skinLabel28.AutoSize = true;
            this.skinLabel28.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel28.BorderColor = System.Drawing.Color.White;
            this.skinLabel28.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel28.Location = new System.Drawing.Point(11, 81);
            this.skinLabel28.Name = "skinLabel28";
            this.skinLabel28.Size = new System.Drawing.Size(61, 17);
            this.skinLabel28.TabIndex = 16;
            this.skinLabel28.Text = "RSSI阀值:";
            // 
            // skinLabel27
            // 
            this.skinLabel27.AutoSize = true;
            this.skinLabel27.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel27.BorderColor = System.Drawing.Color.White;
            this.skinLabel27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel27.Location = new System.Drawing.Point(331, 43);
            this.skinLabel27.Name = "skinLabel27";
            this.skinLabel27.Size = new System.Drawing.Size(37, 17);
            this.skinLabel27.TabIndex = 14;
            this.skinLabel27.Text = "Q 值:";
            // 
            // skinComboBox_advan_target
            // 
            this.skinComboBox_advan_target.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_advan_target.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_advan_target.FormattingEnabled = true;
            this.skinComboBox_advan_target.Items.AddRange(new object[] {
            "target A",
            "target B"});
            this.skinComboBox_advan_target.Location = new System.Drawing.Point(486, 43);
            this.skinComboBox_advan_target.Name = "skinComboBox_advan_target";
            this.skinComboBox_advan_target.Size = new System.Drawing.Size(86, 22);
            this.skinComboBox_advan_target.TabIndex = 13;
            this.skinComboBox_advan_target.WaterText = "";
            // 
            // skinLabel26
            // 
            this.skinLabel26.AutoSize = true;
            this.skinLabel26.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel26.BorderColor = System.Drawing.Color.White;
            this.skinLabel26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel26.Location = new System.Drawing.Point(437, 43);
            this.skinLabel26.Name = "skinLabel26";
            this.skinLabel26.Size = new System.Drawing.Size(49, 17);
            this.skinLabel26.TabIndex = 12;
            this.skinLabel26.Text = "Target:";
            // 
            // skinComboBox_advan_session
            // 
            this.skinComboBox_advan_session.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_advan_session.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_advan_session.FormattingEnabled = true;
            this.skinComboBox_advan_session.Items.AddRange(new object[] {
            "Sesion0",
            "Session1",
            "Session2",
            "Session3"});
            this.skinComboBox_advan_session.Location = new System.Drawing.Point(252, 41);
            this.skinComboBox_advan_session.Name = "skinComboBox_advan_session";
            this.skinComboBox_advan_session.Size = new System.Drawing.Size(67, 22);
            this.skinComboBox_advan_session.TabIndex = 11;
            this.skinComboBox_advan_session.WaterText = "";
            // 
            // skinLabel25
            // 
            this.skinLabel25.AutoSize = true;
            this.skinLabel25.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel25.BorderColor = System.Drawing.Color.White;
            this.skinLabel25.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel25.Location = new System.Drawing.Point(197, 42);
            this.skinLabel25.Name = "skinLabel25";
            this.skinLabel25.Size = new System.Drawing.Size(55, 17);
            this.skinLabel25.TabIndex = 10;
            this.skinLabel25.Text = "Session:";
            // 
            // skinComboBox_advan_sel
            // 
            this.skinComboBox_advan_sel.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_advan_sel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_advan_sel.FormattingEnabled = true;
            this.skinComboBox_advan_sel.Items.AddRange(new object[] {
            "ALL",
            "ALL",
            "~SL",
            "SL"});
            this.skinComboBox_advan_sel.Location = new System.Drawing.Point(129, 41);
            this.skinComboBox_advan_sel.Name = "skinComboBox_advan_sel";
            this.skinComboBox_advan_sel.Size = new System.Drawing.Size(56, 22);
            this.skinComboBox_advan_sel.TabIndex = 9;
            this.skinComboBox_advan_sel.WaterText = "";
            // 
            // skinLabel24
            // 
            this.skinLabel24.AutoSize = true;
            this.skinLabel24.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel24.BorderColor = System.Drawing.Color.White;
            this.skinLabel24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel24.Location = new System.Drawing.Point(102, 43);
            this.skinLabel24.Name = "skinLabel24";
            this.skinLabel24.Size = new System.Drawing.Size(28, 17);
            this.skinLabel24.TabIndex = 8;
            this.skinLabel24.Text = "Sel:";
            // 
            // skinComboBox_advan_cw
            // 
            this.skinComboBox_advan_cw.AutoCompleteCustomSource.AddRange(new string[] {
            "off",
            "on"});
            this.skinComboBox_advan_cw.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_advan_cw.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_advan_cw.FormattingEnabled = true;
            this.skinComboBox_advan_cw.Items.AddRange(new object[] {
            "off",
            "on"});
            this.skinComboBox_advan_cw.Location = new System.Drawing.Point(39, 42);
            this.skinComboBox_advan_cw.Name = "skinComboBox_advan_cw";
            this.skinComboBox_advan_cw.Size = new System.Drawing.Size(56, 22);
            this.skinComboBox_advan_cw.TabIndex = 7;
            this.skinComboBox_advan_cw.WaterText = "";
            // 
            // skinLabel23
            // 
            this.skinLabel23.AutoSize = true;
            this.skinLabel23.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel23.BorderColor = System.Drawing.Color.White;
            this.skinLabel23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel23.Location = new System.Drawing.Point(7, 43);
            this.skinLabel23.Name = "skinLabel23";
            this.skinLabel23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.skinLabel23.Size = new System.Drawing.Size(31, 17);
            this.skinLabel23.TabIndex = 6;
            this.skinLabel23.Text = "CW:";
            // 
            // skinComboBox_advan_hopping
            // 
            this.skinComboBox_advan_hopping.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_advan_hopping.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_advan_hopping.FormattingEnabled = true;
            this.skinComboBox_advan_hopping.Items.AddRange(new object[] {
            "关闭跳频",
            "开启跳频"});
            this.skinComboBox_advan_hopping.Location = new System.Drawing.Point(440, 12);
            this.skinComboBox_advan_hopping.Name = "skinComboBox_advan_hopping";
            this.skinComboBox_advan_hopping.Size = new System.Drawing.Size(90, 22);
            this.skinComboBox_advan_hopping.TabIndex = 5;
            this.skinComboBox_advan_hopping.WaterText = "";
            // 
            // skinLabel22
            // 
            this.skinLabel22.AutoSize = true;
            this.skinLabel22.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel22.BorderColor = System.Drawing.Color.White;
            this.skinLabel22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel22.Location = new System.Drawing.Point(397, 14);
            this.skinLabel22.Name = "skinLabel22";
            this.skinLabel22.Size = new System.Drawing.Size(35, 17);
            this.skinLabel22.TabIndex = 4;
            this.skinLabel22.Text = "跳频:";
            // 
            // skinWaterTextBox_advan_channel
            // 
            this.skinWaterTextBox_advan_channel.Location = new System.Drawing.Point(278, 12);
            this.skinWaterTextBox_advan_channel.Name = "skinWaterTextBox_advan_channel";
            this.skinWaterTextBox_advan_channel.Size = new System.Drawing.Size(100, 21);
            this.skinWaterTextBox_advan_channel.TabIndex = 3;
            this.skinWaterTextBox_advan_channel.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_advan_channel.WaterText = "";
            // 
            // skinLabel21
            // 
            this.skinLabel21.AutoSize = true;
            this.skinLabel21.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel21.BorderColor = System.Drawing.Color.White;
            this.skinLabel21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel21.Location = new System.Drawing.Point(213, 13);
            this.skinLabel21.Name = "skinLabel21";
            this.skinLabel21.Size = new System.Drawing.Size(59, 17);
            this.skinLabel21.TabIndex = 2;
            this.skinLabel21.Text = "射频通道:";
            // 
            // skinComboBox_advan_region
            // 
            this.skinComboBox_advan_region.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_advan_region.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_advan_region.FormattingEnabled = true;
            this.skinComboBox_advan_region.Items.AddRange(new object[] {
            "North America",
            "Europe",
            "China"});
            this.skinComboBox_advan_region.Location = new System.Drawing.Point(67, 12);
            this.skinComboBox_advan_region.Name = "skinComboBox_advan_region";
            this.skinComboBox_advan_region.Size = new System.Drawing.Size(119, 22);
            this.skinComboBox_advan_region.TabIndex = 1;
            this.skinComboBox_advan_region.WaterText = "";
            // 
            // skinLabel20
            // 
            this.skinLabel20.AutoSize = true;
            this.skinLabel20.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel20.BorderColor = System.Drawing.Color.White;
            this.skinLabel20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel20.Location = new System.Drawing.Point(11, 14);
            this.skinLabel20.Name = "skinLabel20";
            this.skinLabel20.Size = new System.Drawing.Size(59, 17);
            this.skinLabel20.TabIndex = 0;
            this.skinLabel20.Text = "射频区域:";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.skinButton_tag_verify);
            this.tabPage1.Controls.Add(this.skinButton_kill_tag);
            this.tabPage1.Controls.Add(this.skinButton_tag_lock);
            this.tabPage1.Controls.Add(this.comboBox_lock_type);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.skinGroupBox4);
            this.tabPage1.Controls.Add(this.skinButton_wiegand_write);
            this.tabPage1.Controls.Add(this.skinWaterTextBox_wiegand_write_data);
            this.tabPage1.Controls.Add(this.skinLabel51);
            this.tabPage1.Controls.Add(this.skinLine1);
            this.tabPage1.Controls.Add(this.skinTextBox_opt_result);
            this.tabPage1.Controls.Add(this.skinLabel41);
            this.tabPage1.Controls.Add(this.skinButton_operation_read);
            this.tabPage1.Controls.Add(this.skinButton_operation_write);
            this.tabPage1.Controls.Add(this.skinWater_content);
            this.tabPage1.Controls.Add(this.skinLabel40);
            this.tabPage1.Controls.Add(this.skinWaterTextBox_password);
            this.tabPage1.Controls.Add(this.skinLabel39);
            this.tabPage1.Controls.Add(this.skinWaterTextBox_length);
            this.tabPage1.Controls.Add(this.skinLabel38);
            this.tabPage1.Controls.Add(this.skinWaterTextBox_address);
            this.tabPage1.Controls.Add(this.skinLabel37);
            this.tabPage1.Controls.Add(this.skinComboBox_membank);
            this.tabPage1.Controls.Add(this.skinLabel36);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(578, 369);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "标签操作";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // skinButton_tag_verify
            // 
            this.skinButton_tag_verify.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_tag_verify.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_tag_verify.DownBack = null;
            this.skinButton_tag_verify.Location = new System.Drawing.Point(174, 179);
            this.skinButton_tag_verify.MouseBack = null;
            this.skinButton_tag_verify.Name = "skinButton_tag_verify";
            this.skinButton_tag_verify.NormlBack = null;
            this.skinButton_tag_verify.Size = new System.Drawing.Size(75, 23);
            this.skinButton_tag_verify.TabIndex = 23;
            this.skinButton_tag_verify.Text = "校验标签";
            this.skinButton_tag_verify.UseVisualStyleBackColor = false;
            this.skinButton_tag_verify.Click += new System.EventHandler(this.skinButton_tag_verify_Click);
            // 
            // skinButton_kill_tag
            // 
            this.skinButton_kill_tag.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_kill_tag.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_kill_tag.DownBack = null;
            this.skinButton_kill_tag.Location = new System.Drawing.Point(79, 179);
            this.skinButton_kill_tag.MouseBack = null;
            this.skinButton_kill_tag.Name = "skinButton_kill_tag";
            this.skinButton_kill_tag.NormlBack = null;
            this.skinButton_kill_tag.Size = new System.Drawing.Size(75, 23);
            this.skinButton_kill_tag.TabIndex = 22;
            this.skinButton_kill_tag.Text = "销毁标签";
            this.skinButton_kill_tag.UseVisualStyleBackColor = false;
            this.skinButton_kill_tag.Click += new System.EventHandler(this.skinButton_kill_tag_Click);
            // 
            // skinButton_tag_lock
            // 
            this.skinButton_tag_lock.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_tag_lock.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_tag_lock.DownBack = null;
            this.skinButton_tag_lock.Location = new System.Drawing.Point(302, 149);
            this.skinButton_tag_lock.MouseBack = null;
            this.skinButton_tag_lock.Name = "skinButton_tag_lock";
            this.skinButton_tag_lock.NormlBack = null;
            this.skinButton_tag_lock.Size = new System.Drawing.Size(75, 23);
            this.skinButton_tag_lock.TabIndex = 21;
            this.skinButton_tag_lock.Text = "锁定";
            this.skinButton_tag_lock.UseVisualStyleBackColor = false;
            this.skinButton_tag_lock.Click += new System.EventHandler(this.skinButton_tag_lock_Click);
            // 
            // comboBox_lock_type
            // 
            this.comboBox_lock_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_lock_type.FormattingEnabled = true;
            this.comboBox_lock_type.Items.AddRange(new object[] {
            "无操作",
            "锁定写EPC(需要密码访问)",
            "永久锁定EPC(需要密码访问，不可更改)",
            "取消密码访问EPC",
            "锁定写USER区",
            "永久锁定USER区(需要密码访问，不可更改)",
            "取消锁定USER区",
            "密码访问ACCESS",
            "永久锁定ACCESS",
            "取消密码访问ACCESS",
            "密码访问KILL",
            "永久锁定KILL",
            "解锁KILL"});
            this.comboBox_lock_type.Location = new System.Drawing.Point(79, 151);
            this.comboBox_lock_type.Name = "comboBox_lock_type";
            this.comboBox_lock_type.Size = new System.Drawing.Size(208, 20);
            this.comboBox_lock_type.TabIndex = 20;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(17, 154);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 19;
            this.label16.Text = "锁定操作：";
            // 
            // skinGroupBox4
            // 
            this.skinGroupBox4.BackColor = System.Drawing.Color.Transparent;
            this.skinGroupBox4.BorderColor = System.Drawing.Color.Teal;
            this.skinGroupBox4.Controls.Add(this.skinButton_query_time);
            this.skinGroupBox4.Controls.Add(this.skinButton_sync_time);
            this.skinGroupBox4.Controls.Add(this.skinButton_upload_record);
            this.skinGroupBox4.ForeColor = System.Drawing.Color.Blue;
            this.skinGroupBox4.Location = new System.Drawing.Point(9, 301);
            this.skinGroupBox4.Name = "skinGroupBox4";
            this.skinGroupBox4.RectBackColor = System.Drawing.Color.White;
            this.skinGroupBox4.RoundStyle = CCWin.SkinClass.RoundStyle.All;
            this.skinGroupBox4.Size = new System.Drawing.Size(561, 48);
            this.skinGroupBox4.TabIndex = 18;
            this.skinGroupBox4.TabStop = false;
            this.skinGroupBox4.Text = "标签记录";
            this.skinGroupBox4.TitleBorderColor = System.Drawing.Color.Red;
            this.skinGroupBox4.TitleRectBackColor = System.Drawing.Color.White;
            this.skinGroupBox4.TitleRoundStyle = CCWin.SkinClass.RoundStyle.All;
            // 
            // skinButton_query_time
            // 
            this.skinButton_query_time.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_query_time.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_query_time.DownBack = null;
            this.skinButton_query_time.Location = new System.Drawing.Point(237, 19);
            this.skinButton_query_time.MouseBack = null;
            this.skinButton_query_time.Name = "skinButton_query_time";
            this.skinButton_query_time.NormlBack = null;
            this.skinButton_query_time.Size = new System.Drawing.Size(75, 21);
            this.skinButton_query_time.TabIndex = 2;
            this.skinButton_query_time.Text = "查询时间";
            this.skinButton_query_time.UseVisualStyleBackColor = false;
            this.skinButton_query_time.Click += new System.EventHandler(this.skinButton_query_time_Click);
            // 
            // skinButton_sync_time
            // 
            this.skinButton_sync_time.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_sync_time.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_sync_time.DownBack = null;
            this.skinButton_sync_time.Location = new System.Drawing.Point(134, 19);
            this.skinButton_sync_time.MouseBack = null;
            this.skinButton_sync_time.Name = "skinButton_sync_time";
            this.skinButton_sync_time.NormlBack = null;
            this.skinButton_sync_time.Size = new System.Drawing.Size(75, 21);
            this.skinButton_sync_time.TabIndex = 1;
            this.skinButton_sync_time.Text = "同步时间";
            this.skinButton_sync_time.UseVisualStyleBackColor = false;
            this.skinButton_sync_time.Click += new System.EventHandler(this.skinButton_sync_time_Click);
            // 
            // skinButton_upload_record
            // 
            this.skinButton_upload_record.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_upload_record.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_upload_record.DownBack = null;
            this.skinButton_upload_record.Location = new System.Drawing.Point(12, 19);
            this.skinButton_upload_record.MouseBack = null;
            this.skinButton_upload_record.Name = "skinButton_upload_record";
            this.skinButton_upload_record.NormlBack = null;
            this.skinButton_upload_record.Size = new System.Drawing.Size(89, 21);
            this.skinButton_upload_record.TabIndex = 0;
            this.skinButton_upload_record.Text = "读取标签记录";
            this.skinButton_upload_record.UseVisualStyleBackColor = false;
            this.skinButton_upload_record.Click += new System.EventHandler(this.skinButton_upload_record_Click);
            // 
            // skinButton_wiegand_write
            // 
            this.skinButton_wiegand_write.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_wiegand_write.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_wiegand_write.DownBack = null;
            this.skinButton_wiegand_write.Location = new System.Drawing.Point(213, 277);
            this.skinButton_wiegand_write.Margin = new System.Windows.Forms.Padding(2);
            this.skinButton_wiegand_write.MouseBack = null;
            this.skinButton_wiegand_write.Name = "skinButton_wiegand_write";
            this.skinButton_wiegand_write.NormlBack = null;
            this.skinButton_wiegand_write.Size = new System.Drawing.Size(75, 18);
            this.skinButton_wiegand_write.TabIndex = 17;
            this.skinButton_wiegand_write.Text = "韦根写入";
            this.skinButton_wiegand_write.UseVisualStyleBackColor = false;
            this.skinButton_wiegand_write.Click += new System.EventHandler(this.skinButton_wiegand_write_Click);
            // 
            // skinWaterTextBox_wiegand_write_data
            // 
            this.skinWaterTextBox_wiegand_write_data.Location = new System.Drawing.Point(80, 277);
            this.skinWaterTextBox_wiegand_write_data.Margin = new System.Windows.Forms.Padding(2);
            this.skinWaterTextBox_wiegand_write_data.Name = "skinWaterTextBox_wiegand_write_data";
            this.skinWaterTextBox_wiegand_write_data.Size = new System.Drawing.Size(129, 21);
            this.skinWaterTextBox_wiegand_write_data.TabIndex = 16;
            this.skinWaterTextBox_wiegand_write_data.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_wiegand_write_data.WaterText = "";
            // 
            // skinLabel51
            // 
            this.skinLabel51.AutoSize = true;
            this.skinLabel51.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel51.BorderColor = System.Drawing.Color.White;
            this.skinLabel51.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel51.Location = new System.Drawing.Point(17, 278);
            this.skinLabel51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.skinLabel51.Name = "skinLabel51";
            this.skinLabel51.Size = new System.Drawing.Size(59, 17);
            this.skinLabel51.TabIndex = 15;
            this.skinLabel51.Text = "韦根数据:";
            // 
            // skinLine1
            // 
            this.skinLine1.BackColor = System.Drawing.Color.Transparent;
            this.skinLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.skinLine1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.skinLine1.LineHeight = 1;
            this.skinLine1.Location = new System.Drawing.Point(2, 221);
            this.skinLine1.Margin = new System.Windows.Forms.Padding(2);
            this.skinLine1.Name = "skinLine1";
            this.skinLine1.Size = new System.Drawing.Size(567, 9);
            this.skinLine1.TabIndex = 14;
            this.skinLine1.Text = "skinLine1";
            // 
            // skinTextBox_opt_result
            // 
            this.skinTextBox_opt_result.BackColor = System.Drawing.Color.Transparent;
            this.skinTextBox_opt_result.DownBack = null;
            this.skinTextBox_opt_result.Icon = null;
            this.skinTextBox_opt_result.IconIsButton = false;
            this.skinTextBox_opt_result.IconMouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox_opt_result.IsPasswordChat = '\0';
            this.skinTextBox_opt_result.IsSystemPasswordChar = false;
            this.skinTextBox_opt_result.Lines = new string[0];
            this.skinTextBox_opt_result.Location = new System.Drawing.Point(79, 106);
            this.skinTextBox_opt_result.Margin = new System.Windows.Forms.Padding(0);
            this.skinTextBox_opt_result.MaxLength = 32767;
            this.skinTextBox_opt_result.MinimumSize = new System.Drawing.Size(28, 27);
            this.skinTextBox_opt_result.MouseBack = null;
            this.skinTextBox_opt_result.MouseState = CCWin.SkinClass.ControlState.Normal;
            this.skinTextBox_opt_result.Multiline = true;
            this.skinTextBox_opt_result.Name = "skinTextBox_opt_result";
            this.skinTextBox_opt_result.NormlBack = null;
            this.skinTextBox_opt_result.Padding = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.skinTextBox_opt_result.ReadOnly = false;
            this.skinTextBox_opt_result.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.skinTextBox_opt_result.Size = new System.Drawing.Size(491, 38);
            // 
            // 
            // 
            this.skinTextBox_opt_result.SkinTxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.skinTextBox_opt_result.SkinTxt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.skinTextBox_opt_result.SkinTxt.Font = new System.Drawing.Font("微软雅黑", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinTextBox_opt_result.SkinTxt.Location = new System.Drawing.Point(5, 6);
            this.skinTextBox_opt_result.SkinTxt.Multiline = true;
            this.skinTextBox_opt_result.SkinTxt.Name = "BaseText";
            this.skinTextBox_opt_result.SkinTxt.Size = new System.Drawing.Size(481, 26);
            this.skinTextBox_opt_result.SkinTxt.TabIndex = 0;
            this.skinTextBox_opt_result.SkinTxt.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox_opt_result.SkinTxt.WaterText = "";
            this.skinTextBox_opt_result.TabIndex = 13;
            this.skinTextBox_opt_result.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.skinTextBox_opt_result.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinTextBox_opt_result.WaterText = "";
            this.skinTextBox_opt_result.WordWrap = true;
            // 
            // skinLabel41
            // 
            this.skinLabel41.AutoSize = true;
            this.skinLabel41.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel41.BorderColor = System.Drawing.Color.White;
            this.skinLabel41.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel41.Location = new System.Drawing.Point(17, 106);
            this.skinLabel41.Name = "skinLabel41";
            this.skinLabel41.Size = new System.Drawing.Size(59, 17);
            this.skinLabel41.TabIndex = 12;
            this.skinLabel41.Text = "读取结果:";
            // 
            // skinButton_operation_read
            // 
            this.skinButton_operation_read.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_operation_read.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_operation_read.DownBack = null;
            this.skinButton_operation_read.Location = new System.Drawing.Point(232, 42);
            this.skinButton_operation_read.MouseBack = null;
            this.skinButton_operation_read.Name = "skinButton_operation_read";
            this.skinButton_operation_read.NormlBack = null;
            this.skinButton_operation_read.Size = new System.Drawing.Size(75, 23);
            this.skinButton_operation_read.TabIndex = 11;
            this.skinButton_operation_read.Text = "读标签";
            this.skinButton_operation_read.UseVisualStyleBackColor = false;
            this.skinButton_operation_read.Click += new System.EventHandler(this.skinButton_operation_read_Click);
            // 
            // skinButton_operation_write
            // 
            this.skinButton_operation_write.BackColor = System.Drawing.Color.Transparent;
            this.skinButton_operation_write.ControlState = CCWin.SkinClass.ControlState.Normal;
            this.skinButton_operation_write.DownBack = null;
            this.skinButton_operation_write.Location = new System.Drawing.Point(339, 42);
            this.skinButton_operation_write.MouseBack = null;
            this.skinButton_operation_write.Name = "skinButton_operation_write";
            this.skinButton_operation_write.NormlBack = null;
            this.skinButton_operation_write.Size = new System.Drawing.Size(75, 23);
            this.skinButton_operation_write.TabIndex = 10;
            this.skinButton_operation_write.Text = "写标签";
            this.skinButton_operation_write.UseVisualStyleBackColor = false;
            this.skinButton_operation_write.Click += new System.EventHandler(this.skinButton_operation_write_Click);
            // 
            // skinWater_content
            // 
            this.skinWater_content.Location = new System.Drawing.Point(79, 71);
            this.skinWater_content.Multiline = true;
            this.skinWater_content.Name = "skinWater_content";
            this.skinWater_content.Size = new System.Drawing.Size(491, 33);
            this.skinWater_content.TabIndex = 9;
            this.skinWater_content.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWater_content.WaterText = "";
            // 
            // skinLabel40
            // 
            this.skinLabel40.AutoSize = true;
            this.skinLabel40.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel40.BorderColor = System.Drawing.Color.White;
            this.skinLabel40.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel40.Location = new System.Drawing.Point(18, 72);
            this.skinLabel40.Name = "skinLabel40";
            this.skinLabel40.Size = new System.Drawing.Size(59, 17);
            this.skinLabel40.TabIndex = 8;
            this.skinLabel40.Text = "写入内容:";
            // 
            // skinWaterTextBox_password
            // 
            this.skinWaterTextBox_password.Location = new System.Drawing.Point(79, 45);
            this.skinWaterTextBox_password.Name = "skinWaterTextBox_password";
            this.skinWaterTextBox_password.Size = new System.Drawing.Size(134, 21);
            this.skinWaterTextBox_password.TabIndex = 7;
            this.skinWaterTextBox_password.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_password.WaterText = "";
            // 
            // skinLabel39
            // 
            this.skinLabel39.AutoSize = true;
            this.skinLabel39.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel39.BorderColor = System.Drawing.Color.White;
            this.skinLabel39.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel39.Location = new System.Drawing.Point(17, 48);
            this.skinLabel39.Name = "skinLabel39";
            this.skinLabel39.Size = new System.Drawing.Size(59, 17);
            this.skinLabel39.TabIndex = 6;
            this.skinLabel39.Text = "访问密码:";
            // 
            // skinWaterTextBox_length
            // 
            this.skinWaterTextBox_length.Location = new System.Drawing.Point(395, 13);
            this.skinWaterTextBox_length.Name = "skinWaterTextBox_length";
            this.skinWaterTextBox_length.Size = new System.Drawing.Size(91, 21);
            this.skinWaterTextBox_length.TabIndex = 5;
            this.skinWaterTextBox_length.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_length.WaterText = "";
            // 
            // skinLabel38
            // 
            this.skinLabel38.AutoSize = true;
            this.skinLabel38.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel38.BorderColor = System.Drawing.Color.White;
            this.skinLabel38.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel38.Location = new System.Drawing.Point(336, 15);
            this.skinLabel38.Name = "skinLabel38";
            this.skinLabel38.Size = new System.Drawing.Size(59, 17);
            this.skinLabel38.TabIndex = 4;
            this.skinLabel38.Text = "操作长度:";
            // 
            // skinWaterTextBox_address
            // 
            this.skinWaterTextBox_address.Location = new System.Drawing.Point(232, 15);
            this.skinWaterTextBox_address.Name = "skinWaterTextBox_address";
            this.skinWaterTextBox_address.Size = new System.Drawing.Size(100, 21);
            this.skinWaterTextBox_address.TabIndex = 3;
            this.skinWaterTextBox_address.WaterColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.skinWaterTextBox_address.WaterText = "";
            // 
            // skinLabel37
            // 
            this.skinLabel37.AutoSize = true;
            this.skinLabel37.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel37.BorderColor = System.Drawing.Color.White;
            this.skinLabel37.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel37.Location = new System.Drawing.Point(171, 15);
            this.skinLabel37.Name = "skinLabel37";
            this.skinLabel37.Size = new System.Drawing.Size(59, 17);
            this.skinLabel37.TabIndex = 2;
            this.skinLabel37.Text = "起始地址:";
            // 
            // skinComboBox_membank
            // 
            this.skinComboBox_membank.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.skinComboBox_membank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.skinComboBox_membank.FormattingEnabled = true;
            this.skinComboBox_membank.Items.AddRange(new object[] {
            "Reserve",
            "EPC",
            "TID",
            "USER"});
            this.skinComboBox_membank.Location = new System.Drawing.Point(79, 13);
            this.skinComboBox_membank.Name = "skinComboBox_membank";
            this.skinComboBox_membank.Size = new System.Drawing.Size(79, 22);
            this.skinComboBox_membank.TabIndex = 1;
            this.skinComboBox_membank.WaterText = "";
            // 
            // skinLabel36
            // 
            this.skinLabel36.AutoSize = true;
            this.skinLabel36.BackColor = System.Drawing.Color.Transparent;
            this.skinLabel36.BorderColor = System.Drawing.Color.White;
            this.skinLabel36.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.skinLabel36.Location = new System.Drawing.Point(13, 15);
            this.skinLabel36.Name = "skinLabel36";
            this.skinLabel36.Size = new System.Drawing.Size(59, 17);
            this.skinLabel36.TabIndex = 0;
            this.skinLabel36.Text = "标签区域:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(578, 369);
            this.tabPage2.TabIndex = 6;
            this.tabPage2.Text = "拓展功能";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button_relay_control);
            this.groupBox3.Controls.Add(this.textBox_relay_ctrl_time);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.comboBox_op_index);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(9, 255);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(563, 48);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "继电器控制测试";
            // 
            // button_relay_control
            // 
            this.button_relay_control.Location = new System.Drawing.Point(392, 18);
            this.button_relay_control.Name = "button_relay_control";
            this.button_relay_control.Size = new System.Drawing.Size(75, 21);
            this.button_relay_control.TabIndex = 4;
            this.button_relay_control.Text = "控制";
            this.button_relay_control.UseVisualStyleBackColor = true;
            this.button_relay_control.Click += new System.EventHandler(this.button_relay_control_Click);
            // 
            // textBox_relay_ctrl_time
            // 
            this.textBox_relay_ctrl_time.Location = new System.Drawing.Point(273, 19);
            this.textBox_relay_ctrl_time.Name = "textBox_relay_ctrl_time";
            this.textBox_relay_ctrl_time.Size = new System.Drawing.Size(70, 21);
            this.textBox_relay_ctrl_time.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(233, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "时间：";
            // 
            // comboBox_op_index
            // 
            this.comboBox_op_index.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_op_index.FormattingEnabled = true;
            this.comboBox_op_index.Items.AddRange(new object[] {
            "继电器1开",
            "电击器1关",
            "继电器2开",
            "继电器2关",
            "1,2打开",
            "1,2关闭"});
            this.comboBox_op_index.Location = new System.Drawing.Point(79, 21);
            this.comboBox_op_index.Name = "comboBox_op_index";
            this.comboBox_op_index.Size = new System.Drawing.Size(121, 20);
            this.comboBox_op_index.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "操作类型";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_audio_set_vol);
            this.groupBox2.Controls.Add(this.button_audio_play);
            this.groupBox2.Controls.Add(this.textBox_audio_text);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(9, 139);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(563, 82);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "语音模块测试";
            // 
            // button_audio_set_vol
            // 
            this.button_audio_set_vol.Location = new System.Drawing.Point(69, 45);
            this.button_audio_set_vol.Margin = new System.Windows.Forms.Padding(2);
            this.button_audio_set_vol.Name = "button_audio_set_vol";
            this.button_audio_set_vol.Size = new System.Drawing.Size(94, 25);
            this.button_audio_set_vol.TabIndex = 8;
            this.button_audio_set_vol.Text = "设置离线播放";
            this.button_audio_set_vol.UseVisualStyleBackColor = true;
            this.button_audio_set_vol.Click += new System.EventHandler(this.button_audio_set_vol_Click);
            // 
            // button_audio_play
            // 
            this.button_audio_play.Location = new System.Drawing.Point(482, 18);
            this.button_audio_play.Name = "button_audio_play";
            this.button_audio_play.Size = new System.Drawing.Size(75, 21);
            this.button_audio_play.TabIndex = 2;
            this.button_audio_play.Text = "播放";
            this.button_audio_play.UseVisualStyleBackColor = true;
            this.button_audio_play.Click += new System.EventHandler(this.button_audio_play_Click);
            // 
            // textBox_audio_text
            // 
            this.textBox_audio_text.Location = new System.Drawing.Point(69, 19);
            this.textBox_audio_text.Name = "textBox_audio_text";
            this.textBox_audio_text.Size = new System.Drawing.Size(398, 21);
            this.textBox_audio_text.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "播放内容：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_ext_auto_add_verify);
            this.groupBox1.Controls.Add(this.button_ext_add_verify);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.textBox_tag_verify_pwd);
            this.groupBox1.Controls.Add(this.checkBox_tag_verify);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.button_relay_set);
            this.groupBox1.Controls.Add(this.button_ext_fresh);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBox_relay_time);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.checkBox_relay2_auto);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.checkBox_relay1_auto);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(6, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(566, 129);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "拓展功能参数";
            // 
            // button_ext_add_verify
            // 
            this.button_ext_add_verify.Location = new System.Drawing.Point(96, 97);
            this.button_ext_add_verify.Name = "button_ext_add_verify";
            this.button_ext_add_verify.Size = new System.Drawing.Size(94, 23);
            this.button_ext_add_verify.TabIndex = 15;
            this.button_ext_add_verify.Text = "标签校验";
            this.button_ext_add_verify.UseVisualStyleBackColor = true;
            this.button_ext_add_verify.Click += new System.EventHandler(this.button_ext_add_verify_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(32, 102);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 12);
            this.label21.TabIndex = 14;
            this.label21.Text = "标签操作：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(170, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 12);
            this.label19.TabIndex = 13;
            this.label19.Text = "（0000H~FFFFH)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(29, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 12);
            this.label18.TabIndex = 12;
            this.label18.Text = "校验密码：";
            // 
            // textBox_tag_verify_pwd
            // 
            this.textBox_tag_verify_pwd.Location = new System.Drawing.Point(96, 65);
            this.textBox_tag_verify_pwd.Name = "textBox_tag_verify_pwd";
            this.textBox_tag_verify_pwd.Size = new System.Drawing.Size(72, 21);
            this.textBox_tag_verify_pwd.TabIndex = 11;
            this.textBox_tag_verify_pwd.Text = "0000";
            // 
            // checkBox_tag_verify
            // 
            this.checkBox_tag_verify.AutoSize = true;
            this.checkBox_tag_verify.Location = new System.Drawing.Point(269, 66);
            this.checkBox_tag_verify.Name = "checkBox_tag_verify";
            this.checkBox_tag_verify.Size = new System.Drawing.Size(132, 16);
            this.checkBox_tag_verify.TabIndex = 10;
            this.checkBox_tag_verify.Text = "读卡时启用标签校验";
            this.checkBox_tag_verify.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label10.Location = new System.Drawing.Point(21, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(461, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "（勾选自动开启设备在读到标签后会自动打开继电器，在经历开启时间之后自动关闭）";
            // 
            // button_relay_set
            // 
            this.button_relay_set.Location = new System.Drawing.Point(485, 102);
            this.button_relay_set.Name = "button_relay_set";
            this.button_relay_set.Size = new System.Drawing.Size(75, 21);
            this.button_relay_set.TabIndex = 8;
            this.button_relay_set.Text = "设置";
            this.button_relay_set.UseVisualStyleBackColor = true;
            this.button_relay_set.Click += new System.EventHandler(this.button_relay_set_Click);
            // 
            // button_ext_fresh
            // 
            this.button_ext_fresh.Location = new System.Drawing.Point(395, 102);
            this.button_ext_fresh.Name = "button_ext_fresh";
            this.button_ext_fresh.Size = new System.Drawing.Size(75, 21);
            this.button_ext_fresh.TabIndex = 7;
            this.button_ext_fresh.Text = "刷新";
            this.button_ext_fresh.UseVisualStyleBackColor = true;
            this.button_ext_fresh.Click += new System.EventHandler(this.button_ext_fresh_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(493, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 6;
            this.label8.Text = "（秒）";
            // 
            // textBox_relay_time
            // 
            this.textBox_relay_time.Location = new System.Drawing.Point(434, 18);
            this.textBox_relay_time.Name = "textBox_relay_time";
            this.textBox_relay_time.Size = new System.Drawing.Size(54, 21);
            this.textBox_relay_time.TabIndex = 5;
            this.textBox_relay_time.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(371, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 4;
            this.label7.Text = "开启时间：";
            // 
            // checkBox_relay2_auto
            // 
            this.checkBox_relay2_auto.AutoSize = true;
            this.checkBox_relay2_auto.Location = new System.Drawing.Point(260, 21);
            this.checkBox_relay2_auto.Name = "checkBox_relay2_auto";
            this.checkBox_relay2_auto.Size = new System.Drawing.Size(72, 16);
            this.checkBox_relay2_auto.TabIndex = 3;
            this.checkBox_relay2_auto.Text = "自动开启";
            this.checkBox_relay2_auto.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(202, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "继电器2：";
            // 
            // checkBox_relay1_auto
            // 
            this.checkBox_relay1_auto.AutoSize = true;
            this.checkBox_relay1_auto.Location = new System.Drawing.Point(94, 19);
            this.checkBox_relay1_auto.Name = "checkBox_relay1_auto";
            this.checkBox_relay1_auto.Size = new System.Drawing.Size(72, 16);
            this.checkBox_relay1_auto.TabIndex = 1;
            this.checkBox_relay1_auto.Text = "自动开启";
            this.checkBox_relay1_auto.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "继电器1：";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(578, 369);
            this.tabPage3.TabIndex = 7;
            this.tabPage3.Text = "写卡专区";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button_write_file_reload);
            this.groupBox9.Controls.Add(this.button_write_file_auto);
            this.groupBox9.Controls.Add(this.button_write_file_hand);
            this.groupBox9.Controls.Add(this.textBox_write_file_data);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Controls.Add(this.numericUpDown_write_file_row);
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Controls.Add(this.button_write_file_choose);
            this.groupBox9.Controls.Add(this.textBox_write_file_path);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Location = new System.Drawing.Point(11, 122);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(561, 123);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "文件写卡";
            // 
            // button_write_file_reload
            // 
            this.button_write_file_reload.Location = new System.Drawing.Point(283, 94);
            this.button_write_file_reload.Name = "button_write_file_reload";
            this.button_write_file_reload.Size = new System.Drawing.Size(75, 23);
            this.button_write_file_reload.TabIndex = 8;
            this.button_write_file_reload.Text = "重载数据";
            this.button_write_file_reload.UseVisualStyleBackColor = true;
            this.button_write_file_reload.Click += new System.EventHandler(this.button_write_file_reload_Click);
            // 
            // button_write_file_auto
            // 
            this.button_write_file_auto.Location = new System.Drawing.Point(476, 94);
            this.button_write_file_auto.Name = "button_write_file_auto";
            this.button_write_file_auto.Size = new System.Drawing.Size(75, 23);
            this.button_write_file_auto.TabIndex = 7;
            this.button_write_file_auto.Text = "自动写入";
            this.button_write_file_auto.UseVisualStyleBackColor = true;
            this.button_write_file_auto.Click += new System.EventHandler(this.button_write_file_auto_Click);
            // 
            // button_write_file_hand
            // 
            this.button_write_file_hand.Location = new System.Drawing.Point(384, 94);
            this.button_write_file_hand.Name = "button_write_file_hand";
            this.button_write_file_hand.Size = new System.Drawing.Size(75, 23);
            this.button_write_file_hand.TabIndex = 7;
            this.button_write_file_hand.Text = "手动写入";
            this.button_write_file_hand.UseVisualStyleBackColor = true;
            this.button_write_file_hand.Click += new System.EventHandler(this.button_write_file_hand_Click);
            // 
            // textBox_write_file_data
            // 
            this.textBox_write_file_data.Location = new System.Drawing.Point(241, 54);
            this.textBox_write_file_data.Name = "textBox_write_file_data";
            this.textBox_write_file_data.ReadOnly = true;
            this.textBox_write_file_data.Size = new System.Drawing.Size(310, 21);
            this.textBox_write_file_data.TabIndex = 6;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(181, 58);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 12);
            this.label37.TabIndex = 5;
            this.label37.Text = "写入数据：";
            // 
            // numericUpDown_write_file_row
            // 
            this.numericUpDown_write_file_row.Location = new System.Drawing.Point(67, 54);
            this.numericUpDown_write_file_row.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_write_file_row.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_write_file_row.Name = "numericUpDown_write_file_row";
            this.numericUpDown_write_file_row.Size = new System.Drawing.Size(90, 21);
            this.numericUpDown_write_file_row.TabIndex = 4;
            this.numericUpDown_write_file_row.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_write_file_row.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(7, 58);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(65, 12);
            this.label36.TabIndex = 3;
            this.label36.Text = "当前行号：";
            // 
            // button_write_file_choose
            // 
            this.button_write_file_choose.Location = new System.Drawing.Point(191, 94);
            this.button_write_file_choose.Name = "button_write_file_choose";
            this.button_write_file_choose.Size = new System.Drawing.Size(75, 23);
            this.button_write_file_choose.TabIndex = 2;
            this.button_write_file_choose.Text = "文件选择";
            this.button_write_file_choose.UseVisualStyleBackColor = true;
            this.button_write_file_choose.Click += new System.EventHandler(this.button_write_file_choose_Click);
            // 
            // textBox_write_file_path
            // 
            this.textBox_write_file_path.Location = new System.Drawing.Point(44, 24);
            this.textBox_write_file_path.Name = "textBox_write_file_path";
            this.textBox_write_file_path.ReadOnly = true;
            this.textBox_write_file_path.Size = new System.Drawing.Size(507, 21);
            this.textBox_write_file_path.TabIndex = 1;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(7, 28);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 12);
            this.label35.TabIndex = 0;
            this.label35.Text = "路径：";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.checkBox_auto_write_increse);
            this.groupBox5.Controls.Add(this.checkBox_auto_write_flag);
            this.groupBox5.Controls.Add(this.button_auto_write_wiegand);
            this.groupBox5.Controls.Add(this.button_auto_write_hex);
            this.groupBox5.Controls.Add(this.textBox_auto_wiegand_write_text);
            this.groupBox5.Controls.Add(this.textBox_auto_hex_write_text);
            this.groupBox5.Location = new System.Drawing.Point(10, 17);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(562, 97);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "自动写卡";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(24, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 7;
            this.label14.Text = "韦根卡号：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 37);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 6;
            this.label13.Text = "十六进卡号：";
            // 
            // checkBox_auto_write_increse
            // 
            this.checkBox_auto_write_increse.AutoSize = true;
            this.checkBox_auto_write_increse.Location = new System.Drawing.Point(176, 13);
            this.checkBox_auto_write_increse.Name = "checkBox_auto_write_increse";
            this.checkBox_auto_write_increse.Size = new System.Drawing.Size(66, 16);
            this.checkBox_auto_write_increse.TabIndex = 5;
            this.checkBox_auto_write_increse.Text = "自动加1";
            this.checkBox_auto_write_increse.UseVisualStyleBackColor = true;
            // 
            // checkBox_auto_write_flag
            // 
            this.checkBox_auto_write_flag.AutoSize = true;
            this.checkBox_auto_write_flag.Location = new System.Drawing.Point(96, 13);
            this.checkBox_auto_write_flag.Name = "checkBox_auto_write_flag";
            this.checkBox_auto_write_flag.Size = new System.Drawing.Size(48, 16);
            this.checkBox_auto_write_flag.TabIndex = 4;
            this.checkBox_auto_write_flag.Text = "自动";
            this.checkBox_auto_write_flag.UseVisualStyleBackColor = true;
            // 
            // button_auto_write_wiegand
            // 
            this.button_auto_write_wiegand.Location = new System.Drawing.Point(259, 65);
            this.button_auto_write_wiegand.Name = "button_auto_write_wiegand";
            this.button_auto_write_wiegand.Size = new System.Drawing.Size(75, 21);
            this.button_auto_write_wiegand.TabIndex = 3;
            this.button_auto_write_wiegand.Text = "韦根写卡";
            this.button_auto_write_wiegand.UseVisualStyleBackColor = true;
            this.button_auto_write_wiegand.Click += new System.EventHandler(this.button_auto_write_wiegand_Click);
            // 
            // button_auto_write_hex
            // 
            this.button_auto_write_hex.Location = new System.Drawing.Point(453, 34);
            this.button_auto_write_hex.Name = "button_auto_write_hex";
            this.button_auto_write_hex.Size = new System.Drawing.Size(75, 21);
            this.button_auto_write_hex.TabIndex = 2;
            this.button_auto_write_hex.Text = "Hex写卡";
            this.button_auto_write_hex.UseVisualStyleBackColor = true;
            this.button_auto_write_hex.Click += new System.EventHandler(this.button_auto_write_hex_Click);
            // 
            // textBox_auto_wiegand_write_text
            // 
            this.textBox_auto_wiegand_write_text.Location = new System.Drawing.Point(96, 66);
            this.textBox_auto_wiegand_write_text.Name = "textBox_auto_wiegand_write_text";
            this.textBox_auto_wiegand_write_text.Size = new System.Drawing.Size(148, 21);
            this.textBox_auto_wiegand_write_text.TabIndex = 1;
            // 
            // textBox_auto_hex_write_text
            // 
            this.textBox_auto_hex_write_text.Location = new System.Drawing.Point(96, 34);
            this.textBox_auto_hex_write_text.Name = "textBox_auto_hex_write_text";
            this.textBox_auto_hex_write_text.Size = new System.Drawing.Size(338, 21);
            this.textBox_auto_hex_write_text.TabIndex = 0;
            // 
            // tabPage_ExDataParam
            // 
            this.tabPage_ExDataParam.Controls.Add(this.groupBox8);
            this.tabPage_ExDataParam.Controls.Add(this.groupBox7);
            this.tabPage_ExDataParam.Controls.Add(this.groupBox6);
            this.tabPage_ExDataParam.Location = new System.Drawing.Point(4, 22);
            this.tabPage_ExDataParam.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage_ExDataParam.Name = "tabPage_ExDataParam";
            this.tabPage_ExDataParam.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage_ExDataParam.Size = new System.Drawing.Size(578, 369);
            this.tabPage_ExDataParam.TabIndex = 8;
            this.tabPage_ExDataParam.Text = "拓展数据";
            this.tabPage_ExDataParam.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.comboBox_ex_modbus_proto);
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.label25);
            this.groupBox8.Controls.Add(this.label_ex_modbus_register_num);
            this.groupBox8.Controls.Add(this.button_ex_modbus_set);
            this.groupBox8.Controls.Add(this.button_ex_modbus_query);
            this.groupBox8.Controls.Add(this.checkBox_ex_modbus_clear_flag);
            this.groupBox8.Controls.Add(this.numericUpDown_ex_modbus_startaddr);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.numericUpDown_ex_modbus_union_size);
            this.groupBox8.Controls.Add(this.label23);
            this.groupBox8.Controls.Add(this.numericUpDown_ex_modbus_tag_num);
            this.groupBox8.Controls.Add(this.label22);
            this.groupBox8.Location = new System.Drawing.Point(17, 210);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox8.Size = new System.Drawing.Size(547, 73);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Modbus参数";
            // 
            // comboBox_ex_modbus_proto
            // 
            this.comboBox_ex_modbus_proto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ex_modbus_proto.FormattingEnabled = true;
            this.comboBox_ex_modbus_proto.Items.AddRange(new object[] {
            "ModbusRtu",
            "ModbusAscii",
            "ModbusTcp"});
            this.comboBox_ex_modbus_proto.Location = new System.Drawing.Point(396, 22);
            this.comboBox_ex_modbus_proto.Name = "comboBox_ex_modbus_proto";
            this.comboBox_ex_modbus_proto.Size = new System.Drawing.Size(121, 20);
            this.comboBox_ex_modbus_proto.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(356, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "协议：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(291, 25);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 12);
            this.label26.TabIndex = 10;
            this.label26.Text = "(单位:字)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(143, 53);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 12);
            this.label25.TabIndex = 10;
            this.label25.Text = "(单位:字)";
            // 
            // label_ex_modbus_register_num
            // 
            this.label_ex_modbus_register_num.AutoSize = true;
            this.label_ex_modbus_register_num.Location = new System.Drawing.Point(335, 52);
            this.label_ex_modbus_register_num.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ex_modbus_register_num.Name = "label_ex_modbus_register_num";
            this.label_ex_modbus_register_num.Size = new System.Drawing.Size(77, 12);
            this.label_ex_modbus_register_num.TabIndex = 9;
            this.label_ex_modbus_register_num.Text = "Registers：0";
            // 
            // button_ex_modbus_set
            // 
            this.button_ex_modbus_set.Location = new System.Drawing.Point(486, 49);
            this.button_ex_modbus_set.Margin = new System.Windows.Forms.Padding(2);
            this.button_ex_modbus_set.Name = "button_ex_modbus_set";
            this.button_ex_modbus_set.Size = new System.Drawing.Size(51, 20);
            this.button_ex_modbus_set.TabIndex = 8;
            this.button_ex_modbus_set.Text = "设置";
            this.button_ex_modbus_set.UseVisualStyleBackColor = true;
            this.button_ex_modbus_set.Click += new System.EventHandler(this.button_ex_modbus_set_Click);
            // 
            // button_ex_modbus_query
            // 
            this.button_ex_modbus_query.Location = new System.Drawing.Point(424, 49);
            this.button_ex_modbus_query.Margin = new System.Windows.Forms.Padding(2);
            this.button_ex_modbus_query.Name = "button_ex_modbus_query";
            this.button_ex_modbus_query.Size = new System.Drawing.Size(50, 20);
            this.button_ex_modbus_query.TabIndex = 7;
            this.button_ex_modbus_query.Text = "查询";
            this.button_ex_modbus_query.UseVisualStyleBackColor = true;
            this.button_ex_modbus_query.Click += new System.EventHandler(this.button_ex_modbus_query_Click);
            // 
            // checkBox_ex_modbus_clear_flag
            // 
            this.checkBox_ex_modbus_clear_flag.AutoSize = true;
            this.checkBox_ex_modbus_clear_flag.Location = new System.Drawing.Point(216, 51);
            this.checkBox_ex_modbus_clear_flag.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox_ex_modbus_clear_flag.Name = "checkBox_ex_modbus_clear_flag";
            this.checkBox_ex_modbus_clear_flag.Size = new System.Drawing.Size(108, 16);
            this.checkBox_ex_modbus_clear_flag.TabIndex = 6;
            this.checkBox_ex_modbus_clear_flag.Text = "取走寄存器清零";
            this.checkBox_ex_modbus_clear_flag.UseVisualStyleBackColor = true;
            // 
            // numericUpDown_ex_modbus_startaddr
            // 
            this.numericUpDown_ex_modbus_startaddr.Location = new System.Drawing.Point(235, 23);
            this.numericUpDown_ex_modbus_startaddr.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown_ex_modbus_startaddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown_ex_modbus_startaddr.Name = "numericUpDown_ex_modbus_startaddr";
            this.numericUpDown_ex_modbus_startaddr.Size = new System.Drawing.Size(51, 21);
            this.numericUpDown_ex_modbus_startaddr.TabIndex = 5;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(151, 26);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(89, 12);
            this.label24.TabIndex = 4;
            this.label24.Text = "存储起始地址：";
            // 
            // numericUpDown_ex_modbus_union_size
            // 
            this.numericUpDown_ex_modbus_union_size.Location = new System.Drawing.Point(84, 47);
            this.numericUpDown_ex_modbus_union_size.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown_ex_modbus_union_size.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown_ex_modbus_union_size.Name = "numericUpDown_ex_modbus_union_size";
            this.numericUpDown_ex_modbus_union_size.Size = new System.Drawing.Size(53, 21);
            this.numericUpDown_ex_modbus_union_size.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(5, 49);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "单标签大小：";
            // 
            // numericUpDown_ex_modbus_tag_num
            // 
            this.numericUpDown_ex_modbus_tag_num.Location = new System.Drawing.Point(84, 23);
            this.numericUpDown_ex_modbus_tag_num.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown_ex_modbus_tag_num.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown_ex_modbus_tag_num.Name = "numericUpDown_ex_modbus_tag_num";
            this.numericUpDown_ex_modbus_tag_num.Size = new System.Drawing.Size(53, 21);
            this.numericUpDown_ex_modbus_tag_num.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(18, 26);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "标签总数：";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.comboBox_dataflag_format);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.button_dataflag_set);
            this.groupBox7.Controls.Add(this.button_dataflag_query);
            this.groupBox7.Controls.Add(this.checkBoxDataFlag_DevNo);
            this.groupBox7.Controls.Add(this.checkBoxDataFlag_ANT);
            this.groupBox7.Controls.Add(this.checkBoxDataFlag_RSSI);
            this.groupBox7.Location = new System.Drawing.Point(17, 107);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox7.Size = new System.Drawing.Size(547, 88);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "数据参数";
            // 
            // comboBox_dataflag_format
            // 
            this.comboBox_dataflag_format.FormattingEnabled = true;
            this.comboBox_dataflag_format.Items.AddRange(new object[] {
            "0：默认带协议数据",
            "1：标签原始数据",
            "2：十六进制字符串",
            "3：JSON",
            "4：Wiegand26字符(整数2+1)",
            "5：Wiegand26字符（整数 3bytes）",
            "6：Wiegand34/32（整数 4bytes)",
            "7：标签最后3个16进制字符"});
            this.comboBox_dataflag_format.Location = new System.Drawing.Point(107, 52);
            this.comboBox_dataflag_format.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_dataflag_format.Name = "comboBox_dataflag_format";
            this.comboBox_dataflag_format.Size = new System.Drawing.Size(203, 20);
            this.comboBox_dataflag_format.TabIndex = 4;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(42, 54);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 12);
            this.label34.TabIndex = 3;
            this.label34.Text = "数据格式：";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(21, 26);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(83, 12);
            this.label33.TabIndex = 2;
            this.label33.Text = "上传数据信息:";
            // 
            // button_dataflag_set
            // 
            this.button_dataflag_set.Location = new System.Drawing.Point(480, 63);
            this.button_dataflag_set.Margin = new System.Windows.Forms.Padding(2);
            this.button_dataflag_set.Name = "button_dataflag_set";
            this.button_dataflag_set.Size = new System.Drawing.Size(54, 21);
            this.button_dataflag_set.TabIndex = 1;
            this.button_dataflag_set.Text = "设置";
            this.button_dataflag_set.UseVisualStyleBackColor = true;
            this.button_dataflag_set.Click += new System.EventHandler(this.button_dataflag_set_Click);
            // 
            // button_dataflag_query
            // 
            this.button_dataflag_query.Location = new System.Drawing.Point(407, 63);
            this.button_dataflag_query.Margin = new System.Windows.Forms.Padding(2);
            this.button_dataflag_query.Name = "button_dataflag_query";
            this.button_dataflag_query.Size = new System.Drawing.Size(54, 21);
            this.button_dataflag_query.TabIndex = 1;
            this.button_dataflag_query.Text = "查询";
            this.button_dataflag_query.UseVisualStyleBackColor = true;
            this.button_dataflag_query.Click += new System.EventHandler(this.button_dataflag_query_Click);
            // 
            // checkBoxDataFlag_DevNo
            // 
            this.checkBoxDataFlag_DevNo.AutoSize = true;
            this.checkBoxDataFlag_DevNo.Location = new System.Drawing.Point(169, 25);
            this.checkBoxDataFlag_DevNo.Margin = new System.Windows.Forms.Padding(2);
            this.checkBoxDataFlag_DevNo.Name = "checkBoxDataFlag_DevNo";
            this.checkBoxDataFlag_DevNo.Size = new System.Drawing.Size(60, 16);
            this.checkBoxDataFlag_DevNo.TabIndex = 0;
            this.checkBoxDataFlag_DevNo.Text = "设备号";
            this.checkBoxDataFlag_DevNo.UseVisualStyleBackColor = true;
            // 
            // checkBoxDataFlag_ANT
            // 
            this.checkBoxDataFlag_ANT.AutoSize = true;
            this.checkBoxDataFlag_ANT.Location = new System.Drawing.Point(244, 25);
            this.checkBoxDataFlag_ANT.Margin = new System.Windows.Forms.Padding(2);
            this.checkBoxDataFlag_ANT.Name = "checkBoxDataFlag_ANT";
            this.checkBoxDataFlag_ANT.Size = new System.Drawing.Size(60, 16);
            this.checkBoxDataFlag_ANT.TabIndex = 0;
            this.checkBoxDataFlag_ANT.Text = "天线号";
            this.checkBoxDataFlag_ANT.UseVisualStyleBackColor = true;
            // 
            // checkBoxDataFlag_RSSI
            // 
            this.checkBoxDataFlag_RSSI.AutoSize = true;
            this.checkBoxDataFlag_RSSI.Location = new System.Drawing.Point(107, 25);
            this.checkBoxDataFlag_RSSI.Margin = new System.Windows.Forms.Padding(2);
            this.checkBoxDataFlag_RSSI.Name = "checkBoxDataFlag_RSSI";
            this.checkBoxDataFlag_RSSI.Size = new System.Drawing.Size(48, 16);
            this.checkBoxDataFlag_RSSI.TabIndex = 0;
            this.checkBoxDataFlag_RSSI.Text = "RSSI";
            this.checkBoxDataFlag_RSSI.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButton_USB_COM);
            this.groupBox6.Controls.Add(this.radioButton_USB_HID);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.button_usbdata_sset);
            this.groupBox6.Controls.Add(this.button_usbdata_query);
            this.groupBox6.Controls.Add(this.checkBox_usbdata_enter_flag);
            this.groupBox6.Controls.Add(this.comboBox_usbdata_proto);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Location = new System.Drawing.Point(17, 13);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(547, 77);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "USB";
            // 
            // radioButton_USB_COM
            // 
            this.radioButton_USB_COM.AutoSize = true;
            this.radioButton_USB_COM.Location = new System.Drawing.Point(208, 17);
            this.radioButton_USB_COM.Name = "radioButton_USB_COM";
            this.radioButton_USB_COM.Size = new System.Drawing.Size(119, 16);
            this.radioButton_USB_COM.TabIndex = 6;
            this.radioButton_USB_COM.TabStop = true;
            this.radioButton_USB_COM.Text = "USB虚拟串口(COM)";
            this.radioButton_USB_COM.UseVisualStyleBackColor = true;
            // 
            // radioButton_USB_HID
            // 
            this.radioButton_USB_HID.AutoSize = true;
            this.radioButton_USB_HID.Location = new System.Drawing.Point(98, 16);
            this.radioButton_USB_HID.Name = "radioButton_USB_HID";
            this.radioButton_USB_HID.Size = new System.Drawing.Size(95, 16);
            this.radioButton_USB_HID.TabIndex = 6;
            this.radioButton_USB_HID.TabStop = true;
            this.radioButton_USB_HID.Text = "USB HID 键盘";
            this.radioButton_USB_HID.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(9, 18);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 12);
            this.label20.TabIndex = 5;
            this.label20.Text = "USB输出类型：";
            // 
            // button_usbdata_sset
            // 
            this.button_usbdata_sset.Location = new System.Drawing.Point(471, 44);
            this.button_usbdata_sset.Margin = new System.Windows.Forms.Padding(2);
            this.button_usbdata_sset.Name = "button_usbdata_sset";
            this.button_usbdata_sset.Size = new System.Drawing.Size(52, 20);
            this.button_usbdata_sset.TabIndex = 4;
            this.button_usbdata_sset.Text = "设置";
            this.button_usbdata_sset.UseVisualStyleBackColor = true;
            this.button_usbdata_sset.Click += new System.EventHandler(this.button_usbdata_sset_Click);
            // 
            // button_usbdata_query
            // 
            this.button_usbdata_query.Location = new System.Drawing.Point(396, 44);
            this.button_usbdata_query.Margin = new System.Windows.Forms.Padding(2);
            this.button_usbdata_query.Name = "button_usbdata_query";
            this.button_usbdata_query.Size = new System.Drawing.Size(54, 20);
            this.button_usbdata_query.TabIndex = 3;
            this.button_usbdata_query.Text = "查询";
            this.button_usbdata_query.UseVisualStyleBackColor = true;
            this.button_usbdata_query.Click += new System.EventHandler(this.button_usbdata_query_Click);
            // 
            // checkBox_usbdata_enter_flag
            // 
            this.checkBox_usbdata_enter_flag.AutoSize = true;
            this.checkBox_usbdata_enter_flag.Location = new System.Drawing.Point(309, 45);
            this.checkBox_usbdata_enter_flag.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox_usbdata_enter_flag.Name = "checkBox_usbdata_enter_flag";
            this.checkBox_usbdata_enter_flag.Size = new System.Drawing.Size(72, 16);
            this.checkBox_usbdata_enter_flag.TabIndex = 2;
            this.checkBox_usbdata_enter_flag.Text = "输出换行";
            this.checkBox_usbdata_enter_flag.UseVisualStyleBackColor = true;
            // 
            // comboBox_usbdata_proto
            // 
            this.comboBox_usbdata_proto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_usbdata_proto.FormattingEnabled = true;
            this.comboBox_usbdata_proto.Items.AddRange(new object[] {
            "十六进制字符",
            "Wiegand26(1+2)字符",
            "Wiegand26(3)字符",
            "Wiegand34字符",
            "标签原始数据",
            "标签最后三个字符(HEX)"});
            this.comboBox_usbdata_proto.Location = new System.Drawing.Point(98, 42);
            this.comboBox_usbdata_proto.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_usbdata_proto.Name = "comboBox_usbdata_proto";
            this.comboBox_usbdata_proto.Size = new System.Drawing.Size(201, 20);
            this.comboBox_usbdata_proto.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(17, 44);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "USB数据格式:";
            // 
            // tabPage_filterdata
            // 
            this.tabPage_filterdata.Controls.Add(this.button2);
            this.tabPage_filterdata.Controls.Add(this.button1);
            this.tabPage_filterdata.Controls.Add(this.textBox5);
            this.tabPage_filterdata.Controls.Add(this.label32);
            this.tabPage_filterdata.Controls.Add(this.textBox4);
            this.tabPage_filterdata.Controls.Add(this.label31);
            this.tabPage_filterdata.Controls.Add(this.textBox3);
            this.tabPage_filterdata.Controls.Add(this.label30);
            this.tabPage_filterdata.Controls.Add(this.textBox2);
            this.tabPage_filterdata.Controls.Add(this.label29);
            this.tabPage_filterdata.Controls.Add(this.textBox1);
            this.tabPage_filterdata.Controls.Add(this.label28);
            this.tabPage_filterdata.Location = new System.Drawing.Point(4, 22);
            this.tabPage_filterdata.Name = "tabPage_filterdata";
            this.tabPage_filterdata.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_filterdata.Size = new System.Drawing.Size(578, 369);
            this.tabPage_filterdata.TabIndex = 9;
            this.tabPage_filterdata.Text = "标签过滤";
            this.tabPage_filterdata.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(298, 334);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "设置";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(165, 334);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(73, 124);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(315, 21);
            this.textBox5.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(30, 128);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(47, 12);
            this.label32.TabIndex = 0;
            this.label32.Text = "标签5：";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(73, 97);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(315, 21);
            this.textBox4.TabIndex = 1;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(30, 101);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(47, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "标签4：";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(73, 70);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(315, 21);
            this.textBox3.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(30, 74);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(47, 12);
            this.label30.TabIndex = 0;
            this.label30.Text = "标签3：";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(73, 43);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(315, 21);
            this.textBox2.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(30, 47);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(47, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "标签2：";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(73, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(315, 21);
            this.textBox1.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(30, 20);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(47, 12);
            this.label28.TabIndex = 0;
            this.label28.Text = "标签1：";
            // 
            // button_ext_auto_add_verify
            // 
            this.button_ext_auto_add_verify.Location = new System.Drawing.Point(196, 97);
            this.button_ext_auto_add_verify.Name = "button_ext_auto_add_verify";
            this.button_ext_auto_add_verify.Size = new System.Drawing.Size(94, 23);
            this.button_ext_auto_add_verify.TabIndex = 15;
            this.button_ext_auto_add_verify.Text = "自动校验";
            this.button_ext_auto_add_verify.UseVisualStyleBackColor = true;
            this.button_ext_auto_add_verify.Click += new System.EventHandler(this.button_ext_auto_verify_Click);
            // 
            // M100Window
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 394);
            this.Controls.Add(this.tabControl_function);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "M100Window";
            this.Text = "M100Window";
            this.tabControl_function.ResumeLayout(false);
            this.tabPage_inventory.ResumeLayout(false);
            this.tabPage_inventory.PerformLayout();
            this.tabPage_work_param.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.skinGroupBox7.ResumeLayout(false);
            this.skinGroupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_power)).EndInit();
            this.skinGroupBox6.ResumeLayout(false);
            this.skinGroupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_trigger_time)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_work_interval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_work_filter)).EndInit();
            this.tabPage_transfer.ResumeLayout(false);
            this.tabPage_transfer.PerformLayout();
            this.skinGroupBox8.ResumeLayout(false);
            this.skinGroupBox8.PerformLayout();
            this.skinGroupBox5.ResumeLayout(false);
            this.skinGroupBox5.PerformLayout();
            this.skinGroupBox3.ResumeLayout(false);
            this.skinGroupBox3.PerformLayout();
            this.skinGroupBox2.ResumeLayout(false);
            this.skinGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_wiegand_location)).EndInit();
            this.skinGroupBox1.ResumeLayout(false);
            this.skinGroupBox1.PerformLayout();
            this.tabPage_advance.ResumeLayout(false);
            this.tabPage_advance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skinNumericUpDown_advan_Q)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.skinGroupBox4.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_write_file_row)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage_ExDataParam.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ex_modbus_startaddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ex_modbus_union_size)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ex_modbus_tag_num)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage_filterdata.ResumeLayout(false);
            this.tabPage_filterdata.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_function;
        private System.Windows.Forms.TabPage tabPage_inventory;
        private CCWin.SkinControl.SkinButton skinButton_once;
        private CCWin.SkinControl.SkinButton skinButton_stop;
        private CCWin.SkinControl.SkinListView skinListView_tags;
        private CCWin.SkinControl.SkinButton skinButton_start;
        private System.Windows.Forms.ColumnHeader columnHeader_time;
        private System.Windows.Forms.ColumnHeader columnHeader_ID;
        private System.Windows.Forms.ColumnHeader columnHeader_rssi;
        private System.Windows.Forms.ColumnHeader columnHeader_count;
        private CCWin.SkinControl.SkinButton skinButton_clear;
        private System.Windows.Forms.TabPage tabPage_work_param;
        private CCWin.SkinControl.SkinLabel skinLabel1;
        private CCWin.SkinControl.SkinNumericUpDown skinNumericUpDown_power;
        private CCWin.SkinControl.SkinButton skinButton_work_set;
        private CCWin.SkinControl.SkinButton skinButton_work_refresh;
        private CCWin.SkinControl.SkinNumericUpDown skinNumericUpDown_work_interval;
        private CCWin.SkinControl.SkinNumericUpDown skinNumericUpDown_work_filter;
        private CCWin.SkinControl.SkinLabel skinLabel3;
        private CCWin.SkinControl.SkinLabel skinLabel2;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_addr;
        private CCWin.SkinControl.SkinLabel skinLabel4;
        private CCWin.SkinControl.SkinNumericUpDown skinNumericUpDown_trigger_time;
        private CCWin.SkinControl.SkinLabel skinLabel_trigger;
        private CCWin.SkinControl.SkinComboBox skinComboBox_work_mode;
        private CCWin.SkinControl.SkinLabel skinLabel_work_mode;
        private System.Windows.Forms.TabPage tabPage_transfer;
        private CCWin.SkinControl.SkinComboBox skinComboBox_transfer_mode;
        private CCWin.SkinControl.SkinLabel skinLabel6;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox2;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox1;
        private CCWin.SkinControl.SkinComboBox skinComboBox_transfer_baudrate;
        private CCWin.SkinControl.SkinLabel skinLabel5;
        private CCWin.SkinControl.SkinNumericUpDown skinNumericUpDown_wiegand_location;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_wiegand_interval;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_wiegand_prorid;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_wiegand_width;
        private CCWin.SkinControl.SkinComboBox skinComboBox_wiegand_protocl;
        private CCWin.SkinControl.SkinLabel skinLabel11;
        private CCWin.SkinControl.SkinLabel skinLabel10;
        private CCWin.SkinControl.SkinLabel skinLabel9;
        private CCWin.SkinControl.SkinLabel skinLabel8;
        private CCWin.SkinControl.SkinLabel skinLabel7;
        private CCWin.SkinControl.SkinButton skinButton_transfer_set;
        private CCWin.SkinControl.SkinButton skinButton_transfer_query;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox3;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_gate_way;
        private CCWin.SkinControl.SkinLabel skinLabel19;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_ip_sub_masker;
        private CCWin.SkinControl.SkinLabel skinLabel18;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_remote_port;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_ip_remote;
        private CCWin.SkinControl.SkinLabel skinLabel16;
        private CCWin.SkinControl.SkinLabel skinLabel15;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_local_port;
        private CCWin.SkinControl.SkinLabel skinLabel14;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_ip_local;
        private CCWin.SkinControl.SkinLabel skinLabel13;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_ip_mac;
        private CCWin.SkinControl.SkinLabel skinLabel12;
        private System.Windows.Forms.TabPage tabPage_advance;
        private CCWin.SkinControl.SkinNumericUpDown skinNumericUpDown_advan_Q;
        private CCWin.SkinControl.SkinButton skinButton_advance_set;
        private CCWin.SkinControl.SkinButton skinButton_advance_refresh;
        private CCWin.SkinControl.SkinLabel skinLabel28;
        private CCWin.SkinControl.SkinLabel skinLabel27;
        private CCWin.SkinControl.SkinComboBox skinComboBox_advan_target;
        private CCWin.SkinControl.SkinLabel skinLabel26;
        private CCWin.SkinControl.SkinComboBox skinComboBox_advan_session;
        private CCWin.SkinControl.SkinLabel skinLabel25;
        private CCWin.SkinControl.SkinComboBox skinComboBox_advan_sel;
        private CCWin.SkinControl.SkinLabel skinLabel24;
        private CCWin.SkinControl.SkinComboBox skinComboBox_advan_cw;
        private CCWin.SkinControl.SkinLabel skinLabel23;
        private CCWin.SkinControl.SkinComboBox skinComboBox_advan_hopping;
        private CCWin.SkinControl.SkinLabel skinLabel22;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_advan_channel;
        private CCWin.SkinControl.SkinLabel skinLabel21;
        private CCWin.SkinControl.SkinComboBox skinComboBox_advan_region;
        private CCWin.SkinControl.SkinLabel skinLabel20;
        private CCWin.SkinControl.SkinButton skinButton_defualt;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_heart_beats;
        private CCWin.SkinControl.SkinLabel skinLabel30;
        private CCWin.SkinControl.SkinButton skinButton_reset;
        private CCWin.SkinControl.SkinLabel skinLabel31;
        private CCWin.SkinControl.SkinLabel skinLabel33;
        private CCWin.SkinControl.SkinLabel skinLabel32;
        private System.Windows.Forms.TabPage tabPage1;
        private CCWin.SkinControl.SkinButton skinButton_operation_write;
        private CCWin.SkinControl.SkinWaterTextBox skinWater_content;
        private CCWin.SkinControl.SkinLabel skinLabel40;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_password;
        private CCWin.SkinControl.SkinLabel skinLabel39;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_length;
        private CCWin.SkinControl.SkinLabel skinLabel38;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_address;
        private CCWin.SkinControl.SkinLabel skinLabel37;
        private CCWin.SkinControl.SkinComboBox skinComboBox_membank;
        private CCWin.SkinControl.SkinLabel skinLabel36;
        private CCWin.SkinControl.SkinLabel skinLabel_tag_num;
		private CCWin.SkinControl.SkinButton skinButton_operation_read;
        private CCWin.SkinControl.SkinLabel skinLabel41;
        private CCWin.SkinControl.SkinTextBox skinTextBox_opt_result;
        private System.Windows.Forms.CheckedListBox checkedListBox_work_ant;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox5;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_module_id;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_module_sn;
        private CCWin.SkinControl.SkinLabel skinLabel43;
        private CCWin.SkinControl.SkinLabel skinLabel42;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox6;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox7;
        private CCWin.SkinControl.SkinCheckBox buzzer_check;
        private CCWin.SkinControl.SkinLabel skinLabel49;
        private CCWin.SkinControl.SkinLabel skinLabel48;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_inventory_length;
        private CCWin.SkinControl.SkinLabel skinLabel47;
        private CCWin.SkinControl.SkinLabel skinLabel46;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_inventory_address;
        private CCWin.SkinControl.SkinLabel skinLabel45;
        private CCWin.SkinControl.SkinComboBox skinComboBox_inventory_area;
        private CCWin.SkinControl.SkinLabel skinLabel44;
        private CCWin.SkinControl.SkinLabel skinLabel50;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox8;
        private CCWin.SkinControl.SkinCheckBox dhcp_check;
        private CCWin.SkinControl.SkinLabel skinLabel17;
        private CCWin.SkinControl.SkinCheckBox record_check;
        private CCWin.SkinControl.SkinComboBox skinComboBox_sub_protocol;
        private CCWin.SkinControl.SkinLabel skinLabel29;
        private CCWin.SkinControl.SkinComboBox skinComboBox_wiegand_direction;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ColumnHeader columnHeader_ext;
        private CCWin.SkinControl.SkinButton skinButton_wiegand_write;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_wiegand_write_data;
        private CCWin.SkinControl.SkinLabel skinLabel51;
        private CCWin.SkinControl.SkinLine skinLine1;
        private CCWin.SkinControl.SkinGroupBox skinGroupBox4;
        private CCWin.SkinControl.SkinButton skinButton_query_time;
        private CCWin.SkinControl.SkinButton skinButton_sync_time;
        private CCWin.SkinControl.SkinButton skinButton_upload_record;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_audio_play;
        private System.Windows.Forms.TextBox textBox_audio_text;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_relay_set;
        private System.Windows.Forms.Button button_ext_fresh;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_relay_time;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkBox_relay2_auto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBox_relay1_auto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button_relay_control;
        private System.Windows.Forms.TextBox textBox_relay_ctrl_time;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox_op_index;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_audio_set_vol;
        private System.Windows.Forms.ComboBox comboBox_lock_type;
        private System.Windows.Forms.Label label16;
        private CCWin.SkinControl.SkinButton skinButton_tag_lock;
        private CCWin.SkinControl.SkinButton skinButton_kill_tag;
        private System.Windows.Forms.GroupBox groupBox4;
        private CCWin.SkinControl.SkinWaterTextBox skinWaterTextBox_dev_num;
        private CCWin.SkinControl.SkinButton skinButton_dev_set;
        private CCWin.SkinControl.SkinButton skinButton_dev_query;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox_tag_verify_pwd;
        private System.Windows.Forms.CheckBox checkBox_tag_verify;
        private CCWin.SkinControl.SkinButton skinButton_tag_verify;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox checkBox_auto_write_increse;
        private System.Windows.Forms.CheckBox checkBox_auto_write_flag;
        private System.Windows.Forms.Button button_auto_write_wiegand;
        private System.Windows.Forms.Button button_auto_write_hex;
        private System.Windows.Forms.TextBox textBox_auto_wiegand_write_text;
        private System.Windows.Forms.TextBox textBox_auto_hex_write_text;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tabPage_ExDataParam;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button_usbdata_sset;
        private System.Windows.Forms.Button button_usbdata_query;
        private System.Windows.Forms.CheckBox checkBox_usbdata_enter_flag;
        private System.Windows.Forms.ComboBox comboBox_usbdata_proto;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button_dataflag_set;
        private System.Windows.Forms.Button button_dataflag_query;
        private System.Windows.Forms.CheckBox checkBoxDataFlag_DevNo;
        private System.Windows.Forms.CheckBox checkBoxDataFlag_ANT;
        private System.Windows.Forms.CheckBox checkBoxDataFlag_RSSI;
        private System.Windows.Forms.RadioButton radioButton_USB_COM;
        private System.Windows.Forms.RadioButton radioButton_USB_HID;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button_ext_add_verify;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label_ex_modbus_register_num;
        private System.Windows.Forms.Button button_ex_modbus_set;
        private System.Windows.Forms.Button button_ex_modbus_query;
        private System.Windows.Forms.CheckBox checkBox_ex_modbus_clear_flag;
        private System.Windows.Forms.NumericUpDown numericUpDown_ex_modbus_startaddr;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown numericUpDown_ex_modbus_union_size;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown numericUpDown_ex_modbus_tag_num;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox_advan_rssi;
        private System.Windows.Forms.TabPage tabPage_filterdata;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox_dataflag_format;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RadioButton radioButton_remote_ipmode_IP;
        private System.Windows.Forms.RadioButton radioButton_remote_ipmode_host;
        private System.Windows.Forms.ComboBox comboBox_ex_modbus_proto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox_write_file_path;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button_write_file_choose;
        private System.Windows.Forms.NumericUpDown numericUpDown_write_file_row;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox_write_file_data;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button_write_file_auto;
        private System.Windows.Forms.Button button_write_file_hand;
        private System.Windows.Forms.Button button_write_file_reload;
        private CCWin.SkinControl.SkinButton skinButton_save;
        private System.Windows.Forms.Button button_ext_auto_add_verify;
    }
}