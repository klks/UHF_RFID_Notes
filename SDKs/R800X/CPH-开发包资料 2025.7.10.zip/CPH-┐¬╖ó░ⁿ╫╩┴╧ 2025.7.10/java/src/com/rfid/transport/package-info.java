/**
 * 
 */
/**
 * @author huangrongbin
 *send and receive data from rfid reader.
 */
package com.rfid.transport;