/**
 * 
 */
/**
 * @author huangrongbin
 *
 */
package com.rfid.message;