package com.rfid.AppNotifyImpl;

import com.rfid.reader.AppNotify;

public class R2000ReaderNotifyImpl implements AppNotify {

	@Override
	public int NotifyRecvTags(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		int tagCount = 0;	//��ǩ����
		int iIndex = 0;
		tagCount = message[7];
		tagCount = tagCount << 8;
		tagCount = tagCount + message[8];
		System.out.println("���յ��ı�ǩ����:"+tagCount);
		System.out.println("���յ��ı�ǩ��������:");
		for (iIndex = 0; iIndex < tagCount; iIndex++) {
			for (int jIndex = 0; jIndex < 12; jIndex++) {
				System.out.print(String.format("%2X ", message[9+iIndex*12+jIndex]));
			}
			System.out.println();
		}
		return 0;
	}

	@Override
	public int NotifyStopInventory(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		System.out.println("��д��ֹͣ����ǩ");
		return 0;
	}

	@Override
	public int NotifyReset(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		System.out.println("��д�����óɹ�");
		return 0;
	}

	@Override
	public int NotifyReadTagBlock(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyWriteTagBlock(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyLockTag(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyKillTag(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyInventoryOnce(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public int NotifyStartInventory(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		System.out.println("R2000��ʼ��Ѱ��ǩ");
		return 0;
	}
	

}
