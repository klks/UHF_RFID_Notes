import com.rfid.AppNotifyImpl.GeneralReaderNotifyImpl;
import com.rfid.AppNotifyImpl.MRfidReaderNotifyImpl;
import com.rfid.reader.MRfidReader;
import com.rfid.reader.RfidReader;
import com.rfid.transport.TransportThreadManager;

//调用接口进行测试
public class Main {
    public static void main(String[] args) {


        //如果读写器设置为TCP Server
        try {
            SerialPortTest();
        }catch (Exception ex)
        {
            ex.printStackTrace();
        }

        /*
        //如果读写器使用的是UDP传输
        try {
            //请确认RFID读写器是使用udp 传输和目的接口是PC地址
            UDPTest();
        }catch (Exception ex)
        {
            ex.printStackTrace();
        }
         */

        /*
        //如果使用串口通信
        try {
            SerialPortTest();
        }catch (Exception ex)
        {
            ex.printStackTrace();
        }
        */
    }

    public static void UDPTest() throws Exception{
        System.out.println("Start a UDP transport test.");
        TransportThreadManager.initilizeTransportManager();
        RfidReader readerServer = new MRfidReader();
        //在本地创建一个端口为12345的udp，如果要发送数据则发送目标的地址为192.168.1.65:12345
        int result = readerServer.ConnectPhysicalInterface("192.168.2.166", 12345, "127.0.0.1",12345,RfidReader.CONNECT_TYPE_NET_UDP);
        if (0 == result)
        {
            System.out.println("Success to create a reader listener.");
        }
        else
        {
            System.out.println("Fail to create a reader listener.");
            return;
        }

        readerServer.setAppNotify(new MRfidReaderNotifyImpl());
        TransportThreadManager manager = TransportThreadManager.getInstance();
        manager.AddRfidReader(readerServer);
        System.out.println("the application start recveive data from reader.");
        //如果读写器的工作模式设置为定时模式或者是触发模式那么isInventory设置为true那么就可以自动获取标签数据，如果是做其它操作那么请设置为false
        //其它那么设置为false进行其它操作
        boolean isInventoryTest = true;
        if (isInventoryTest){
            //发送重启指令后进入循环模式，在底层的线程接收到数据后会打印数据
            readerServer.Reset();
            while(true) {
                Thread.sleep(3000);
            }
        }
        else {
            //停止读卡
            readerServer.Stop();
            while(true) {
                Thread.sleep(3000);
				/*
				//停止读卡功能测试
				reader.Stop();
				*/

                /*
				//写标签数据
                writeCount++;
                writtenData[0] = (byte)(writeCount >> 24);
                writtenData[1] = (byte)(writeCount >> 16);
                writtenData[2] = (byte)(writeCount >> 8);
                writtenData[3] = (byte)writeCount;

                //写入EPC，注意EPC的起始地址从2开始，前面存储的是标签数据的长度校验等信息，不建议修改
                //用户区的数据起始地址为0
				//reader.WriteTagBlock((byte)RfidReader.MEMBANK_EPC, (byte)2, (byte)2, writtenData, 0,NULL);
                System.out.println("Write Data:"+Integer.toHexString(writtenData[0] & 0xFF)+" "+Integer.toHexString(writtenData[1] & 0xFF) + " "+Integer.toHexString(writtenData[2] & 0xFF) +" "+Integer.toHexString(writtenData[3] & 0xFF));
                reader.WriteTagBlock(MRfidReader.MEMBANK_EPC,2,writelen,writtenData,0,null);
                * */


                //读取用户区中起始地址为0，长度为2个字的数据
                //public abstract int ReadTagBlock(byte membank,byte addr,byte len,byte[] accessPassword) throws IOException;
                readerServer.ReadTagBlock((byte)RfidReader.MEMBANK_EPC, (byte)2, (byte)2,null);

                //锁定EPC区，这里不建议做测试
                //reader.LockTag((byte)0x02,null);

                //销毁标签
                //reader.KillTag();

                /*
                //通过主动发命令的方式盘寻一次标签
                reader.InventoryOnce();
                */
            }
        }
    }

    public static void TcpClientTest() throws Exception{
        System.out.println("Start a TCP transport test.");
        TransportThreadManager.initilizeTransportManager();
        TransportThreadManager manager = TransportThreadManager.getInstance();
        RfidReader reader = new MRfidReader();
        RfidReader reader2 = new MRfidReader();
        MRfidReaderNotifyImpl notify = new MRfidReaderNotifyImpl();
        //先设置读写器的网口为TCP Server模式，然后填写对端监听的IP和端口
        try {
            int result = reader.ConnectPhysicalInterface("192.168.2.149", 12345, null, 0, RfidReader.CONNECT_TYPE_NET_TCP_CLIENT);
            if (0 == result) {
                System.out.println("connet to the reader is ok, and the app will receive data.");
            } else {
                System.out.println("Fail to the reader is ok, please check the address of the reader.");
                return;
            }
            reader.setAppNotify(notify);
            manager.AddRfidReader(reader);
        }catch (Exception ex)
        {
            System.out.println("Please check the address of the reader.");
            ex.printStackTrace();
        }

        /*
        //如果要连接到多个读写器
        try {
            int result = reader2.ConnectPhysicalInterface("192.168.2.166", 12346, null, 0, RfidReader.CONNECT_TYPE_NET_TCP_CLIENT);
            if (0 == result) {
                System.out.println("connet to the reader is ok, and the app will receive data.");
            } else {
                System.out.println("Fail to the reader is ok, please check the address of the reader.");
                return;
            }
            reader2.setAppNotify(notify);
            manager.AddRfidReader(reader2);
        }catch (Exception ex)
        {
            System.out.println("Please check the address of the reader.");
            ex.printStackTrace();
        }
        */

        //如果让设备自动读卡就设置为true,其余功能测试则为false
        boolean isInventoryTest = false;
        if (isInventoryTest){
            //设备重启,也作为开始读卡用
            //如果工作模式不是主动模式则不会读卡上报数据
            reader.Reset();
            while(true) {
                Thread.sleep(3000);
                //reader.RelayControl(1,1,3);	//打开继电器1后3秒自动关闭
                //reader.RelayControl(1,0,0);	//关闭继电器1
                //reader.RelayControl(2,1,3);	//打开继电器2后3秒自动关闭
                //reader.RelayControl(2,0,0);	//关闭继电器2
                //reader.RelayControl(3,1,5);	//打开继电器1，2后5秒钟自动关闭
                //reader.RelayControl(1,1,3);	//关闭继电器1和2

            }
        }
        else {
            //做如下功能的时候最好不要让设备读标签
            reader.Stop();
            int result = 0;

            //写卡相关参数定义
            int writeCount = 0;
            byte writelen = 2;
            byte[] writtenData = new byte[writelen *  2];

            while(true) {
                Thread.sleep(3000);
				/*
				//停止读卡功能测试
				reader.Stop();
				*/

                /*
				//写标签数据
                writeCount++;
                writtenData[0] = (byte)(writeCount >> 24);
                writtenData[1] = (byte)(writeCount >> 16);
                writtenData[2] = (byte)(writeCount >> 8);
                writtenData[3] = (byte)writeCount;

                //写入EPC，注意EPC的起始地址从2开始，前面存储的是标签数据的长度校验等信息，不建议修改
                //用户区的数据起始地址为0
				//reader.WriteTagBlock((byte)RfidReader.MEMBANK_EPC, (byte)2, (byte)2, writtenData, 0,NULL);
                System.out.println("Write Data:"+Integer.toHexString(writtenData[0] & 0xFF)+" "+Integer.toHexString(writtenData[1] & 0xFF) + " "+Integer.toHexString(writtenData[2] & 0xFF) +" "+Integer.toHexString(writtenData[3] & 0xFF));
                reader.WriteTagBlock(MRfidReader.MEMBANK_EPC,2,writelen,writtenData,0,null);
                * */



				//读取用户区中起始地址为0，长度为2个字的数据
				reader.ReadTagBlock((byte)RfidReader.MEMBANK_EPC, (byte)2, (byte)2,null);


                //锁定EPC区，这里不建议做测试
                //reader.LockTag((byte)0x02,null);

                //销毁标签
                //reader.KillTag();

                /*
                //通过主动发命令的方式盘寻一次标签
                reader.InventoryOnce();
                */
            }
        }
    }

    public static void SerialPortTest() throws Exception{
        System.out.println("Start Serial Port Test....");
        TransportThreadManager.initilizeTransportManager();
        RfidReader reader = new MRfidReader();
        //打开串口4,波特率115200
        int result = reader.ConnectPhysicalInterface("COM4", 115200, null,0,RfidReader.CONNECT_TYPE_SERIALPORT);
        if (0 == result)
        {
            System.out.println("connet to the reader is ok.");
        }
        else
        {
            System.out.println("Fail to open the serial port");
            return;
        }
        reader.setAppNotify(new MRfidReaderNotifyImpl());
        TransportThreadManager manager = TransportThreadManager.getInstance();
        manager.AddRfidReader(reader);
        System.out.println("the application start recveive data from reader.");
        //如果让设备自动读卡就设置为true,其余功能测试则为false
        boolean isInventoryTest = true;
        if (isInventoryTest){
            //设备重启,也作为开始读卡用
            reader.Reset();
            while(true) {
                //标签显示会在MRfidReaderNotifyImpl的NotifyRecvTags方法中
                Thread.sleep(3000);
            }
        }
        else {
            //做如下功能的时候最好不要让设备读标签
            //reader.Stop();
            while(true) {
                Thread.sleep(3000);
				/*
				//停止读卡功能测试
				reader.Stop();
				*/

                /*
				//写标签数据
                writeCount++;
                writtenData[0] = (byte)(writeCount >> 24);
                writtenData[1] = (byte)(writeCount >> 16);
                writtenData[2] = (byte)(writeCount >> 8);
                writtenData[3] = (byte)writeCount;

                //写入EPC，注意EPC的起始地址从2开始，前面存储的是标签数据的长度校验等信息，不建议修改
                //用户区的数据起始地址为0
				//reader.WriteTagBlock((byte)RfidReader.MEMBANK_EPC, (byte)2, (byte)2, writtenData, 0,NULL);
                System.out.println("Write Data:"+Integer.toHexString(writtenData[0] & 0xFF)+" "+Integer.toHexString(writtenData[1] & 0xFF) + " "+Integer.toHexString(writtenData[2] & 0xFF) +" "+Integer.toHexString(writtenData[3] & 0xFF));
                reader.WriteTagBlock(MRfidReader.MEMBANK_EPC,2,writelen,writtenData,0,null);
                * */



                //读取用户区中起始地址为0，长度为2个字的数据
                reader.ReadTagBlock((byte)RfidReader.MEMBANK_EPC, (byte)2, (byte)2,null);


                //锁定EPC区，这里不建议做测试
                //reader.LockTag((byte)0x02,null);

                //销毁标签
                //reader.KillTag();

                /*
                //通过主动发命令的方式盘寻一次标签
                reader.InventoryOnce();
                */
            }
        }
    }
}