/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rfid_epc_project;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.win32.StdCallLibrary.StdCallCallback;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import struct.JavaStruct;
import struct.StructClass;
import struct.StructException;
import struct.StructField;

/**
 *
 * @author admin
 */
public class NewJFrame extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public NewJFrame() {
        initComponents();
        //   jComboBox1.setEditable(rootPaneCheckingEnabled);
        DLLProject = Clibrary.instance;
        jRadioButton1ItemStateChanged(null);
        jRadioButton4ItemStateChanged(null);
        SetIPList();
    }

    public interface Clibrary extends Library {

        // DLL文件默认路径为项目根目录，若DLL文件存放在项目外，请使用绝对路径。（此处：(Platform.isWindows()?"msvcrt":"c")指本地动态库msvcrt.dll）
//    Clibrary instance = (Clibrary) Native.load("D:\\Java\\RFID_EPC_Project\\DLLProject.dll", Clibrary.class);
        Clibrary instance = (Clibrary) Native.load(System.getProperty("user.dir") + "\\DLLProject_x86.dll", Clibrary.class);

        public interface CallReceive extends StdCallCallback {

            int MessageHandle(byte Type, byte Command, int RecSize, ByteByReference buf);
        }

        public interface CallReceiveEx extends StdCallCallback {

            int MessageHandle(int EventType, String IP, int Port, byte Type, byte Command, int RecSize, ByteByReference buf);
        }

        public interface SvrCallReceive extends StdCallCallback {

            int MessageHandle(byte Type, String IP, int Port, int LpRecSize, ByteByReference LpRecByt);
        }

        // 声明将要调用的DLL中的方法,可以是多个方法(此处示例调用本地动态库msvcrt.dll中的printf()方法)
        int Connect(byte ConnType, String ConnChar, CallReceive rc);

        int ConnectEx(byte ConnType, String ConnChar, CallReceiveEx rc);

        int Disconnect();

        int SetCommAddr(String ConnChar);

        int GetTcpSrvCount(IntByReference Count);

        int GetTcpSrvClientArray(IntByReference Count, byte[] Data);

        int SetRegion(byte Region);

        int GetRfChannel(ByteByReference RfChannel);

        int SetRfChannel(byte RfChannel);

        int SetFhss(boolean Fhss);

        int SetPower(int Power);

        int GetPower(IntByReference Power);

        int ReadSingle();

        int SetCW(boolean CW);

        int ReadMulti(int PollCount);

        int StopRead();

        int GetModuleInfo(ByteByReference InfoType, PointerByReference InfoData, IntByReference DataSize);

        int SetSelectMode(byte Mode);

        int SetSelectParam(byte Target, byte Action, byte MemBank, int Pointer, byte Truncated, byte[] MaskData, byte MaskSize);

        int ImpinjMonzaQT(byte[] AccessPassword, byte RW, byte Persistence, byte Payload, byte[] PC, byte[] EPC, byte[] QTControl);

        int NxpChangeConfig(byte[] AccessPassword, byte[] Config, byte[] PC, byte[] EPC);

        int NxpChangeEas(byte[] AccessPassword, byte Protect, byte[] PC, byte[] EPC);

        int NxpReadProtect(byte[] AccessPassword, byte Protect, byte[] PC, byte[] EPC);

        int NxpEasAlarm(byte[] EASAlarmCode);

        int GetQuery(ByteByReference DR, ByteByReference M, ByteByReference TRext, ByteByReference Sel, ByteByReference Session, ByteByReference Target, ByteByReference Q);

        int SetQuery(byte DR, byte M, byte TRext, byte Sel, byte Session, byte Target, byte Q);

        int ReadData(byte[] AccessPassword, byte MemBank, int StartIndex, int Length, byte[] PC, byte[] EPC, byte[] Data, IntByReference Size);

        int WriteData(byte[] AccessPassword, byte MemBank, int StartIndex, byte[] Data, int Size, byte[] PC, byte[] EPC);

        int LockUnlock(byte[] AccessPassword, byte[] LD, byte[] PC, byte[] EPC);

        int Kill(byte[] AccessPassword, byte[] PC, byte[] EPC);

        int ScanJammer(ByteByReference CH_L, ByteByReference CH_H, byte[] JMR);

        int ScanRSSI(ByteByReference CH_L, ByteByReference CH_H, byte[] JMR);

        int SetModemPara(byte Mixer_G, byte IF_G, int Thrd);

        int GetModemPara(ByteByReference Mixer_G, ByteByReference IF_G, IntByReference Thrd);

        int NetCfg_Open(String IP);

        int NetCfg_Close();

        int NetCfg_SearchForDevices(byte DeviceType, IntByReference Count, byte[] Data, IntByReference Length);

        int NetCfg_FactoryReset(byte DeviceType, byte[] MAC);

        int NetCfg_GetInfo(byte DeviceType, byte[] MAC, byte[] Data, IntByReference Length);

        int NetCfg_SetInfo(byte DeviceType, byte[] LocalMAC, byte[] DevMAC, byte[] Data, int Length);

        int Svr_Startup(byte ConnType, String ConnChar, SvrCallReceive rc);

        int Svr_CleanUp();

        int Svr_Send(String ConnChar, byte[] Data, int Length);
    }

    /**
     *
     * @return
     */
    public static List<String> getComPorts() {
        List<String> ports = new ArrayList();
        try {
            String command = "reg query HKEY_LOCAL_MACHINE\\HARDWARE\\DEVICEMAP\\SERIALCOMM";

            Process process = Runtime.getRuntime().exec(command);
            InputStream in = process.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String line;

            int index = 0;
            while ((line = br.readLine()) != null) {
                if (line == null || "".equals(line)) {
                    continue;
                }
                if (index != 0) {
                    String[] strs = line.replaceAll(" +", ",").split(",");
                    String comPort = strs[strs.length - 1];
                    ports.add(comPort);
                }
                index++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ports;
    }

    public static List<String> GetNetwork() {
        List<String> Networks = new ArrayList();
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress inetAddress = inetAddresses.nextElement();
                    if (inetAddress.isSiteLocalAddress()) {
                        Networks.add(inetAddress.getHostAddress());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Networks;
    }

    public static byte[] GetMac(String IP) {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress inetAddress = inetAddresses.nextElement();
                    if (inetAddress.isSiteLocalAddress() && IP.equals(inetAddress.getHostAddress())) {
                        return networkInterface.getHardwareAddress();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ConnGroup = new javax.swing.ButtonGroup();
        rbSvrGroup = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jRadioButton9 = new javax.swing.JRadioButton();
        jLabel63 = new javax.swing.JLabel();
        jComboBox31 = new javax.swing.JComboBox<>();
        jButton42 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jTextField32 = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jButton15 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton16 = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jPanel13 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jPanel14 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jCheckBox4 = new javax.swing.JCheckBox();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jCheckBox5 = new javax.swing.JCheckBox();
        jPanel12 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox8 = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jComboBox9 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jComboBox10 = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jComboBox11 = new javax.swing.JComboBox<>();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jComboBox12 = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        jComboBox13 = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jComboBox14 = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jCheckBox6 = new javax.swing.JCheckBox();
        jPanel16 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jComboBox15 = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jButton29 = new javax.swing.JButton();
        jCheckBox7 = new javax.swing.JCheckBox();
        jCheckBox8 = new javax.swing.JCheckBox();
        jCheckBox9 = new javax.swing.JCheckBox();
        jCheckBox10 = new javax.swing.JCheckBox();
        jCheckBox11 = new javax.swing.JCheckBox();
        jComboBox16 = new javax.swing.JComboBox<>();
        jComboBox17 = new javax.swing.JComboBox<>();
        jComboBox18 = new javax.swing.JComboBox<>();
        jComboBox19 = new javax.swing.JComboBox<>();
        jComboBox20 = new javax.swing.JComboBox<>();
        jPanel19 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jButton30 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jButton31 = new javax.swing.JButton();
        jPanel21 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jButton32 = new javax.swing.JButton();
        jPanel22 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jComboBox21 = new javax.swing.JComboBox<>();
        jLabel32 = new javax.swing.JLabel();
        jComboBox22 = new javax.swing.JComboBox<>();
        jLabel33 = new javax.swing.JLabel();
        jTextField16 = new javax.swing.JTextField();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jPanel24 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jTextField17 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jComboBox23 = new javax.swing.JComboBox<>();
        jButton35 = new javax.swing.JButton();
        jPanel27 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton36 = new javax.swing.JButton();
        jTextField19 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jCheckBox12 = new javax.swing.JCheckBox();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jCheckBox13 = new javax.swing.JCheckBox();
        jButton41 = new javax.swing.JButton();
        jPanel26 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jComboBox24 = new javax.swing.JComboBox<>();
        jCheckBox14 = new javax.swing.JCheckBox();
        jTextField24 = new javax.swing.JTextField();
        jComboBox25 = new javax.swing.JComboBox<>();
        jTextField25 = new javax.swing.JTextField();
        jTextField26 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jComboBox26 = new javax.swing.JComboBox<>();
        jComboBox27 = new javax.swing.JComboBox<>();
        jComboBox28 = new javax.swing.JComboBox<>();
        jComboBox29 = new javax.swing.JComboBox<>();
        jCheckBox15 = new javax.swing.JCheckBox();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jCheckBox16 = new javax.swing.JCheckBox();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jButton40 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jRadioButton6 = new javax.swing.JRadioButton();
        jRadioButton7 = new javax.swing.JRadioButton();
        jButton37 = new javax.swing.JButton();
        jLabel60 = new javax.swing.JLabel();
        jComboBox30 = new javax.swing.JComboBox<>();
        jButton38 = new javax.swing.JButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jPanel29 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jPanel30 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        jTextField30 = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jTextField31 = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        jButton39 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Clear");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(190, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
            .addComponent(jScrollPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1))
        );

        jTabbedPane1.setToolTipText("");

        jPanel2.setToolTipText("");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "PC", "EPC", "CRC", "RSSI(dBm)", "CNT", "PER(%)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setColumnSelectionAllowed(true);
        jTable2.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(jTable2);
        jTable2.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setPreferredWidth(40);
            jTable2.getColumnModel().getColumn(1).setPreferredWidth(60);
            jTable2.getColumnModel().getColumn(2).setPreferredWidth(240);
            jTable2.getColumnModel().getColumn(3).setPreferredWidth(60);
            jTable2.getColumnModel().getColumn(4).setPreferredWidth(75);
            jTable2.getColumnModel().getColumn(5).setPreferredWidth(75);
        }

        jPanel3.setPreferredSize(new java.awt.Dimension(271, 151));

        jButton2.setText("Connect");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        ConnGroup.add(jRadioButton1);
        jRadioButton1.setSelected(true);
        jRadioButton1.setText("SerialPort");
        jRadioButton1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButton1ItemStateChanged(evt);
            }
        });

        ConnGroup.add(jRadioButton2);
        jRadioButton2.setText("USB");
        jRadioButton2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButton2ItemStateChanged(evt);
            }
        });

        ConnGroup.add(jRadioButton3);
        jRadioButton3.setText("TcpClient");
        jRadioButton3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButton3ItemStateChanged(evt);
            }
        });

        jLabel1.setText("Value");

        jComboBox2.setEditable(true);

        ConnGroup.add(jRadioButton9);
        jRadioButton9.setText("TcpClient");
        jRadioButton9.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButton9ItemStateChanged(evt);
            }
        });

        jLabel63.setText("CommAddr");

        jComboBox31.setEditable(true);
        jComboBox31.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox31ItemStateChanged(evt);
            }
        });

        jButton42.setText("GetTcpSrvClientArray");
        jButton42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton42ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButton1)
                                    .addComponent(jRadioButton3))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButton9)
                                    .addComponent(jRadioButton2))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jLabel63)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox31, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton42)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButton1)
                            .addComponent(jRadioButton2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButton3)
                            .addComponent(jRadioButton9))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel63)
                    .addComponent(jComboBox31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton42)
                .addContainerGap())
        );

        jButton3.setText("Set Region");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Set RFCH");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "China2", "China1", "US", "Europe", "Korea" }));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "920.125MHz", "920.375MHz", "920.625MHz", "920.875MHz", "921.125MHz", "921.375MHz", "921.625MHz", "921.875MHz", "922.125MHz", "922.375MHz", "922.625MHz", "922.875MHz", "923.125MHz", "923.375MHz", "923.625MHz", "923.875MHz", "924.125MHz", "924.375MHz", "924.625MHz", "924.875MHz" }));

        jButton5.setText("Get RFCH");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("FHSS OFF");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5)
                    .addComponent(jButton6))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton7.setText("Set PA Power");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel2.setText("dBm");

        jButton8.setText("Get PA Power");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jTextField32.setText("20.00");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField32, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jLabel2)
                    .addComponent(jButton8)
                    .addComponent(jTextField32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton9.setText("Read Single");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setText("Read Multi");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setText("Continue");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel3.setText("Q =");

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8" }));

        jTextField1.setText("65535");

        jLabel4.setText("0-65535");

        jTextField2.setText("60");

        jLabel5.setText("ms");

        jButton12.setText("CW ON");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setText("Stop Read");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setText("Module Info");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton9)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jButton13))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton11)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jButton14))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 645, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(983, 983, 983))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 634, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        jTabbedPane1.addTab("Connection & Read EPC", jPanel2);

        jButton15.setText("Clear");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "PC", "EPC", "CRC", "CNT"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(40);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(120);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(120);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(200);
        }

        jButton16.setText("Read Single");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jCheckBox1.setText("Select");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jLabel6.setText("Access Password");

        jTextField3.setText("00 00 00 00");

        jButton17.setText("QT Read");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setText("QT Write");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jCheckBox2.setText("QT_SR");

        jCheckBox3.setText("QT_MEM");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton17)
                    .addComponent(jButton18)
                    .addComponent(jCheckBox2)
                    .addComponent(jCheckBox3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel7.setText("Access Password");

        jTextField4.setText("00 00 00 00");

        jButton19.setText("Change Config");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton20.setText("ReadProtect");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jLabel8.setText("Config-Word");

        jTextField5.setText("00 00");

        jCheckBox4.setText("Reset");

        jButton21.setText("Change EAS");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jButton22.setText("EAS Alarm");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jCheckBox5.setText("Set EAS");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jCheckBox4)
                        .addGap(18, 18, 18)
                        .addComponent(jButton22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton21)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jCheckBox5)
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jButton21)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jCheckBox4)
                            .addComponent(jButton20)
                            .addComponent(jButton22)))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jButton19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jCheckBox5)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton15))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addComponent(jButton16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton16)
                    .addComponent(jCheckBox1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel9.setText("DR =");

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8", "64/3" }));
        jComboBox5.setMinimumSize(new java.awt.Dimension(40, 21));
        jComboBox5.setPreferredSize(new java.awt.Dimension(40, 21));

        jLabel10.setText("M =");

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "4", "8" }));
        jComboBox6.setMinimumSize(new java.awt.Dimension(40, 21));
        jComboBox6.setPreferredSize(new java.awt.Dimension(40, 21));

        jLabel11.setText("TRext =");

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NoPilot", "UsePilot" }));

        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL(00)", "ALL(01)", "~SL(10)", "SL(11)" }));

        jLabel12.setText("Sel =");

        jLabel13.setText("Session =");

        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "S0", "S1", "S2", "S3" }));
        jComboBox9.setMinimumSize(new java.awt.Dimension(40, 21));
        jComboBox9.setPreferredSize(new java.awt.Dimension(40, 21));

        jLabel14.setText("Target =");

        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "B" }));
        jComboBox10.setMinimumSize(new java.awt.Dimension(40, 21));
        jComboBox10.setPreferredSize(new java.awt.Dimension(40, 21));

        jLabel15.setText("Q =");

        jComboBox11.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8" }));
        jComboBox11.setMinimumSize(new java.awt.Dimension(40, 21));
        jComboBox11.setPreferredSize(new java.awt.Dimension(40, 21));

        jButton23.setText("Get Query");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jButton24.setText("Set Query");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton24)
                        .addGap(25, 25, 25))))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14)
                        .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel15)
                        .addComponent(jComboBox11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton23)
                        .addComponent(jButton24)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton25.setText("Set Select");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        jButton26.setText("Get Select");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jLabel16.setText("Target");

        jComboBox12.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "S0(000)", "S1(001)", "S2(010)", "S3(011)", "SL(100)", "RFU(101)", "RFU(110)", "RFU(111)" }));

        jLabel17.setText("Action");

        jComboBox13.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "000", "001", "010", "011", "100", "101", "110", "111" }));

        jLabel18.setText("MemBank");

        jComboBox14.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "RFU", "EPC", "TID", "User" }));

        jLabel19.setText("Pointer");

        jTextField6.setText("00 00 00 20");

        jLabel20.setText("Mask");

        jTextField8.setEditable(false);

        jLabel21.setText("Mask");

        jCheckBox6.setText("Truncate");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jButton26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField8))
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addComponent(jLabel20)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox6)
                        .addGap(74, 74, 74))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jButton25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel16)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel17)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel18)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jLabel19)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton25)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jComboBox14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addGap(27, 27, 27))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jButton26))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox6))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel22.setText("MemBank");

        jComboBox15.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "RFU", "EPC", "TID", "User" }));

        jLabel23.setText("Word Pointer");

        jTextField9.setText("00 00");

        jLabel24.setText("Word Counter");

        jTextField10.setText("00 08");

        jLabel25.setText("Access Password");

        jTextField11.setText("00 00 00 00");

        jLabel26.setText("Data:");

        jButton27.setText("Read");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        jButton28.setText("Write");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jLabel27.setText("(Max Length is 32 Words)");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel22)))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel23)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel25))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField12)))
                .addContainerGap())
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(jButton27)
                .addGap(101, 101, 101)
                .addComponent(jButton28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel27)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addComponent(jLabel24)
                            .addGap(27, 27, 27))
                        .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addComponent(jLabel23)
                            .addGap(27, 27, 27))
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addComponent(jLabel22)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jComboBox15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton27)
                    .addComponent(jButton28)
                    .addComponent(jLabel27))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel28.setText("Access Password");

        jTextField13.setText("00 00 00 00");

        jButton29.setText("Lock");
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        jCheckBox7.setText("Kill Pwd");

        jCheckBox8.setText("TID");

        jCheckBox9.setText("Access Pwd");

        jCheckBox10.setText("User");

        jCheckBox11.setText("EPC");

        jComboBox16.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Open", "PWD R/W", "Perma Open", "Perma NOT R/W" }));

        jComboBox17.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Open", "PWD Lock", "Perma Open", "Perma Lock" }));

        jComboBox18.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Open", "PWD R/W", "Perma Open", "Perma NOT R/W" }));

        jComboBox19.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Open", "PWD Lock", "Perma Open", "Perma Lock" }));

        jComboBox20.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Open", "PWD Lock", "Perma Open", "Perma Lock" }));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addComponent(jCheckBox7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBox16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jCheckBox9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBox18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(181, 181, 181))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel18Layout.createSequentialGroup()
                                .addComponent(jCheckBox11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jCheckBox8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jCheckBox10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel18Layout.createSequentialGroup()
                                .addComponent(jLabel28)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton29)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton29))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox7)
                    .addComponent(jCheckBox9)
                    .addComponent(jComboBox16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jCheckBox8)
                        .addComponent(jCheckBox10)
                        .addComponent(jComboBox17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jCheckBox11)
                        .addComponent(jComboBox20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel29.setText("Kill Password");

        jTextField14.setText("00 00 00 00");

        jLabel30.setText("RFU(3 bits)");

        jTextField15.setText("000");

        jButton30.setText("Kill");
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton30)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30)
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton30))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel16, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 1, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 117, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Read & Write Tag Memory", jPanel4);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane4.setViewportView(jTextArea2);

        jButton31.setText("Scan Jammer");
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton31)
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addComponent(jScrollPane4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton31)
                .addContainerGap())
        );

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jScrollPane5.setViewportView(jTextArea3);

        jButton32.setText("Scan RSSI");
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton32)
                .addContainerGap())
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 601, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton32)
                .addContainerGap())
        );

        jLabel31.setText("Mixer Gain");

        jComboBox21.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0dB", "3dB", "6dB", "9dB", "12dB", "15dB", "16dB" }));

        jLabel32.setText("IF Amp Gain");

        jComboBox22.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "12dB", "18dB", "21dB", "24dB", "27dB", "30dB", "36dB", "40dB" }));

        jLabel33.setText("Threshold");

        jTextField16.setText("01B0");

        jButton33.setText("Set Modem");
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });

        jButton34.setText("Get Modem");
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jButton33)
                        .addGap(42, 42, 42)
                        .addComponent(jButton34))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel31))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel32)
                            .addComponent(jComboBox22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jTextField16))
                            .addComponent(jLabel33))))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel33)
                            .addComponent(jLabel32))
                        .addGap(27, 27, 27)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton33)
                    .addComponent(jButton34))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jLabel34.setText("Antenna Gain");

        jTextField17.setText("1");

        jLabel35.setText("Coupling of Coupler");

        jTextField18.setText("-27");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel34))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel35)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 236, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Test & Modem Setting", jPanel5);

        jLabel36.setText("network interface:");

        jButton35.setText("Refresh");

        jPanel27.setBorder(javax.swing.BorderFactory.createTitledBorder("Device list (double-click the module in the device list to get the configuration of the corresponding device)"));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Device name", "IP", "MAC", "Version"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(jTable3);
        if (jTable3.getColumnModel().getColumnCount() > 0) {
            jTable3.getColumnModel().getColumn(0).setPreferredWidth(40);
            jTable3.getColumnModel().getColumn(1).setPreferredWidth(120);
            jTable3.getColumnModel().getColumn(2).setPreferredWidth(120);
            jTable3.getColumnModel().getColumn(3).setPreferredWidth(200);
        }

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane8)
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 262, Short.MAX_VALUE)
        );

        jButton36.setText("Search device ");
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });

        jTextField19.setEnabled(false);

        jCheckBox12.setText("Enabled");

        jLabel42.setText("Gateway:");

        jLabel43.setText("negotiation configuration for Serial port:");

        jLabel37.setText("MAC of device:");

        jLabel38.setText("Device name:");

        jLabel39.setText("HDCP:");

        jLabel40.setText("Device IP:");

        jLabel41.setText("Mask:");

        jCheckBox13.setText("Enabled");

        jButton41.setText("Factory reset");
        jButton41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton41ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBox23, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton35))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton41)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel42, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel43, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel37, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel39, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel40, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel41, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jCheckBox12)
                                    .addComponent(jTextField19)
                                    .addComponent(jTextField20)
                                    .addComponent(jTextField21, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                                    .addComponent(jTextField22, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                                    .addComponent(jTextField23, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                                    .addComponent(jCheckBox13))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel36)
                    .addComponent(jComboBox23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton35))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton36)
                .addGap(18, 18, 18)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel38)
                    .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox12)
                    .addComponent(jLabel39))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(jCheckBox13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton41)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jLabel44.setText("Net mode:");

        jLabel45.setText("Local port:");

        jLabel46.setText("IP / Domain:");

        jLabel47.setText("Domain:");

        jLabel48.setText("IP:");

        jLabel49.setText("destination port:");

        jLabel50.setText("BaudRate:");

        jLabel51.setText("DataSize:");

        jLabel52.setText("StopBits:");

        jLabel53.setText("Parity:");

        jLabel54.setText("PHY  disconnects:");

        jLabel55.setText("Package size of Rx data:");

        jLabel56.setText("Timeout of Rx data:");

        jLabel57.setText("Reset control:");

        jComboBox24.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TCP SERVER", "TCP CLIENT", "UDP SERVER", "UDP CLIENT" }));

        jCheckBox14.setText("random");

        jComboBox25.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "IP", "Domain" }));

        jComboBox26.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "300", "600", "1200", "2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200", "230400", "460800", "921600" }));

        jComboBox27.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "5", "6", "7", "8" }));

        jComboBox28.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "1.5", "2" }));

        jComboBox29.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Odd parity", "Even parity", "Mark parity", "Space parity", "None" }));

        jCheckBox15.setText("close socket");

        jCheckBox16.setText("flush data buffer on serial port");

        jLabel58.setText("(<=512)");

        jLabel59.setText("(10ms)");

        jButton40.setText("Configure equipment parameters");
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel44, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel45, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel46, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel57, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel47, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel48, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel49, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel50, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel51, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel52, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel53, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel54, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel55, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel56, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jComboBox24, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel26Layout.createSequentialGroup()
                                    .addComponent(jCheckBox14)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jComboBox25, 0, 142, Short.MAX_VALUE)
                                .addComponent(jTextField25))
                            .addComponent(jTextField26, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox26, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox27, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox28, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox29, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox15)
                            .addGroup(jPanel26Layout.createSequentialGroup()
                                .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel58))
                            .addGroup(jPanel26Layout.createSequentialGroup()
                                .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel59))
                            .addComponent(jCheckBox16))
                        .addGap(0, 24, Short.MAX_VALUE))
                    .addComponent(jButton40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel44)
                    .addComponent(jComboBox24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(jCheckBox14)
                    .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(jComboBox25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel48)
                    .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(jTextField26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49)
                    .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel50)
                    .addComponent(jComboBox26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel51)
                    .addComponent(jComboBox27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel52)
                    .addComponent(jComboBox28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel53)
                    .addComponent(jComboBox29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel54)
                    .addComponent(jCheckBox15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel55)
                    .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel58))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel56)
                    .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel59))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel57)
                    .addComponent(jCheckBox16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton40)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Net Module Config", jPanel6);

        rbSvrGroup.add(jRadioButton6);
        jRadioButton6.setText("TcpServer");

        rbSvrGroup.add(jRadioButton7);
        jRadioButton7.setText("UDP");

        jButton37.setText("Startup");
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });

        jLabel60.setText("Value");

        jComboBox30.setEditable(true);

        jButton38.setText("Refresh");

        rbSvrGroup.add(jRadioButton4);
        jRadioButton4.setSelected(true);
        jRadioButton4.setText("SerialPort");
        jRadioButton4.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButton4ItemStateChanged(evt);
            }
        });

        rbSvrGroup.add(jRadioButton5);
        jRadioButton5.setText("TcpClient");
        jRadioButton5.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButton5ItemStateChanged(evt);
            }
        });

        rbSvrGroup.add(jRadioButton8);
        jRadioButton8.setText("USB");
        jRadioButton8.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButton8ItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton37)
                .addGap(32, 32, 32)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(jLabel60)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox30, 0, 326, Short.MAX_VALUE))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(jRadioButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton7)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton38)
                .addGap(422, 422, 422))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButton4)
                            .addComponent(jRadioButton5)
                            .addComponent(jRadioButton6)
                            .addComponent(jRadioButton7)
                            .addComponent(jRadioButton8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel60)
                            .addComponent(jComboBox30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTextArea4.setColumns(20);
        jTextArea4.setRows(5);
        jScrollPane6.setViewportView(jTextArea4);

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6)
                .addContainerGap())
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel61.setText("IP:");

        jLabel62.setText("Port:");

        jTextArea5.setColumns(20);
        jTextArea5.setRows(5);
        jTextArea5.setText("BB 00 22 00 00 22 7E");
        jScrollPane7.setViewportView(jTextArea5);

        jButton39.setText("Send Data");
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel61, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel62, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton39)
                .addContainerGap())
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel30Layout.createSequentialGroup()
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel61)
                            .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel62)
                            .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Response Service", jPanel7);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 985, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTabbedPane1))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private Integer RetDword = 0;
    private Clibrary DLLProject;

    public enum ConnType {
        Com((byte) 0x01), USB((byte) 0x02), TcpCli((byte) 0x03), TcpSvr((byte) 0x04), UDP((byte) 0x05);
        private final byte Type;

        private ConnType(byte _Type) {
            this.Type = _Type;
        }

        public byte GetConn() {
            return this.Type;
        }
    }

    private void ShowRetDword(String CommandStr) {
        ShowRetDword(CommandStr, null);
    }

    private void ShowRetDword(String CommandStr, String DataText) {
        jTextArea1.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()).toString() + "\r\n");
        jTextArea1.append("Command:" + CommandStr + ";Status:" + (RetDword == 0 ? "Succeed" : "Failure[" + Integer.toHexString(RetDword) + "]") + "\r\n");
        if (DataText != null && DataText != "") {
            jTextArea1.append("DataText:" + DataText + "\r\n");
        }
        jTextArea1.append("\r\n");
        jTextArea1.selectAll();
    }
    private void jRadioButton1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButton1ItemStateChanged
        // TODO add your handling code here:
        if (jRadioButton1.isSelected()) {
            jComboBox2.removeAllItems();
            for (String Cp : getComPorts()) {
                jComboBox2.addItem(Cp);
            }
        }
    }//GEN-LAST:event_jRadioButton1ItemStateChanged

    private void jRadioButton2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButton2ItemStateChanged
        // TODO add your handling code here:
        if (jRadioButton2.isSelected()) {
            jComboBox2.removeAllItems();
        }
    }//GEN-LAST:event_jRadioButton2ItemStateChanged

    private void jRadioButton3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButton3ItemStateChanged
        // TODO add your handling code here:
        if (jRadioButton3.isSelected()) {
            jComboBox2.removeAllItems();
        }
    }//GEN-LAST:event_jRadioButton3ItemStateChanged
    public String BytesToHexString(byte[] b, String Padding) {
        return BytesToHexString(b, Padding, 0, b.length);
    }

    public String BytesToHexString(byte[] b, String Padding, int startIndex, int length) {
        String RetStr = "";
        for (int i = 0; i < length; i++) {
            String TmpStr = Integer.toHexString(b[i + startIndex] & 0xFF);
            if (TmpStr.length() < 2) {
                TmpStr = "0" + TmpStr;
            }
            RetStr += TmpStr + Padding;
        }
        if (RetStr.length() > 0) {
            RetStr = RetStr.substring(0, RetStr.length() - Padding.length()).toUpperCase();
        }
        return RetStr;
    }

    String BytesToIP(byte[] Bytes) {
        return BytesToIP(Bytes, 0, 4);
    }

    String BytesToIP(byte[] Bytes, int startIndex, int length) {
        int NumSize = 4 > length ? length : 4;
        String RetStr = "";
        for (int i = 0; i < NumSize; i++) {
            RetStr += String.valueOf(Bytes[i + startIndex] & 0xFF) + ".";
        }
        if (RetStr.length() > 0) {
            RetStr = RetStr.substring(0, RetStr.length() - 1);
        }
        return RetStr;
    }

    public byte[] IPToBytes(String IPStr) {
        String[] IpStrList = IPStr.split("\\.");
        if (IpStrList == null || IpStrList.length < 4) {
            return new byte[4];
        }
        String HexStr = "";
        for (int i = 0; i < IpStrList.length; i++) {
            String TmpStr = Integer.toHexString(Integer.valueOf(IpStrList[i]));
            if (TmpStr.length() < 2) {
                TmpStr = "0" + TmpStr;
            }
            HexStr += TmpStr;
        }
        return HexStringToBytes(HexStr);
    }

    public byte[] HexStringToBytes(String HexStr, String Padding) {
        String TmpStr = HexStr.replace(Padding, "");
        return HexStringToBytes(TmpStr);
    }

    public byte[] HexStringToBytes(String HexStr) {
        List<Byte> Bytes = new ArrayList();
        String TmpStr = HexStr.replace(" ", "").replace("-", "").replace(":", "");
        if (TmpStr.length() % 2 > 0) {
            TmpStr = "0" + TmpStr;
        }
        int byteLen = TmpStr.length() / 2;
        byte[] ret = new byte[byteLen];
        for (int i = 0; i < byteLen; i++) {
            int m = i * 2 + 1;
            int n = m + 1;
            int intVal = Integer.decode("0x" + TmpStr.substring(i * 2, i * 2 + 2));
            ret[i] = Byte.valueOf((byte) intVal);
        }
        return ret;
    }

    long BytesToLong(byte[] Bytes) {
        return BytesToLong(Bytes, 0, Bytes.length);
    }

    long BytesToLong(byte[] Bytes, int startIndex, int length) {
        int NumSize = 8 > length ? length : 8;
        long RetLong = 0;
        for (int i = 0; i < NumSize; i++) {
            RetLong <<= 8;
            RetLong += Bytes[i + startIndex] & 0xFF;
        }
        return RetLong;
    }

    int BytesToInt(byte[] Bytes, int startIndex, int length) {
        int NumSize = 4 > length ? length : 4;
        long RetLong = BytesToLong(Bytes, startIndex, NumSize);
        return (int) RetLong;
    }

    int BytesToInt(byte[] Bytes) {
        return BytesToInt(Bytes, 0, Bytes.length);
    }

    short BytesToShort(byte[] Bytes, int startIndex, int length) {
        int NumSize = 2 > length ? length : 2;
        long RetLong = BytesToLong(Bytes, startIndex, NumSize);
        return (short) RetLong;
    }

    short BytesToShort(byte[] Bytes) {
        return BytesToShort(Bytes, 0, Bytes.length);
    }

    public class CallReceiveImpl implements Clibrary.CallReceive {

        @Override
        public int MessageHandle(byte Type, byte Command, int RecSize, ByteByReference buf) {
            // TODO Auto-generated method stub
            byte[] b = buf.getPointer().getByteArray(0, RecSize);
            String TmpStr = BytesToHexString(b, " ");
            ShowRetDword("DataReceive", TmpStr);
            ProcReceive(Type, Command, b);
            return 0;
        }
    }

    public class CallReceiveExImpl implements Clibrary.CallReceiveEx {

        @Override
        public int MessageHandle(int EventType, String IP, int Port, byte Type, byte Command, int RecSize, ByteByReference buf) {
            // TODO Auto-generated method stub
            if (EventType == 0x01) {
                ShowRetDword("DataReceiveEx_Accept", "Addr:" + IP + ":" + String.valueOf(Port));
            } else if (EventType == 0x02) {
                byte[] b = buf.getPointer().getByteArray(0, RecSize);
                String TmpStr = BytesToHexString(b, " ");
                ShowRetDword("DataReceiveEx_Data", "Addr:" + IP + ":" + String.valueOf(Port) + ";Data:" + TmpStr);
                ProcReceive(Type, Command, b);
            } else if (EventType == 0x03) {
                ShowRetDword("DataReceiveEx_Close", "Addr:" + IP + ":" + String.valueOf(Port));
            }
            return 0;
        }
    }

    public class SvrCallReceiveImpl implements Clibrary.SvrCallReceive {

        @Override
        public int MessageHandle(byte Type, String IP, int Port, int LpRecSize, ByteByReference LpRecByt) {
            // TODO Auto-generated method stub
            byte[] b = LpRecByt.getPointer().getByteArray(0, LpRecSize);
            String MsgStr = "";
            jTextArea4.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()).toString() + "\r\n");
            MsgStr = "Type:" + String.valueOf(Type) + ";IP:" + IP + ";Port:" + String.valueOf(Port) + ";";
            if (LpRecSize > 0) {
                String BytStr = BytesToHexString(b, " ");
                MsgStr += "Data:" + BytStr + ";";
            }
            jTextArea4.append(MsgStr + "\r\n");
            jTextArea4.append("\r\n");
            jTextArea4.selectAll();

            return 0;
        }
    }
    int SucessEPCNum = 0;
    double db_errEPCNum = 0, FailEPCNum = 0, db_LoopNum_cnt = 0, errnum = 0;

    void ProcReceive(byte Type, byte Command, byte[] ParamData) {
        if (Type == 0x02 && Command == 0x22 && ParamData != null) {
            SucessEPCNum = SucessEPCNum + 1;
            db_errEPCNum = FailEPCNum;
            db_LoopNum_cnt = db_LoopNum_cnt + 1;
            errnum = (db_errEPCNum / db_LoopNum_cnt) * 100;
            DecimalFormat df = new DecimalFormat(".00");
            String per = df.format(errnum);

            int rssidBm = ParamData[0];
            if (rssidBm > 127) {
                rssidBm = -((-rssidBm) & 0xFF);
            }
            rssidBm -= Integer.valueOf(jTextField17.getText());
            rssidBm -= Integer.valueOf(jTextField18.getText());
            String rssi = String.valueOf(rssidBm);

            int PCEPCLength = (ParamData[1] / 8) * 2;
            String pc = BytesToHexString(ParamData, " ", 1, 2);
            String epc = BytesToHexString(ParamData, " ", 3, PCEPCLength);
            String crc = BytesToHexString(ParamData, " ", 3 + PCEPCLength, 2);
            GetEPC(pc, epc, crc, rssi, per);
        }
    }

    private void GetEPC(String pc, String epc, String crc, String rssi, String per) {
        jTable1.clearSelection();

        lbDo1:
        {
            for (int i = 0; i < jTable2.getRowCount(); i++) {
                if (epc.equals(jTable2.getValueAt(i, 2))) {
                    jTable2.setValueAt(rssi, i, 4);
                    jTable2.setValueAt(String.valueOf(Integer.valueOf(jTable2.getValueAt(i, 5).toString()) + 1), i, 5);
                    jTable2.setValueAt(per, i, 6);
                    break lbDo1;
                }
            }
            DefaultTableModel Tm = (DefaultTableModel) jTable2.getModel();
            Vector<String> RowData = new Vector<String>();
            RowData.add(String.valueOf(jTable2.getRowCount() + 1));
            RowData.add(pc);
            RowData.add(epc);
            RowData.add(crc);
            RowData.add(rssi);
            RowData.add("1");
            RowData.add(per);
            Tm.addRow(RowData);
        }
        lbDo2:
        {
            for (int i = 0; i < jTable1.getRowCount(); i++) {
                if (epc.equals(jTable1.getValueAt(i, 2))) {
                    jTable1.setValueAt(String.valueOf(Integer.valueOf(jTable1.getValueAt(i, 4).toString()) + 1), i, 4);
                    break lbDo2;
                }
            }
            DefaultTableModel Tm = (DefaultTableModel) jTable1.getModel();
            Vector<String> RowData = new Vector<String>();
            RowData.add(String.valueOf(jTable1.getRowCount() + 1));
            RowData.add(pc);
            RowData.add(epc);
            RowData.add(crc);
            RowData.add("1");
            Tm.addRow(RowData);
        }
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        jButton10.setEnabled(true);
        jButton13.setEnabled(true);
        String CommandStr = jButton2.getText();
        Clibrary.CallReceive callReceive = new CallReceiveImpl();
        Clibrary.CallReceiveEx callReceiveEx = new CallReceiveExImpl();
        if (CommandStr == "Connect") {
            if (jRadioButton1.isSelected()) {
                RetDword = DLLProject.Connect(ConnType.Com.GetConn(), jComboBox2.getEditor().getItem().toString(), callReceive);
            } else if (jRadioButton2.isSelected()) {
                jButton10.setEnabled(false);
                jButton13.setEnabled(false);
                RetDword = DLLProject.Connect(ConnType.USB.GetConn(), null, callReceive);
            } else if (jRadioButton3.isSelected()) {
                RetDword = DLLProject.Connect(ConnType.TcpCli.GetConn(), jComboBox2.getEditor().getItem().toString(), callReceive);
            } else if (jRadioButton9.isSelected()) {
                RetDword = DLLProject.ConnectEx(ConnType.TcpSvr.GetConn(), jComboBox2.getEditor().getItem().toString(), callReceiveEx);
            }
            if (RetDword == 0) {
                jButton2.setText("Disconnect");
            }
        } else {
            RetDword = DLLProject.Disconnect();
            jButton2.setText("Connect");
        }
        ShowRetDword(CommandStr);
    }//GEN-LAST:event_jButton2ActionPerformed
    private byte GetRegionType(String Name) {
        switch (Name) {
            case "China1":
                return 0x01;
            case "US":
                return 0x02;
            case "Europe":
                return 0x03;
            case "China2":
                return 0x04;
            case "Korea":
                return 0x06;
        }
        return 0x01;
    }
  private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      // TODO add your handling code here:
      byte RegionType = GetRegionType(jComboBox1.getSelectedItem().toString());
      RetDword = DLLProject.SetRegion(RegionType);
      ShowRetDword("SetRegion");
  }//GEN-LAST:event_jButton3ActionPerformed

  private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
      // TODO add your handling code here:
      byte RegionType = GetRegionType(jComboBox1.getSelectedItem().toString());
      ByteByReference RfChannel = new ByteByReference();
      RetDword = DLLProject.GetRfChannel(RfChannel);
      ShowRetDword("GetRfChannel");
      jComboBox3.setSelectedIndex(RfChannel.getValue());
  }//GEN-LAST:event_jButton5ActionPerformed

  private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
      // TODO add your handling code here:
      byte RegionType = GetRegionType(jComboBox1.getSelectedItem().toString());
      jComboBox3.removeAllItems();
      switch (RegionType) {
          case 0x01: {
              for (int i = 0; i < 20; i++) {
                  jComboBox3.addItem(String.valueOf((840.125 + i * 0.25)) + "MHz");
              }
          }
          break;
          case 0x02: {
              for (int i = 0; i < 20; i++) {
                  jComboBox3.addItem(String.valueOf((902.25 + i * 0.5)) + "MHz");
              }
          }
          break;
          case 0x03: {
              for (int i = 0; i < 20; i++) {
                  jComboBox3.addItem(String.valueOf((865.1 + i * 0.2)) + "MHz");
              }
          }
          break;
          case 0x04: {
              for (int i = 0; i < 20; i++) {
                  jComboBox3.addItem(String.valueOf((920.125 + i * 0.25)) + "MHz");
              }
          }
          break;
          case 0x06: {
              for (int i = 0; i < 20; i++) {
                  jComboBox3.addItem(String.valueOf((917.1 + i * 0.2)) + "MHz");
              }
          }
          break;
      }
      jComboBox3.setSelectedIndex(0);
  }//GEN-LAST:event_jComboBox1ItemStateChanged

  private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
      // TODO add your handling code here:
      byte RfChannel = (byte) jComboBox3.getSelectedIndex();
      RetDword = DLLProject.SetRfChannel(RfChannel);
      ShowRetDword("SetRfChannel");
  }//GEN-LAST:event_jButton4ActionPerformed

  private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
      // TODO add your handling code here:
      boolean Fhss = false;
      if (jButton6.getText() == "FHSS OFF") {
          Fhss = false;
          jButton6.setText("FHSS ON");
      } else {
          Fhss = true;
          jButton6.setText("FHSS OFF");
      }
      RetDword = DLLProject.SetFhss(Fhss);
      ShowRetDword("SetFhss");
  }//GEN-LAST:event_jButton6ActionPerformed

  private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
      // TODO add your handling code here:
      double TmpDouble = Double.valueOf(jTextField32.getText());
      DecimalFormat df = new DecimalFormat(".00");
      int Power = Double.valueOf(Double.valueOf(jTextField32.getText()) * 100).intValue();
      RetDword = DLLProject.SetPower(Power);
      ShowRetDword("SetPower");
  }//GEN-LAST:event_jButton7ActionPerformed

  private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
      // TODO add your handling code here:
      IntByReference Power = new IntByReference();
      RetDword = DLLProject.GetPower(Power);
      ShowRetDword("GetPower");
      DecimalFormat df = new DecimalFormat(".00");
      jTextField32.setText(df.format(Power.getValue() / (double) 100));
  }//GEN-LAST:event_jButton8ActionPerformed

  private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
      // TODO add your handling code here:
      RetDword = DLLProject.ReadSingle();
      ShowRetDword("ReadSingle");
  }//GEN-LAST:event_jButton9ActionPerformed

  private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
      // TODO add your handling code here:   
      boolean CW = false;
      if (jButton6.getText() == "CW OFF") {
          CW = false;
          jButton6.setText("CW ON");
      } else {
          CW = true;
          jButton6.setText("CW OFF");
      }
      RetDword = DLLProject.SetCW(CW);
      ShowRetDword("SetCW");
  }//GEN-LAST:event_jButton12ActionPerformed

  private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
      // TODO add your handling code here:
      RetDword = DLLProject.ReadMulti(Integer.valueOf(jTextField1.getText()));
      ShowRetDword("ReadMulti");
  }//GEN-LAST:event_jButton10ActionPerformed

  private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
      // TODO add your handling code here:
      RetDword = DLLProject.StopRead();
      ShowRetDword("StopRead");
  }//GEN-LAST:event_jButton13ActionPerformed

  private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
      // TODO add your handling code here:
      ByteByReference InfoType = new ByteByReference();
      PointerByReference InfoData = new PointerByReference();
      IntByReference DataSize = new IntByReference();
      RetDword = DLLProject.GetModuleInfo(InfoType, InfoData, DataSize);
      String val = InfoData.getPointer().getString(0);
      ShowRetDword("GetModuleInfo", val.substring(0, DataSize.getValue()));

  }//GEN-LAST:event_jButton14ActionPerformed

  private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
      // TODO add your handling code here:
      RetDword = DLLProject.ReadSingle();
      ShowRetDword("ReadSingle");
  }//GEN-LAST:event_jButton16ActionPerformed

  private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
      // TODO add your handling code here:
      RetDword = DLLProject.SetSelectMode(jCheckBox1.isSelected() ? (byte) 0x00 : (byte) 0x01);
      ShowRetDword("SetSelectMode");
  }//GEN-LAST:event_jCheckBox1ActionPerformed
    void SetSelect() {
        byte Target = (byte) jComboBox12.getSelectedIndex();
        byte Action = (byte) jComboBox13.getSelectedIndex();
        byte MemBank = 1;
        int Pointer = BytesToInt(HexStringToBytes(jTextField6.getText()));
        byte Truncated = jCheckBox6.isSelected() ? (byte) 0x80 : (byte) 0x00;
        byte[] MaskByt = HexStringToBytes(jTextField7.getText());
        RetDword = DLLProject.SetSelectParam(Target, Action, MemBank, Pointer, Truncated, MaskByt, (byte) MaskByt.length);
        ShowRetDword("SetSelectParam");
    }
  private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
      // TODO add your handling code here:
      byte[] PC = new byte[2], EPC = new byte[12], QTControl = new byte[16];
      byte[] AccessPassword = HexStringToBytes(jTextField3.getText());
      byte RW = 0x00;
      byte Persistence = 0x01;
      byte Payload = (byte) ((jCheckBox2.isSelected() ? 0x01 : 0x00) | (jCheckBox3.isSelected() ? 0x02 : 0x00));

      SetSelect();
      RetDword = DLLProject.ImpinjMonzaQT(AccessPassword, RW, Persistence, Payload, PC, EPC, QTControl);
      ShowRetDword("ImpinjMonzaQT");
  }//GEN-LAST:event_jButton17ActionPerformed

  private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
      // TODO add your handling code here:
      int rowIndex = jTable1.getSelectedRow();
      if (jTable1.getValueAt(rowIndex, 2).toString() != null) {
          jTextField7.setText(jTable1.getValueAt(rowIndex, 2).toString());
      }
  }//GEN-LAST:event_jTable1MouseClicked

  private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
      // TODO add your handling code here:
      byte[] PC = new byte[2], EPC = new byte[12], QTControl = new byte[16];
      byte[] AccessPassword = HexStringToBytes(jTextField3.getText());
      byte RW = 0x01;
      byte Persistence = 0x01;
      byte Payload = (byte) ((jCheckBox2.isSelected() ? 0x01 : 0x00) | (jCheckBox3.isSelected() ? 0x02 : 0x00));

      SetSelect();
      RetDword = DLLProject.ImpinjMonzaQT(AccessPassword, RW, Persistence, Payload, PC, EPC, QTControl);
      ShowRetDword("ImpinjMonzaQT");
  }//GEN-LAST:event_jButton18ActionPerformed

  private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
      // TODO add your handling code here:
      byte[] PC = new byte[2], EPC = new byte[12];
      byte[] AccessPassword = HexStringToBytes(jTextField4.getText());
      byte[] Config = HexStringToBytes(jTextField5.getText());

      SetSelect();
      RetDword = DLLProject.NxpChangeConfig(AccessPassword, Config, PC, EPC);
      ShowRetDword("NxpChangeConfig");
  }//GEN-LAST:event_jButton19ActionPerformed

  private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
      // TODO add your handling code here:
      byte[] PC = new byte[2], EPC = new byte[12];
      byte[] AccessPassword = HexStringToBytes(jTextField4.getText());
      byte SetEas = (byte) (jCheckBox5.isSelected() ? 0x01 : 0x00);

      SetSelect();
      RetDword = DLLProject.NxpChangeEas(AccessPassword, SetEas, PC, EPC);
      ShowRetDword("NxpChangeEas");
  }//GEN-LAST:event_jButton21ActionPerformed

  private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
      // TODO add your handling code here:
      byte[] PC = new byte[2], EPC = new byte[12];
      byte[] AccessPassword = HexStringToBytes(jTextField4.getText());
      byte Protect = (byte) (jCheckBox4.isSelected() ? 0x01 : 0x00);

      SetSelect();
      RetDword = DLLProject.NxpReadProtect(AccessPassword, Protect, PC, EPC);
      ShowRetDword("NxpReadProtect");
  }//GEN-LAST:event_jButton20ActionPerformed

  private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
      // TODO add your handling code here:
      byte[] EASAlarmCode = new byte[64];
      RetDword = DLLProject.NxpEasAlarm(EASAlarmCode);
      ShowRetDword("NxpEasAlarm");
  }//GEN-LAST:event_jButton22ActionPerformed

  private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
      // TODO add your handling code here:
      ByteByReference DR = new ByteByReference(), TRext = new ByteByReference(), Target = new ByteByReference(), M = new ByteByReference(), Sel = new ByteByReference(), Session = new ByteByReference(), Q = new ByteByReference();
      RetDword = DLLProject.GetQuery(DR, M, TRext, Sel, Session, Target, Q);
      ShowRetDword("GetQuery");

      jComboBox5.setSelectedIndex(DR.getValue());
      jComboBox6.setSelectedIndex(M.getValue());
      jComboBox7.setSelectedIndex(TRext.getValue());
      jComboBox8.setSelectedIndex(Sel.getValue());
      jComboBox9.setSelectedIndex(Session.getValue());
      jComboBox10.setSelectedIndex(Target.getValue());
      jComboBox11.setSelectedIndex(Q.getValue());
  }//GEN-LAST:event_jButton23ActionPerformed

  private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
      // TODO add your handling code here:
      byte DR = (byte) jComboBox5.getSelectedIndex();
      byte M = (byte) jComboBox6.getSelectedIndex();
      byte TRext = (byte) jComboBox7.getSelectedIndex();
      byte Sel = (byte) jComboBox8.getSelectedIndex();
      byte Session = (byte) jComboBox9.getSelectedIndex();
      byte Target = (byte) jComboBox10.getSelectedIndex();
      byte Q = (byte) jComboBox11.getSelectedIndex();

      RetDword = DLLProject.SetQuery(DR, M, TRext, Sel, Session, Target, Q);
      ShowRetDword("SetQuery");
  }//GEN-LAST:event_jButton24ActionPerformed

  private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
      // TODO add your handling code here:
      byte Target = (byte) jComboBox12.getSelectedIndex();
      byte Action = (byte) jComboBox13.getSelectedIndex();
      byte MemBank = (byte) jComboBox14.getSelectedIndex();
      int Pointer = BytesToInt(HexStringToBytes(jTextField6.getText()));
      byte Truncated = jCheckBox6.isSelected() ? (byte) 0x80 : (byte) 0x00;
      byte[] MaskByt = HexStringToBytes(jTextField7.getText());
      RetDword = DLLProject.SetSelectParam(Target, Action, MemBank, Pointer, Truncated, MaskByt, (byte) MaskByt.length);
      ShowRetDword("SetSelectParam");
  }//GEN-LAST:event_jButton25ActionPerformed

  private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
      // TODO add your handling code here:
  }//GEN-LAST:event_jButton26ActionPerformed

  private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
      // TODO add your handling code here:
      byte[] AccessPassword = HexStringToBytes(jTextField11.getText());
      byte MemBank = (byte) jComboBox15.getSelectedIndex();
      int StartIndex = BytesToShort(HexStringToBytes(jTextField9.getText()));
      int Length = BytesToShort(HexStringToBytes(jTextField10.getText()));
      byte[] PC = new byte[2], EPC = new byte[12], Data = new byte[1024];
      IntByReference Size = new IntByReference();
      SetSelect();
      RetDword = DLLProject.ReadData(AccessPassword, MemBank, StartIndex, Length, PC, EPC, Data, Size);
      if (RetDword == 0) {
          jTextField12.setText(BytesToHexString(Data, " ", 0, Size.getValue()));
      }
      ShowRetDword("ReadData");
  }//GEN-LAST:event_jButton27ActionPerformed

  private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
      // TODO add your handling code here:
      byte[] AccessPassword = HexStringToBytes(jTextField11.getText());
      byte MemBank = (byte) jComboBox15.getSelectedIndex();
      int StartIndex = BytesToShort(HexStringToBytes(jTextField9.getText()));
      int Length = BytesToShort(HexStringToBytes(jTextField10.getText()));
      byte[] PC = new byte[2], EPC = new byte[12];
      byte[] Data = HexStringToBytes(jTextField12.getText());
      SetSelect();
      RetDword = DLLProject.WriteData(AccessPassword, MemBank, StartIndex, Data, Data.length, PC, EPC);
      ShowRetDword("WriteData");
  }//GEN-LAST:event_jButton28ActionPerformed

  private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
      // TODO add your handling code here:
      byte[] LD = new byte[3];
      if (jCheckBox7.isSelected()) {
          LD[2] |= 0x03 * 0x04;
          LD[1] |= (byte) jComboBox16.getSelectedIndex();
      }
      if (jCheckBox9.isSelected()) {
          LD[2] |= 0x03;
          LD[0] |= (byte) (jComboBox18.getSelectedIndex() * 0x40);
      }
      if (jCheckBox11.isSelected()) {
          LD[1] |= 0x03 * 0x40;
          LD[0] |= (byte) (jComboBox20.getSelectedIndex() * 0x10);
      }
      if (jCheckBox8.isSelected()) {
          LD[1] |= 0x03 * 0x10;
          LD[0] |= (byte) (jComboBox17.getSelectedIndex() * 0x04);
      }
      if (jCheckBox10.isSelected()) {
          LD[1] |= 0x03 * 0x04;
          LD[0] |= (byte) jComboBox19.getSelectedIndex();
      }
      byte[] PC = new byte[2], EPC = new byte[12];
      byte[] AccessPassword = HexStringToBytes(jTextField13.getText());

      SetSelect();
      RetDword = DLLProject.LockUnlock(AccessPassword, LD, PC, EPC);
      ShowRetDword("LockUnlock");
  }//GEN-LAST:event_jButton29ActionPerformed

  private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
      // TODO add your handling code here:
      byte[] PC = new byte[2], EPC = new byte[12];
      byte[] AccessPassword = HexStringToBytes(jTextField14.getText());

      SetSelect();
      RetDword = DLLProject.Kill(AccessPassword, PC, EPC);
      ShowRetDword("Kill");
  }//GEN-LAST:event_jButton30ActionPerformed

  private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
      // TODO add your handling code here:
      jTextArea2.setText("");
      ByteByReference CH_L = new ByteByReference(), CH_H = new ByteByReference();
      byte[] JMR = new byte[128];
      RetDword = DLLProject.ScanJammer(CH_L, CH_H, JMR);
      ShowRetDword("ScanJammer");

      for (int i = 0; i < CH_H.getValue() - CH_L.getValue(); i++) {
          int jammer = JMR[i];
          if (jammer > 127) {
              jammer = -((-jammer) & 0xFF);
          }
          jTextArea2.append("CH_" + String.valueOf(i) + ":" + String.valueOf(jammer) + "dBm" + "\r\n");
      }
  }//GEN-LAST:event_jButton31ActionPerformed

  private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
      // TODO add your handling code here:
      jTextArea3.setText("");
      ByteByReference CH_L = new ByteByReference(), CH_H = new ByteByReference();
      byte[] JMR = new byte[128];
      RetDword = DLLProject.ScanRSSI(CH_L, CH_H, JMR);
      ShowRetDword("ScanRSSI");

      for (int i = 0; i < CH_H.getValue() - CH_L.getValue(); i++) {
          int jammer = JMR[i];
          if (jammer > 127) {
              jammer = -((-jammer) & 0xFF);
          }
          jTextArea3.append("CH_" + String.valueOf(i) + ":" + String.valueOf(jammer) + "dBm" + "\r\n");
      }
  }//GEN-LAST:event_jButton32ActionPerformed

  private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
      // TODO add your handling code here:
      byte Mixer_G = (byte) jComboBox21.getSelectedIndex();
      byte IF_G = (byte) jComboBox22.getSelectedIndex();
      int Thrd = BytesToShort(HexStringToBytes(jTextField16.getText()));
      RetDword = DLLProject.SetModemPara(Mixer_G, IF_G, Thrd);
      ShowRetDword("SetModemPara");
  }//GEN-LAST:event_jButton33ActionPerformed

  private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
      // TODO add your handling code here:
      ByteByReference Mixer_G = new ByteByReference(), IF_G = new ByteByReference();
      IntByReference Thrd = new IntByReference();
      RetDword = DLLProject.GetModemPara(Mixer_G, IF_G, Thrd);
      ShowRetDword("GetModemPara");

      jComboBox21.setSelectedIndex(Mixer_G.getValue());
      jComboBox22.setSelectedIndex(IF_G.getValue());
      String ThrdStr = Integer.toHexString(Thrd.getValue()).toUpperCase();
      if (ThrdStr.length() % 2 > 0) {
          ThrdStr = "0" + ThrdStr;
      }
      jTextField16.setText(ThrdStr);
  }//GEN-LAST:event_jButton34ActionPerformed
    _NET_DEVICE_CONFIG CurrentNdc = null;
  private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
      // TODO add your handling code here:
      jTextField19.setText("");
      CurrentNdc = null;
      int rowIndex = jTable3.getSelectedRow();
      if (jTable3.getValueAt(rowIndex, 3) == null) {
          return;
      }

      String MAC = jTable3.getValueAt(rowIndex, 3).toString();
      jTextField19.setText(MAC);
      byte[] MacByt = HexStringToBytes(MAC, ":");
      IntByReference Length = new IntByReference();
      byte[] buffer = new byte[1024];
      RetDword = DLLProject.NetCfg_GetInfo((byte) 0, MacByt, buffer, Length);
      ShowRetDword("NetCfg_GetInfo");
      if (RetDword != 0) {
          return;
      }
      _NET_DEVICE_CONFIG Ndc = new _NET_DEVICE_CONFIG();
      try {
          byte[] HWCfgByt = new byte[128];
          System.arraycopy(buffer, 0, HWCfgByt, 0, 74);
          JavaStruct.unpack(Ndc.HWCfg, HWCfgByt, ByteOrder.LITTLE_ENDIAN);
          byte[] PortCfg0 = new byte[128];
          System.arraycopy(buffer, 76, PortCfg0, 0, 68);
          JavaStruct.unpack(Ndc.PortCfg[0], PortCfg0, ByteOrder.LITTLE_ENDIAN);
          byte[] PortCfg1 = new byte[128];
          System.arraycopy(buffer, 76 + 68, PortCfg1, 0, 68);
          JavaStruct.unpack(Ndc.PortCfg[1], PortCfg1, ByteOrder.LITTLE_ENDIAN);

//      JavaStruct.unpack(Ndc, buffer);
      } catch (StructException ex) {
          Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
      }
      CurrentNdc = Ndc;
      jTextField20.setText(new String(Ndc.HWCfg.szModulename, StandardCharsets.UTF_8));
      jTextField21.setText(BytesToIP(Ndc.HWCfg.bDevIP));
      jTextField22.setText(BytesToIP(Ndc.HWCfg.bDevIPMask));
      jTextField23.setText(BytesToIP(Ndc.HWCfg.bDevGWIP));
      jCheckBox12.setSelected(Ndc.HWCfg.bDhcpEnable == 1 ? true : false);

      jComboBox24.setSelectedIndex(Ndc.PortCfg[1].bNetMode);
      jCheckBox14.setSelected(Ndc.PortCfg[1].bRandSportFlag == 1 ? true : false);
      jTextField24.setText(String.valueOf(Ndc.PortCfg[1].wNetPort & 0xFFFF));
      jComboBox25.setSelectedIndex(Ndc.PortCfg[1].bDNSFlag == 1 ? 1 : 0);
      jTextField25.setText(BytesToIP(Ndc.PortCfg[1].bDesIP));
      jTextField26.setText(new String(Ndc.PortCfg[1].szDomainname, StandardCharsets.UTF_8));
      jTextField27.setText(String.valueOf(Ndc.PortCfg[1].wDesPort & 0xFFFF));
      jComboBox26.setSelectedItem(String.valueOf(Ndc.PortCfg[1].dBaudRate));
      jComboBox27.setSelectedItem(String.valueOf(Ndc.PortCfg[1].bDataSize));
      jComboBox28.setSelectedIndex(Ndc.PortCfg[1].bStopBits);
      jComboBox29.setSelectedIndex(Ndc.PortCfg[1].bParity);
      jCheckBox15.setSelected(Ndc.PortCfg[1].bPHYChangeHandle == 1 ? true : false);
      jTextField28.setText(String.valueOf(Ndc.PortCfg[1].dRxPktlength));
      jTextField29.setText(String.valueOf(Ndc.PortCfg[1].dRxPktTimeout));
      jCheckBox16.setSelected(Ndc.PortCfg[1].bResetCtrl == 1 ? true : false);
  }//GEN-LAST:event_jTable3MouseClicked
    boolean NetCfgBool = false;
    String NetCfgIP = "";
  private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
      // TODO add your handling code here:
      jButton36.setEnabled(false);
      if (!NetCfgBool || !NetCfgIP.equals(jComboBox23.getSelectedItem().toString())) {
          RetDword = DLLProject.NetCfg_Close();
          ShowRetDword("NetCfg_Close");
          RetDword = DLLProject.NetCfg_Open(jComboBox23.getSelectedItem().toString());
          ShowRetDword("NetCfg_Open");
          if (RetDword == 0) {
              NetCfgIP = jComboBox23.getSelectedItem().toString();
              NetCfgBool = true;
          }
      }

      IntByReference Count = new IntByReference(), Length = new IntByReference();
      byte[] buffer = new byte[1024];
      RetDword = DLLProject.NetCfg_SearchForDevices((byte) 0, Count, buffer, Length);
      if (Count.getValue() > 0) {
          int NdiLength = Length.getValue() / Count.getValue();
          for (int i = 0; i < Count.getValue(); i++) {
              byte[] Data = new byte[NdiLength];
              System.arraycopy(buffer, 0, Data, 0, Data.length);
              NET_DeviceInfo Ndi = new NET_DeviceInfo();
              try {
                  JavaStruct.unpack(Ndi, Data);
              } catch (StructException ex) {
                  Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
              }
              SetNetCfg(Ndi);

          }
      }
      ShowRetDword("NetCfg_SearchForDevices");
      jButton36.setEnabled(true);
  }//GEN-LAST:event_jButton36ActionPerformed

  private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed
      // TODO add your handling code here:    
      _NET_DEVICE_CONFIG Ndc = CurrentNdc;
      Arrays.fill(Ndc.HWCfg.szModulename, (byte) 0);
      byte[] ModuleNameByt = jTextField20.getText().getBytes(StandardCharsets.UTF_8);
      System.arraycopy(ModuleNameByt, 0, Ndc.HWCfg.szModulename, 0, ModuleNameByt.length);
      Ndc.HWCfg.bDevIP = IPToBytes(jTextField21.getText());
      Ndc.HWCfg.bDevIPMask = IPToBytes(jTextField22.getText());
      Ndc.HWCfg.bDevGWIP = IPToBytes(jTextField23.getText());
      Ndc.HWCfg.bDhcpEnable = (byte) (jCheckBox12.isSelected() ? 1 : 0);

      Ndc.PortCfg[1].bNetMode = (byte) jComboBox24.getSelectedIndex();
      Ndc.PortCfg[1].bRandSportFlag = (byte) (jCheckBox14.isSelected() ? 1 : 0);
      Ndc.PortCfg[1].wNetPort = BytesToShort(HexStringToBytes(Integer.toHexString(Integer.valueOf(jTextField24.getText()))));
      Ndc.PortCfg[1].bDNSFlag = (byte) jComboBox25.getSelectedIndex();
      Ndc.PortCfg[1].bDesIP = IPToBytes(jTextField25.getText());
      Arrays.fill(Ndc.PortCfg[1].szDomainname, (byte) 0);
      byte[] szDomainnameByt = jTextField26.getText().getBytes(StandardCharsets.UTF_8);
      System.arraycopy(szDomainnameByt, 0, Ndc.PortCfg[1].szDomainname, 0, szDomainnameByt.length);
      Ndc.PortCfg[1].wDesPort = BytesToShort(HexStringToBytes(Integer.toHexString(Integer.valueOf(jTextField27.getText()))));
      Ndc.PortCfg[1].dBaudRate = Integer.valueOf(jComboBox26.getSelectedItem().toString());
      Ndc.PortCfg[1].bDataSize = Byte.valueOf(jComboBox27.getSelectedItem().toString());
      Ndc.PortCfg[1].bStopBits = (byte) jComboBox28.getSelectedIndex();
      Ndc.PortCfg[1].bParity = (byte) jComboBox29.getSelectedIndex();
      Ndc.PortCfg[1].bPHYChangeHandle = (byte) (jCheckBox15.isSelected() ? 1 : 0);
      Ndc.PortCfg[1].dRxPktlength = Integer.valueOf(jTextField28.getText());
      Ndc.PortCfg[1].dRxPktTimeout = Integer.valueOf(jTextField29.getText());
      Ndc.PortCfg[1].bResetCtrl = (byte) (jCheckBox16.isSelected() ? 1 : 0);

      byte[] NdcByt = new byte[1024];

      try {
          byte[] HWCfgByt = JavaStruct.pack(Ndc.HWCfg, ByteOrder.LITTLE_ENDIAN);
          System.arraycopy(HWCfgByt, 0, NdcByt, 0, HWCfgByt.length);
          byte[] PortCfg0 = JavaStruct.pack(Ndc.PortCfg[0], ByteOrder.LITTLE_ENDIAN);
          System.arraycopy(PortCfg0, 0, NdcByt, 76, PortCfg0.length);
          byte[] PortCfg1 = JavaStruct.pack(Ndc.PortCfg[1], ByteOrder.LITTLE_ENDIAN);
          System.arraycopy(PortCfg1, 0, NdcByt, 76 + 68, PortCfg1.length);

      } catch (StructException ex) {
          Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
      }
      byte[] LocalMAC = GetMac(NetCfgIP);
      byte[] DevMAC = HexStringToBytes(jTextField19.getText());
      RetDword = DLLProject.NetCfg_SetInfo((byte) 0, LocalMAC, DevMAC, NdcByt, 212);
      ShowRetDword("NetCfg_SetInfo");
  }//GEN-LAST:event_jButton40ActionPerformed

  private void jRadioButton4ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButton4ItemStateChanged
      // TODO add your handling code here:
      if (jRadioButton4.isSelected()) {
          jComboBox30.removeAllItems();
          for (String Cp : getComPorts()) {
              jComboBox30.addItem(Cp);
          }
      }
  }//GEN-LAST:event_jRadioButton4ItemStateChanged

  private void jRadioButton5ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButton5ItemStateChanged
      // TODO add your handling code here:
      if (jRadioButton5.isSelected()) {
          jComboBox30.removeAllItems();
      }
  }//GEN-LAST:event_jRadioButton5ItemStateChanged

  private void jButton41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton41ActionPerformed
      // TODO add your handling code here:
      byte[] MacByt = HexStringToBytes(jTextField19.getText());
      RetDword = DLLProject.NetCfg_FactoryReset((byte) 0, MacByt);
      ShowRetDword("NetCfg_FactoryReset");
  }//GEN-LAST:event_jButton41ActionPerformed

  private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
      // TODO add your handling code here:
      Clibrary.SvrCallReceive svrCallReceive = new SvrCallReceiveImpl();

      String CommandStr = jButton37.getText();
      if (CommandStr == "Startup") {
          if (jRadioButton4.isSelected()) {
              RetDword = DLLProject.Svr_Startup(ConnType.Com.GetConn(), jComboBox30.getEditor().getItem().toString(), svrCallReceive);
          } else if (jRadioButton8.isSelected()) {
              RetDword = DLLProject.Svr_Startup(ConnType.USB.GetConn(), jComboBox30.getEditor().getItem().toString(), svrCallReceive);
          } else if (jRadioButton5.isSelected()) {
              RetDword = DLLProject.Svr_Startup(ConnType.TcpCli.GetConn(), jComboBox30.getEditor().getItem().toString(), svrCallReceive);
          } else if (jRadioButton6.isSelected()) {
              RetDword = DLLProject.Svr_Startup(ConnType.TcpSvr.GetConn(), jComboBox2.getEditor().getItem().toString(), svrCallReceive);
          } else if (jRadioButton7.isSelected()) {
              RetDword = DLLProject.Svr_Startup(ConnType.UDP.GetConn(), jComboBox2.getEditor().getItem().toString(), svrCallReceive);
          }
          if (RetDword == 0) {
              jButton37.setText("CleanUp");
          }
      } else {
          RetDword = DLLProject.Svr_CleanUp();
          jButton37.setText("Startup");
      }
      ShowRetDword(CommandStr);
  }//GEN-LAST:event_jButton37ActionPerformed

  private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
      // TODO add your handling code here:
      if (jTextArea5.getText() != "") {
          byte[] SenByt = HexStringToBytes(jTextArea5.getText());
          RetDword = DLLProject.Svr_Send(jTextField30.getText() + ":" + jTextField31.getText(), SenByt, SenByt.length);
          ShowRetDword("Svr_Send");
      }
  }//GEN-LAST:event_jButton39ActionPerformed

  private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
      // TODO add your handling code here:
      ShowRetDword("getAbsolutePath", System.getProperty("user.dir"));
  }//GEN-LAST:event_jButton11ActionPerformed

  private void jRadioButton8ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButton8ItemStateChanged
      // TODO add your handling code here:
      if (jRadioButton5.isSelected()) {
          jComboBox30.removeAllItems();
      }
  }//GEN-LAST:event_jRadioButton8ItemStateChanged

    private void jRadioButton9ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButton9ItemStateChanged
        // TODO add your handling code here:
        if (jRadioButton9.isSelected()) {
            jComboBox2.removeAllItems();
        }
    }//GEN-LAST:event_jRadioButton9ItemStateChanged

    private void jButton42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton42ActionPerformed
        // TODO add your handling code here:
        jComboBox31.removeAllItems();
        IntByReference RefCount = new IntByReference();
        RetDword = DLLProject.GetTcpSrvCount(RefCount);
        int Count = RefCount.getValue();
        ShowRetDword("GetTcpSrvCount", "Count:" + String.valueOf(Count));
        if (Count <= 0) {
            return;
        }
        int VarLength = 6;
        //   int VarLength = sizeof(SizeOfTool.getObjectSize(new TSrvClient(),SizeEnum.B));
        Count = 1024;
        byte[] TmpData = new byte[VarLength * 1024];
        RefCount.setValue(Count);
        RetDword = DLLProject.GetTcpSrvClientArray(RefCount, TmpData);
        ShowRetDword("GetTcpSrvClientArray");
        Count = RefCount.getValue();
        if (RetDword == 0 && Count > 0) {
            for (int i = 0; i < Count; i++) {
                byte[] Data = new byte[VarLength];
                System.arraycopy(TmpData, i * VarLength, Data, 0, Data.length);
                byte TmpByt = Data[4];
                Data[4] = Data[5];
                Data[5] = TmpByt;
                TSrvClient Sc = new TSrvClient();
                try {
                    JavaStruct.unpack(Sc, Data);
                    String IP = BytesToIP(Sc.IP);
                    int Port = (Sc.Port & 0x0FFFF);
                    jComboBox31.addItem(IP + ":" + String.valueOf(Port));
                } catch (StructException ex) {
                    Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_jButton42ActionPerformed

    private void jComboBox31ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox31ItemStateChanged
        // TODO add your handling code here:
        String Addr = jComboBox31.getSelectedItem().toString();
        if (Addr != "") {
            RetDword = DLLProject.SetCommAddr(Addr);
            ShowRetDword("SetCommAddr");
        }
    }//GEN-LAST:event_jComboBox31ItemStateChanged

    void SetIPList() {
        jComboBox23.removeAllItems();
        for (String Cp : GetNetwork()) {
            jComboBox23.addItem(Cp);
        }
    }

    @StructClass
    public class TSrvClient {

        /**
         * IP地址
         */
        @StructField(order = 0)
        public byte[] IP = new byte[4];
        /// <summary>
        /// 网络通讯端口号
        /// </summary>
        @StructField(order = 1)
        public short Port;
    }

    @StructClass
    public class NET_DeviceInfo {

        /**
         * MAC地址
         */
        @StructField(order = 0)
        public byte[] MAC = new byte[6];
        /**
         * IP地址
         */
        @StructField(order = 1)
        public byte[] IP = new byte[4];
        /**
         * 版本
         */
        @StructField(order = 2)
        public byte VER;
        /**
         * 设备名长度
         */
        @StructField(order = 3)
        public byte LEN;
        /**
         * 设备名
         */
        @StructField(order = 4)
        public byte[] NAME = new byte[16];
    }

    @StructClass
    public class _DEVICEHW_CONFIG {
        /// <summary>
        /// 设备类型,具体见设备类型表
        /// </summary>

        @StructField(order = 0)
        public byte bDevType;
        /// <summary>
        /// 设备子类型
        /// </summary>
        @StructField(order = 1)
        public byte bAuxDevType;
        /// <summary>
        /// 设备序号
        /// </summary>
        @StructField(order = 2)
        public byte bIndex;
        /// <summary>
        /// 设备硬件版本号
        /// </summary>
        @StructField(order = 3)
        public byte bDevHardwareVer;
        /// <summary>
        /// 设备软件版本号
        /// </summary>
        @StructField(order = 4)
        public byte bDevSoftwareVer;
        /// <summary>
        /// 模块名
        /// </summary>
        @StructField(order = 5)
        public byte[] szModulename = new byte[21];
        /// <summary>
        /// 模块网络MAC地址
        /// </summary>
        @StructField(order = 6)
        public byte[] bDevMAC = new byte[6];
        /// <summary>
        /// 模块IP地址
        /// </summary>   
        @StructField(order = 7)
        public byte[] bDevIP = new byte[4];
        /// <summary>
        /// 模块网关IP
        /// </summary>
        @StructField(order = 8)
        public byte[] bDevGWIP = new byte[4];
        /// <summary>
        /// 模块子网掩码
        /// </summary>  
        @StructField(order = 9)
        public byte[] bDevIPMask = new byte[4];
        /// <summary>
        /// DHCP 使能，是否启用DHCP,1:启用，0：不启用
        /// </summary>
        @StructField(order = 10)
        public byte bDhcpEnable;
        /// <summary>
        /// 保留
        /// </summary>
        @StructField(order = 11)
        public byte[] breserved = new byte[0x1D];
    }

    @StructClass
    public class _DEVICEPORT_CONFIG {
        /// <summary>
        /// 端口序号
        /// </summary>

        @StructField(order = 0)
        public byte bIndex;
        /// <summary>
        /// 端口启用标志 1：启用后 ；0：不启用
        /// </summary>
        @StructField(order = 1)
        public byte bPortEn;
        /// <summary>
        /// 网络工作模式: 0: TCP SERVER;1: TCP CLENT; 2: UDP SERVER 3：UDP CLIENT;
        /// </summary>
        @StructField(order = 2)
        public byte bNetMode;
        /// <summary>
        /// TCP 客户端模式下随即本地端口号，1：随机 0: 不随机
        /// </summary>
        @StructField(order = 3)
        public byte bRandSportFlag;
        /// <summary>
        /// 网络通讯端口号
        /// </summary>
        @StructField(order = 4)
        public short wNetPort;
        /// <summary>
        /// 目的IP地址
        /// </summary>   
        @StructField(order = 5)
        public byte[] bDesIP = new byte[4];
        /// <summary>
        /// 工作于TCP Server模式时，允许外部连接的端口号
        /// </summary>
        @StructField(order = 6)
        public short wDesPort;
        /// <summary>
        /// 串口波特率: 300---921600bps
        /// </summary>
        @StructField(order = 7)
        public int dBaudRate;
        /// <summary>
        /// 串口数据位: 5---8位 
        /// </summary>
        @StructField(order = 8)
        public byte bDataSize;
        /// <summary>
        /// 串口停止位: 1表示1个停止位; 2表示2个停止位
        /// </summary>
        @StructField(order = 9)
        public byte bStopBits;
        /// <summary>
        /// 串口校验位: 0表示奇校验; 1表示偶校验; 2表示标志位(MARK,置1); 3表示空白位(SPACE,清0);
        /// </summary>
        @StructField(order = 10)
        public byte bParity;
        /// <summary>
        /// PHY断开，Socket动作，1：关闭Socket 2、不动作
        /// </summary>
        @StructField(order = 11)
        public byte bPHYChangeHandle;
        /// <summary>
        /// 串口RX数据打包长度，最大1024
        /// </summary>
        @StructField(order = 12)
        public int dRxPktlength;
        /// <summary>
        /// 串口RX数据打包转发的最大等待时间,单位为: 10ms,0则表示关闭超时功能
        /// </summary>
        @StructField(order = 13)
        public int dRxPktTimeout;
        /// <summary>
        /// 工作于TCP CLIENT时，连接TCP SERVER的最大重试次数
        /// </summary>
        @StructField(order = 14)
        public byte bReConnectCnt;
        /// <summary>
        /// 串口复位操作: 0表示不清空串口数据缓冲区; 1表示连接时清空串口数据缓冲区
        /// </summary>
        @StructField(order = 15)
        public byte bResetCtrl;
        /// <summary>
        /// 域名功能启用标志，1：启用 2：不启用
        /// </summary>
        @StructField(order = 16)
        public byte bDNSFlag;
        /// <summary>
        /// 域名
        /// </summary>
        @StructField(order = 17)
        public byte[] szDomainname = new byte[20];
        /// <summary>
        /// DNS 主机
        /// </summary>
        @StructField(order = 18)
        public byte[] bDNSHostIP = new byte[4];
        /// <summary>
        /// DNS 端口
        /// </summary>
        @StructField(order = 19)
        public short wDNSHostPort;
        @StructField(order = 20)
        public byte[] breserved = new byte[8];
    };

    @StructClass
    public class _NET_DEVICE_CONFIG {
        /// <summary>
        /// 从硬件处获取的配置信息
        /// </summary>

        @StructField(order = 0)
        public _DEVICEHW_CONFIG HWCfg = new _DEVICEHW_CONFIG();
        /// <summary>
        /// 网络设备所包含的子设备的配置信息
        /// </summary>
        @StructField(order = 1)
        public _DEVICEPORT_CONFIG[] PortCfg = {new _DEVICEPORT_CONFIG(), new _DEVICEPORT_CONFIG()};
    }

    private void SetNetCfg(NET_DeviceInfo Ndi) {
        String IP = BytesToIP(Ndi.IP);
        String MAC = BytesToHexString(Ndi.MAC, ":");
        String Name = new String(Ndi.NAME, 0, Ndi.LEN, StandardCharsets.UTF_8);
        String VER = String.valueOf(Ndi.VER);

        lbDo1:
        {
            for (int i = 0; i < jTable3.getRowCount(); i++) {
                if (MAC.equals(jTable3.getValueAt(i, 3))) {
                    jTable3.setValueAt(Name, i, 1);
                    jTable3.setValueAt(IP, i, 2);
                    jTable3.setValueAt(VER, i, 4);
                    break lbDo1;
                }
            }
            DefaultTableModel Tm = (DefaultTableModel) jTable3.getModel();
            Vector<String> RowData = new Vector<String>();
            RowData.add(String.valueOf(jTable3.getRowCount() + 1));
            RowData.add(Name);
            RowData.add(IP);
            RowData.add(MAC);
            RowData.add(VER);
            Tm.addRow(RowData);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
//                int fdhf=RFID_EPC_Project.CLibrary.INSTANCE.ReadSingle();
//        int djfi=RFID_EPC_Project.CLibrary.INSTANCE.NetCfg_Open("192.168.0.106");
//        System.out.print(djfi);
// List<String> ports = getComPorts();
//        List<String> Networks = GetNetwork();

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup ConnGroup;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox13;
    private javax.swing.JCheckBox jCheckBox14;
    private javax.swing.JCheckBox jCheckBox15;
    private javax.swing.JCheckBox jCheckBox16;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox10;
    private javax.swing.JComboBox<String> jComboBox11;
    private javax.swing.JComboBox<String> jComboBox12;
    private javax.swing.JComboBox<String> jComboBox13;
    private javax.swing.JComboBox<String> jComboBox14;
    private javax.swing.JComboBox<String> jComboBox15;
    private javax.swing.JComboBox<String> jComboBox16;
    private javax.swing.JComboBox<String> jComboBox17;
    private javax.swing.JComboBox<String> jComboBox18;
    private javax.swing.JComboBox<String> jComboBox19;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox20;
    private javax.swing.JComboBox<String> jComboBox21;
    private javax.swing.JComboBox<String> jComboBox22;
    private javax.swing.JComboBox<String> jComboBox23;
    private javax.swing.JComboBox<String> jComboBox24;
    private javax.swing.JComboBox<String> jComboBox25;
    private javax.swing.JComboBox<String> jComboBox26;
    private javax.swing.JComboBox<String> jComboBox27;
    private javax.swing.JComboBox<String> jComboBox28;
    private javax.swing.JComboBox<String> jComboBox29;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox30;
    private javax.swing.JComboBox<String> jComboBox31;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JRadioButton jRadioButton9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.ButtonGroup rbSvrGroup;
    // End of variables declaration//GEN-END:variables
}
