class Devicepara {
    get Addr() { return this.DEVICEARRD; }
    set Addr(value) { this.DEVICEARRD = value; }

    get Protocol() { return this.RFIDPRO; }
    set Protocol(value) { this.RFIDPRO = value; }

    get Baud() { return this.BAUDRATE; }
    set Baud(value) { this.BAUDRATE = value; }

    get Workmode() { return this.WORKMODE; }
    set Workmode(value) { this.WORKMODE = value; }

    get port() { return this.INTERFACE; }
    set port(value) { this.INTERFACE = value; }

    get wieggand() { return this.WGSET; }
    set wieggand(value) { this.WGSET = value; }

    get Ant() { return this.ANT; }
    set Ant(value) { this.ANT = value; }

    get Region() { return this.REGION; }
    set Region(value) { this.REGION = value; }

    get Channel() { return this.CN; }
    set Channel(value) { this.CN = value; }

    get Power() { return this.RFIDPOWER; }
    set Power(value) { this.RFIDPOWER = value; }

    get Area() { return this.INVENTORYAREA; }
    set Area(value) { this.INVENTORYAREA = value; }

    get Q() { return this.QVALUE; }
    set Q(value) { this.QVALUE = value; }

    get Session() { return this.SESSION; }
    set Session(value) { this.SESSION = value; }

    get Startaddr() { return this.ACSADDR; }
    set Startaddr(value) { this.ACSADDR = value; }

    get DataLen() { return this.ACSDATALEN; }
    set DataLen(value) { this.ACSDATALEN = value; }

    get Filtertime() { return this.FILTERTIME; }
    set Filtertime(value) { this.FILTERTIME = value; }

    get Triggletime() { return this.TRIGGLETIME; }
    set Triggletime(value) { this.TRIGGLETIME = value; }

    get Buzzertime() { return this.BUZZERTIME; }
    set Buzzertime(value) { this.BUZZERTIME = value; }

    get IntenelTime() { return this.INTERNELTIME; }
    set IntenelTime(value) { this.INTERNELTIME = value; }

    get StartFreq() { return this.STRATFREI; }
    set StartFreq(value) { this.STRATFREI = value; }

    get StartFreqde() { return this.STRATFRED; }
    set StartFreqde(value) { this.STRATFRED = value; }

    get Stepfreq() { return this.STEPFRE; }
    set Stepfreq(value) { this.STEPFRE = value; }
}