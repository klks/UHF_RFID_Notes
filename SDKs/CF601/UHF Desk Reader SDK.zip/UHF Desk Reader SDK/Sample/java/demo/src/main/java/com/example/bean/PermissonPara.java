package com.example.bean;

import lombok.Data;

@Data
public class PermissonPara {
    private String CodeEn;
    private String Code;
    private String MaskEn;
    private String StartAdd;
    private String MaskLen;
    private String MaskData;
    private String MaskCondition;
    private int hComm;
}
