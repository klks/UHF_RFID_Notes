package com.example.bean;

import lombok.Data;

@Data
public class SelectSortParam {
   private String  target;
    private String trucate;
    private String action;
    private String membank;
    private String m_ptr;
    private String len;
    private String mask;
  private int hComm;
  private String proto;
}
