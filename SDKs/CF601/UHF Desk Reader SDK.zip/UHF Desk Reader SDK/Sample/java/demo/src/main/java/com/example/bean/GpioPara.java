package com.example.bean;

import lombok.Data;

@Data
public class GpioPara {
    private String KCEn;
    private String RelayTime;
    private String KCPowerEn;
    private String TriggleMode;
    private String BufferEn;
    private String ProtocolEn;
    private String ProtocolType;
    private String ProtocolFormat;
    private int hComm;

}
