package com.example.bean;

import lombok.Data;

@Data
public class DeviceFullInfo extends  DataInfo{
    private int devicehardversion;
    private int devicefirmversion;
    private int devicesn;
    private int hardVersion;
    private int firmVersion;
    private int sn;
    private int hComm;
}
