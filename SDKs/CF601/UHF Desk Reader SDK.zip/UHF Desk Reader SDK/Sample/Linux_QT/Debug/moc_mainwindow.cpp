/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.12)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../UHF_RFID_LinuxDemo/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.12. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[21];
    char stringdata0[444];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 18), // "on_btnOpen_clicked"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 19), // "on_btnClose_clicked"
QT_MOC_LITERAL(4, 51, 21), // "on_btnConnect_clicked"
QT_MOC_LITERAL(5, 73, 24), // "on_btnDisConnect_clicked"
QT_MOC_LITERAL(6, 98, 24), // "on_btnGetRfPower_clicked"
QT_MOC_LITERAL(7, 123, 24), // "on_btnSetRfPower_clicked"
QT_MOC_LITERAL(8, 148, 25), // "on_btnGetWorkMode_clicked"
QT_MOC_LITERAL(9, 174, 25), // "on_btnSetWorkMode_clicked"
QT_MOC_LITERAL(10, 200, 34), // "on_cmbFreqBand_currentIndexCh..."
QT_MOC_LITERAL(11, 235, 5), // "index"
QT_MOC_LITERAL(12, 241, 25), // "on_btnGetFreqBand_clicked"
QT_MOC_LITERAL(13, 267, 25), // "on_btnSetFreqBand_clicked"
QT_MOC_LITERAL(14, 293, 24), // "on_btnCloseRealy_clicked"
QT_MOC_LITERAL(15, 318, 26), // "on_btnReleaseRealy_clicked"
QT_MOC_LITERAL(16, 345, 19), // "on_btnStart_clicked"
QT_MOC_LITERAL(17, 365, 18), // "on_btnStop_clicked"
QT_MOC_LITERAL(18, 384, 21), // "on_btnScanUSB_clicked"
QT_MOC_LITERAL(19, 406, 17), // "on_btnUSB_clicked"
QT_MOC_LITERAL(20, 424, 19) // "on_btnUSB_2_clicked"

    },
    "MainWindow\0on_btnOpen_clicked\0\0"
    "on_btnClose_clicked\0on_btnConnect_clicked\0"
    "on_btnDisConnect_clicked\0"
    "on_btnGetRfPower_clicked\0"
    "on_btnSetRfPower_clicked\0"
    "on_btnGetWorkMode_clicked\0"
    "on_btnSetWorkMode_clicked\0"
    "on_cmbFreqBand_currentIndexChanged\0"
    "index\0on_btnGetFreqBand_clicked\0"
    "on_btnSetFreqBand_clicked\0"
    "on_btnCloseRealy_clicked\0"
    "on_btnReleaseRealy_clicked\0"
    "on_btnStart_clicked\0on_btnStop_clicked\0"
    "on_btnScanUSB_clicked\0on_btnUSB_clicked\0"
    "on_btnUSB_2_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x08 /* Private */,
       3,    0,  105,    2, 0x08 /* Private */,
       4,    0,  106,    2, 0x08 /* Private */,
       5,    0,  107,    2, 0x08 /* Private */,
       6,    0,  108,    2, 0x08 /* Private */,
       7,    0,  109,    2, 0x08 /* Private */,
       8,    0,  110,    2, 0x08 /* Private */,
       9,    0,  111,    2, 0x08 /* Private */,
      10,    1,  112,    2, 0x08 /* Private */,
      12,    0,  115,    2, 0x08 /* Private */,
      13,    0,  116,    2, 0x08 /* Private */,
      14,    0,  117,    2, 0x08 /* Private */,
      15,    0,  118,    2, 0x08 /* Private */,
      16,    0,  119,    2, 0x08 /* Private */,
      17,    0,  120,    2, 0x08 /* Private */,
      18,    0,  121,    2, 0x08 /* Private */,
      19,    0,  122,    2, 0x08 /* Private */,
      20,    0,  123,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_btnOpen_clicked(); break;
        case 1: _t->on_btnClose_clicked(); break;
        case 2: _t->on_btnConnect_clicked(); break;
        case 3: _t->on_btnDisConnect_clicked(); break;
        case 4: _t->on_btnGetRfPower_clicked(); break;
        case 5: _t->on_btnSetRfPower_clicked(); break;
        case 6: _t->on_btnGetWorkMode_clicked(); break;
        case 7: _t->on_btnSetWorkMode_clicked(); break;
        case 8: _t->on_cmbFreqBand_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_btnGetFreqBand_clicked(); break;
        case 10: _t->on_btnSetFreqBand_clicked(); break;
        case 11: _t->on_btnCloseRealy_clicked(); break;
        case 12: _t->on_btnReleaseRealy_clicked(); break;
        case 13: _t->on_btnStart_clicked(); break;
        case 14: _t->on_btnStop_clicked(); break;
        case 15: _t->on_btnScanUSB_clicked(); break;
        case 16: _t->on_btnUSB_clicked(); break;
        case 17: _t->on_btnUSB_2_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
